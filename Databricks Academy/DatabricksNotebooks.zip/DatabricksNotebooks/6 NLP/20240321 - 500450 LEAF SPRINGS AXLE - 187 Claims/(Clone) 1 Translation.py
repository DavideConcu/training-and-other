# Databricks notebook source
# MAGIC %md
# MAGIC # Translate to English

# COMMAND ----------

pip install -U deep-translator


# COMMAND ----------

# MAGIC %md
# MAGIC ## Params

# COMMAND ----------

#percorso del file
path = "/dbfs/FileStore/tables/reliab/NLP Projects/"
file = "20240321___500450_LEAF_SPRINGS_AXLE_187filtered_cleanedsplitted-1"
ext = ".csv"

#failure comment var 
failure_comment_var = "failure_comment"

#!!!!!!!!!!!! UNIQUE KEY !!!!!!!!!!!!!
UNIQUE_KEY = ["index", "claim_number"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

#load file
import pandas as pd 

df = pd.read_csv(path + file + ext)

# COMMAND ----------

#pulire il nome delle variabili
def clean_column_names(df):
    cleaned_columns = [col.replace('"', '')
                             .replace(',', '')
                             .replace(';', '')
                             .replace('{', '')
                             .replace('}', '')
                             .replace('(', '')
                             .replace(')', '')
                             .replace('\n', '')
                             .replace('\t', '')
                             .replace('=', '')
                             .replace(' ', '_')
                             .strip()
                             .lower() for col in df.columns]
    df.columns = cleaned_columns
    return df



# Clean column names
df = clean_column_names(df)

# COMMAND ----------

df.columns

# COMMAND ----------

#vedere se ci sono dei missing
mask = (df.complaint.isnull() == True)|( df.cause.isnull()  == True)|( df.correction.isnull() == True) 
mask2 = (df.complaint== "")|( df.cause  == "")|( df.correction == "")

df.loc[(mask|mask2)].count()

# COMMAND ----------

#create spark dataframe
sdf = spark.createDataFrame(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Translation PUDF

# COMMAND ----------

#pandas udf for translating text
import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType
from deep_translator import GoogleTranslator

# Create pandas_udf()
@pandas_udf(StringType())
def translate_pudf(comment_column: pd.Series) -> pd.Series:
    translated_column = comment_column.apply(lambda text: GoogleTranslator(source='auto', target='en').translate(text))
    return translated_column

# COMMAND ----------

# MAGIC %md
# MAGIC ## Apply Function to Spark Dataframe

# COMMAND ----------

from pyspark.sql.functions import col

for column in ["complaint", "cause", "correction"]:
    sdf = sdf.withColumn(f"{column}_translated", translate_pudf(col(column)))

# COMMAND ----------

#aggiunta del commento intero tradotto
from pyspark.sql.functions import col, concat, lit

sdf = sdf.withColumn("entire_comment_translated" , concat(col("complaint_translated"), lit(". "), col("cause_translated"), lit(". "), col("correction_translated"), lit(".")))

# COMMAND ----------

#aggiunta del commento tradotto in italiano 
# Create pandas_udf()
@pandas_udf(StringType())
def translate_pudf_it(comment_column: pd.Series) -> pd.Series:
    translated_column = comment_column.apply(lambda text: GoogleTranslator(source='auto', target='it').translate(text))
    return translated_column


sdf = sdf.withColumn(f"entire_comment_translated_italian", translate_pudf_it(col("entire_comment_translated")))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Removing Every Comma from Every Column

# COMMAND ----------

from pyspark.sql.functions import col, regexp_replace
from pyspark.sql.types import StringType

# Assuming `sdf` is your DataFrame

# Define a function to remove commas from string values
def remove_commas(column):
    return regexp_replace(column, ",", "")

# Iterate over each column
for column in sdf.columns:
    # Check if column type is string
    if sdf.schema[column].dataType == StringType():
        # Remove commas from string values in the column
        sdf = sdf.withColumn(column, remove_commas(col(column)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Spark Dataframe to Catalog

# COMMAND ----------

#write table to catalog
sdf.write.mode("overwrite")\
        .option("overwriteschema", "true")\
        .saveAsTable("reliab.20240321_NLP_500450LeafSpringAxle_187Claim")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check Results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM reliab.20240321_NLP_500450LeafSpringAxle_187Claim
# MAGIC

# COMMAND ----------

