# Databricks notebook source
# MAGIC %md
# MAGIC # Fit an XGBoost Classifier With CV 

# COMMAND ----------

# MAGIC %pip install xgboost nltk

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load Data

# COMMAND ----------

#load training data 
import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/training_cleaned_766187_splitted.xlsx_TRANSLATED.csv")

df["complete_comment_translated"] = df["complaint_translated"] + " ." + df["cause_translated"] + " ." + df["correction_translated"] + " ." 

cols_to_keep = ["complete_comment_translated", "target"]

df = df.loc[: , cols_to_keep]

df.head(5)

# COMMAND ----------

df

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pre-processing Text Data

# COMMAND ----------

#load stop words list 
import nltk
nltk.download('stopwords')
nltk.download('wordnet')

# COMMAND ----------

# importing the relevant packages
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import re

# Pre Processing
stop_words = stopwords.words('english') # creates a list of English stop words
wnl = WordNetLemmatizer() # I used lemmatizing instead of stemming
def preprocess(text_column):
    """
    Function:    This function aims to remove links, special 
                 characters, symbols, stop words and thereafter 
                 lemmatise each word in the sentence to transform 
                 the dataset into something more usable for a 
                 machine learning model.
    Input:       A text column
    Returns:     A text column (but transformed)
    """
    new_review = []
    for review in text_column:
        # for every sentence, we perform the necessary pre-processing
        text = re.sub("@\S+|https?:\S+|http?:\S|[^A-Za-z0-9]+", 
                        ' ', 
                        str(review).lower()).strip()
        text = [wnl.lemmatize(i) for i in text.split(' ') if i not in stop_words]
        new_review.append(' '.join(text)) 

    return new_review


df['complete_comment_translated_cleaned'] = preprocess(df['complete_comment_translated'])

# COMMAND ----------


def clean_special_words(text):
    import regex as re
    if type(text) == str:
        text = text.lower()

        text = text.replace("rekl", "")

        #sub bcm
        cleaned_text = re.sub(r"\bbcm\b", "body control module" , text)

        cleaned_text = re.sub(r"\bbc\b", "body control" , cleaned_text)
        cleaned_text = re.sub(r"\becu\b", "electronic control unit" , cleaned_text)
        cleaned_text = re.sub(r"\bctrl\b", "control" , cleaned_text)
        cleaned_text = re.sub(r"\bsw\b", "software" , cleaned_text)
        cleaned_text = re.sub(r"\beps\b", "electric power steering" , cleaned_text)
        cleaned_text = re.sub(r"\bimmobiliser\b", "immobilizer" , cleaned_text)
        cleaned_text = re.sub(r"\bimm\b", "immobilizer" , cleaned_text)

        return cleaned_text
    
    else:
        return text
    
#df['complete_comment_translated_cleaned'] = df['complete_comment_translated_cleaned'].apply(lambda x: clean_special_words(x))

# COMMAND ----------


def clean_special_words(text):
    import regex as re
    if type(text) == str:
        text = text.lower()

        text = text.replace("rekl", "")

        #sub bcm
        cleaned_text = re.sub(r"\bbody control\b", "bcm" , text)

        cleaned_text = re.sub(r"\bbc\b", "bcm" , cleaned_text)
        cleaned_text = re.sub(r"\belectronic control unit\b", "ecu" , cleaned_text)
        cleaned_text = re.sub(r"\bctrl\b", "control" , cleaned_text)
        cleaned_text = re.sub(r"\bsw\b", "software" , cleaned_text)
        cleaned_text = re.sub(r"\belectric power steering\b", "eps" , cleaned_text)
        cleaned_text = re.sub(r"\bimmobiliser\b", "immobilizer" , cleaned_text)
        cleaned_text = re.sub(r"\bimmo\b", "immobilizer" , cleaned_text)

        return cleaned_text
    
    else:
        return text
    
#df['complete_comment_translated_cleaned'] = df['complete_comment_translated_cleaned'].apply(lambda x: clean_special_words(x))

# COMMAND ----------

#assign a numerical label to text
labels_swapped = dict(enumerate(set(df.target)))
labels_num = {v: k for k, v in labels_swapped.items()}

#apply new labels
df["target_num"] = df["target"].apply(lambda x: labels_num[x])

print(labels_num)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Splitting Data in Train - Test

# COMMAND ----------

#Splittare in train-test
from sklearn.model_selection import train_test_split

# Text data and labels
#testo e labels
texts = df["complete_comment_translated_cleaned"].to_list()
labels = df["target_num"].to_list()

# Split the data into train and test sets
texts_train, texts_test, labels_train, labels_test = train_test_split(texts, labels, test_size=0.2, random_state=0)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Re-Balance Data

# COMMAND ----------

#visualize classes
import seaborn as sns
print(labels_num)
sns.countplot(labels_train)

# COMMAND ----------

#create df train resampled
df_train_resample = pd.DataFrame({"texts":texts_train , "label":labels_train})

count_per_label = df_train_resample.groupby("label").count()
max_count = count_per_label.iloc[-1].values[0]
max_label = count_per_label.iloc[-1].name

# COMMAND ----------

#upsample minority classes - ONLY TRAIN DATA
from sklearn.utils import resample

new_train_df = df_train_resample[df_train_resample["label"]==max_label].copy()

for label in [x for x in set(labels_train) if x != max_label]:
    df_resample = resample(df_train_resample[df_train_resample["label"]==label],
                            replace=True,
                            n_samples=max_count)
    
    new_train_df = pd.concat([new_train_df, df_resample])

new_train_df.head(5)

# COMMAND ----------

#visualize classes
import seaborn as sns
print(labels_num)
sns.countplot(new_train_df["label"])

# COMMAND ----------

#riportare text e labels come liste
#testo e labels
#texts = new_train_df["texts"].to_list()
#labels = new_train_df["label"].to_list()

# COMMAND ----------

#riportare text e labels come liste
#testo e labels
#texts_train = new_train_df["texts"].to_list()
#labels_train = new_train_df["label"].to_list()

# COMMAND ----------

labels_train.count(0)

# COMMAND ----------

# MAGIC %md
# MAGIC # XGBoost

# COMMAND ----------

# MAGIC %md
# MAGIC ### Vectorizers

# COMMAND ----------

#istanze di diversi vectorizer
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer

count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
tfidf_vect = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000)
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=15000)
tfidf_vect_ngram2 = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,4), max_features=5000)

tfidf_vect_ngram_chars = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000)
tfidf_vect_ngram_chars2 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(1,10), max_features=5000)
tfidf_vect_ngram_chars3 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(1,5), max_features=15000)
tfidf_vect_ngram_chars4 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(1,10), max_features=50000)





# COMMAND ----------

#scegliere un vectorizer
vectorizer = tfidf_vect_ngram_chars

# COMMAND ----------

# Convert text data into numerical features using chosen vectorizer
X_train = vectorizer.fit_transform(texts_train)
X_test = vectorizer.transform(texts_test)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Trasformare in DMatrix 

# COMMAND ----------

#creare la DMatrix
#import xgboost as xgb
#
#dtrain = xgb.DMatrix(X_train, labels_train , enable_categorical=True)
#dtest = xgb.DMatrix(X_test, labels_test , enable_categorical=True)
#

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cross-Validation

# COMMAND ----------

##parametri del cv
#param = {"max_depth": 2, 
#         "eta": 0.01, 
#         "objective": "multi:softmax", 
#         "num_class": len(labels_num)}
#num_round = 2000

# COMMAND ----------

#param = {"objective":"multi:softmax",'colsample_bytree': 0.3,'learning_rate': 0.1,
#                'max_depth': 2, 'alpha': 10, "num_class": len(labels_num)}

# COMMAND ----------

#print("running cross validation")
## do cross validation, this will print result out as
## [iteration]  metric_name:mean_value+std_value
## std_value is standard deviation of the metric
##error: merror or mlogloss 
#cross_validated = xgb.cv(
#                    param,
#                    dtrain,
#                    num_round,
#                    nfold=10,
#                    metrics={"merror"},
#                    seed=0,
#                    early_stopping_rounds=50,
#                    callbacks=[xgb.callback.EvaluationMonitor(show_stdv=True)],
#                )

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Clean

# COMMAND ----------

import xgboost as xgb


# COMMAND ----------

model = xgb.XGBClassifier(max_depth= 2, 
        n_estimators=1000,
         eta= 0.01, 
         objective="multi:softmax",
         eval_metric="merror",
         seed= 0,
         num_class= len(labels_num))

# COMMAND ----------

model = model.fit(X_train, labels_train)

# COMMAND ----------

predictions = model.predict(X_test)

# COMMAND ----------

labels_num.keys()

# COMMAND ----------

 from sklearn.metrics import classification_report
 print(classification_report(predictions, labels_test , target_names=labels_num.keys()))

# COMMAND ----------

pd.DataFrame(report).transpose()

# COMMAND ----------

report = classification_report(predictions, labels_test , target_names=labels_num.keys(), output_dict=True)

display(pd.DataFrame(report).transpose().reset_index())

# COMMAND ----------

