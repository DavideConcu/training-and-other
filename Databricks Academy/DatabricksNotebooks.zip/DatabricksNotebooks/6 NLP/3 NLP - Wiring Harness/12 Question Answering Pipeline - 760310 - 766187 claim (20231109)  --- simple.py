# Databricks notebook source
# MAGIC %pip install transformers torch  --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

#specs
path = "/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/"
filename = "760310___766187_claim__20231109_sheet766187_CLEANED_TRANSLATED"

# COMMAND ----------

import pandas as pd

#load df
df = pd.read_csv(path + filename + ".csv")

# COMMAND ----------

#aggiunta del commento totale (per dare più info al classificatore)

#drop dei missing in uno dei translate
df = df.dropna(subset=["complaint_translated", "cause_translated", "correction_translated"]).reset_index(drop=True)

df["allCommentTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"] + ". CORRECTION: " + x["correction_translated"], axis = 1)

df["ComplaintAndCauseTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"], axis = 1)

for i in df.index:
    for col in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]:
        if type(df.loc[i, col])==str:
            df.loc[i, col] = df.loc[i, col].lower()

import re
for commentVar in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]: 
    df[commentVar] = df.apply(lambda x: re.sub("trl", "trailer", x[commentVar]), axis =1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Con Pandas 

# COMMAND ----------

from transformers import pipeline

question_answerer = pipeline("question-answering")

# COMMAND ----------

#inizializzare il dataframe
reset=False
if reset:
    predicted_df = pd.DataFrame()
    predicted_df.to_csv(path + filename  + "_questionAnswered.csv")  


try: 
    predicted_df = pd.read_csv(path + filename + "_questionAnswered.csv")
except:
    predicted_df = pd.DataFrame()
    predicted_df.to_csv(path + filename  + "_questionAnswered.csv")

#righe da tradurre
index = [riga for riga in df.index if riga not in predicted_df.index]

# COMMAND ----------

#apply to df

#qual'è la lamentela?
questionComplaint = "what is the problem?"
#qual'è la ragione del guasto?
questionCause = "what is the main reason that caused the fault?"
#qual'è la ragione del guasto?
questionCorrection = "how was fixed?"
#qual'è il componente difettoso?
questionDefectiveComponent = "which is the main defective component?"

varsAndQuests = zip(["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated"], 
                    [questionComplaint, questionCause , questionCorrection, questionDefectiveComponent])

# COMMAND ----------

count = 0
for riga in index:
    print(riga)
    for commentVar, quest in zip(["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated"], 
                                 [questionComplaint, questionCause , questionCorrection, questionDefectiveComponent]):
        try: 
            text = df.loc[riga, commentVar]
            answ = question_answerer(context=text, question=quest)["answer"]       
            df.loc[riga, commentVar+"_predicted"] = answ

            print(f"TEXT: {text} - - - ANSWER: {answ}")
            print("done\n")

        except:
            raise
            print("!!!!!!!!!!!!SOMETHING WENT WRONG!!!!!!!!!!!!")
            predicted_df.to_csv(path + filename + "_questionAnswered.csv", index=False)
            raise

    count+=1
    if count == 100:
        print("100 rows appended, riga: ",riga)
        predicted_df.to_csv(path + filename + "_questionAnswered.csv", index=False)
        count=0

    #append a finalDf
    predicted_df = pd.concat([predicted_df, df.loc[riga:riga, :]], axis = 0)


print("!!!DONE!!!")
predicted_df.to_csv(path + filename + "_questionAnswered.csv", index=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Vedere i risultati

# COMMAND ----------

import pandas as pd

df = pd.read_csv(path + filename + "_questionAnswered.csv")

# COMMAND ----------

df

# COMMAND ----------

