# Databricks notebook source
# MAGIC %md
# MAGIC ## Install Dependencies

# COMMAND ----------

# MAGIC %pip install wordcloud  --upgrade Pillow --upgrade pip

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Load File

# COMMAND ----------

import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_Cleaned_Translated_QuestionAnswering.csv")

df = df.loc[:, ["allCommentTranslated", "complaint_predict", "defective_component_predict", "fault_reason_predict", "correction_predict"]]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleaning

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## WordClouds

# COMMAND ----------

papers = df.copy()

var = "fault_reason_predict"

# Import the wordcloud library
import matplotlib.pyplot as plt
from wordcloud import WordCloud

# Join the different processed titles together.
long_string = ','.join(list(papers[var].values))

# Create a WordCloud object
wordcloud = WordCloud(
                    scale=10
                     ,background_color="white"
                     ,random_state=1 # Make sure the output is always the same for the same input
                     ,colormap="inferno")

# Generate a word cloud
wordcloud.generate(long_string)

# Visualize the word cloud
wordcloud

# Display the generated image the matplotlib way:
plt.figure(figsize=(10,10))
plt.axis("off")
plt.imshow(wordcloud, interpolation='bilinear')


# COMMAND ----------

papers = df.copy()

var = "defective_component_predict"

# Import the wordcloud library
import matplotlib.pyplot as plt
from wordcloud import WordCloud

# Join the different processed titles together.
long_string = ','.join(list(papers[var].values))

# Create a WordCloud object
wordcloud = WordCloud(
                    scale=10
                     ,background_color="white"
                     ,random_state=1 # Make sure the output is always the same for the same input
                     ,colormap="inferno")

# Generate a word cloud
wordcloud.generate(long_string)

# Visualize the word cloud
wordcloud

# Display the generated image the matplotlib way:
plt.figure(figsize=(10,10))
plt.axis("off")
plt.imshow(wordcloud, interpolation='bilinear')


# COMMAND ----------

papers = df.copy()

var = "complaint_predict"

# Import the wordcloud library
import matplotlib.pyplot as plt
from wordcloud import WordCloud

# Join the different processed titles together.
long_string = ','.join(list(papers[var].values))

# Create a WordCloud object
wordcloud = WordCloud(
                    scale=10
                     ,background_color="white"
                     ,random_state=1 # Make sure the output is always the same for the same input
                     ,colormap="inferno")
# Generate a word cloud
wordcloud.generate(long_string)

# Visualize the word cloud
wordcloud

# Display the generated image the matplotlib way:
plt.figure(figsize=(10,10))
plt.axis("off")
plt.imshow(wordcloud, interpolation='bilinear')


# COMMAND ----------

papers = df.copy()

var = "correction_predict"

# Import the wordcloud library
import matplotlib.pyplot as plt
from wordcloud import WordCloud

# Join the different processed titles together.
long_string = ','.join(list(papers[var].values))

# Create a WordCloud object
wordcloud = WordCloud(
                    scale=10
                     ,background_color="white"
                     ,random_state=1 # Make sure the output is always the same for the same input
                     ,colormap="inferno")

# Generate a word cloud
wordcloud.generate(long_string)

# Visualize the word cloud
wordcloud

# Display the generated image the matplotlib way:
plt.figure(figsize=(10,10))
plt.axis("off")
plt.imshow(wordcloud, interpolation='bilinear')


# COMMAND ----------

