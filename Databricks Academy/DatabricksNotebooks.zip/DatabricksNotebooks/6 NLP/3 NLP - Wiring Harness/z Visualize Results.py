# Databricks notebook source
# MAGIC %md
# MAGIC ## Question Answering

# COMMAND ----------

# MAGIC %pip install regex

# COMMAND ----------

import pandas as pd 

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/760310___766187_claim__20231109_sheet766187_CLEANED_TRANSLATED_questionAnswered.csv")

# COMMAND ----------

for i in df.index:
    print(f"TEXT: {df.loc[i, 'allCommentTranslated']} ---> PRED: {df.loc[i , 'cause_translated_predicted']}\n")

# COMMAND ----------

df = df.drop('Unnamed: 0',axis=1)

# COMMAND ----------


import regex as re
new_col_names =[  re.sub("[ ,;{}()\n\t=]","", x) for x in df.columns]

# COMMAND ----------

df.columns = new_col_names

# COMMAND ----------

sdf = spark.createDataFrame(df)

# COMMAND ----------

sdf.write.saveAsTable("reliab.20231204_NLP_BCM_sheet766187_questionAnswering")

# COMMAND ----------

