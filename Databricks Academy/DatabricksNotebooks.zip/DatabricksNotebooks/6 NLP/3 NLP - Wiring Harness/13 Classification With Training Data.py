# Databricks notebook source
# MAGIC %pip install xgboost nltk transformers datasets torch  --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Classify With Training

# COMMAND ----------

path = "/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/"
filename = "training_cleaned_766187_splitted.xlsx_TRANSLATED"
extension = ".csv"

# COMMAND ----------

import pandas as pd

if extension == ".csv": 
    df = pd.read_csv(path + filename + extension)
elif extension == ".xlsx":
    df = pd.read_excel(path + filename + extension) 


# COMMAND ----------

#add complete comment
df["complete_comment_translated"] = df["complaint_translated"] + ". " + df["cause_translated"] + ". " + df["correction_translated"] + "."
df["complete_comment_translated"] = df["complete_comment_translated"].apply(lambda x: x.lower().replace("rekl", "")) 

# COMMAND ----------

df.groupby("target").target.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## PreProcess 

# COMMAND ----------

import nltk
nltk.download('stopwords')
nltk.download('wordnet')

# COMMAND ----------

# importing the relevant packages
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import re
# Pre Processing
stop_words = stopwords.words('english') # creates a list of English stop words
wnl = WordNetLemmatizer() # I used lemmatizing instead of stemming
def preprocess(text_column):
    """
    Function:    This function aims to remove links, special 
                 characters, symbols, stop words and thereafter 
                 lemmatise each word in the sentence to transform 
                 the dataset into something more usable for a 
                 machine learning model.
    Input:       A text column
    Returns:     A text column (but transformed)
    """
    new_review = []
    for review in text_column:
        # for every sentence, we perform the necessary pre-processing
        text = re.sub("@\S+|https?:\S+|http?:\S|[^A-Za-z0-9]+", 
                        ' ', 
                        str(review).lower()).strip()
        text = [wnl.lemmatize(i) for i in text.split(' ') if i not in stop_words]
        new_review.append(' '.join(text)) 

    return new_review


df['complete_comment_translated_cleaned'] = preprocess(df['complete_comment_translated'])

# COMMAND ----------

# MAGIC %md 
# MAGIC ## XGBoost Classification

# COMMAND ----------

#assign a numerical label to text
labels_swapped = dict(enumerate(set(df.target)))
labels_num = {v: k for k, v in labels_swapped.items()}

#apply new labels
df["target_num"] = df["target"].apply(lambda x: labels_num[x])

print(labels_num)

# COMMAND ----------

#testo e labels
texts = df["complete_comment_translated_cleaned"].to_list()
labels = df["target_num"].to_list()

# COMMAND ----------

import xgboost as xgb
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Text data and labels
texts = texts
labels = labels

# Split the data into train and test sets
texts_train, texts_test, labels_train, labels_test = train_test_split(texts, labels, test_size=0.2, random_state=0)

# Convert text data into numerical features using TF-IDF
vectorizer = TfidfVectorizer()
X_train = vectorizer.fit_transform(texts_train)
X_test = vectorizer.transform(texts_test)

# Train the XGBoost model
model = xgb.XGBClassifier(max_depth=10, learning_rate=0.01, n_estimators=500, objective='binary:logistic', booster='gbtree')
model.fit(X_train, labels_train)

# Make predictions on the test set
predictions = model.predict(X_test)

# Evaluate the model performance
accuracy = accuracy_score(labels_test, predictions)
print("Accuracy: {:.2f}%".format(accuracy * 100))

# COMMAND ----------

from sklearn.metrics import f1_score

# Compute f1 score for the predictions on the test set for each category
f1_score_0 = f1_score(labels_test, predictions, average='macro', labels=[0])
f1_score_1 = f1_score(labels_test, predictions, average='macro', labels=[1])
f1_score_2 = f1_score(labels_test, predictions, average='macro', labels=[2])
f1_score_3 = f1_score(labels_test, predictions, average='macro', labels=[3])

print("F1 score for class 0: {:.2f}%".format(f1_score_0 * 100))
print("F1 score for class 1: {:.2f}%".format(f1_score_1 * 100))
print("F1 score for class 2: {:.2f}%".format(f1_score_2 * 100))
print("F1 score for class 3: {:.2f}%".format(f1_score_3 * 100))


# COMMAND ----------

 from sklearn.metrics import classification_report
 print(classification_report(predictions, labels_test))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova con XgBoost

# COMMAND ----------

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import linear_model
import numpy as np
from sklearn.model_selection import train_test_split
import scipy
from sklearn.metrics import log_loss
import xgboost as xgb
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score
import seaborn as sns
import matplotlib.pyplot as plt

# COMMAND ----------

count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
count_vect.fit(df["complete_comment_translated_cleaned"].unique())

train_trans = count_vect.transform(df['complete_comment_translated_cleaned'].values)
labels = df['target_num'].values
X = train_trans
y = labels
X_train,X_valid,y_train,y_valid = train_test_split(X,y, test_size = 0.33, random_state = 42)
xgb_model = xgb.XGBClassifier(max_depth=50, n_estimators=80, learning_rate=0.1, colsample_bytree=.7, gamma=0, reg_alpha=4, objective='binary:logistic', eta=0.3, silent=1, subsample=0.8).fit(X_train, y_train) 
xgb_prediction = xgb_model.predict(X_valid)


# COMMAND ----------

from sklearn.metrics import f1_score, classification_report, accuracy_score

print('training score:', f1_score(y_train, xgb_model.predict(X_train), average='macro'))
print('validation score:', f1_score(y_valid, xgb_model.predict(X_valid), average='macro'))
print(classification_report(y_valid, xgb_prediction))

# COMMAND ----------

#migliorabile

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC # Model Selection for Classification

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cleaning 

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Bayes

# COMMAND ----------

my_tags = [key for key in labels_num.keys()]

# COMMAND ----------

X = df["complete_comment_translated_cleaned"]
y = df["target_num"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state = 42)

# COMMAND ----------

from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfTransformer

nb = Pipeline([('vect', CountVectorizer()),
               ('tfidf', TfidfTransformer()),
               ('clf', MultinomialNB()),
              ])
nb.fit(X_train, y_train)

# COMMAND ----------

# MAGIC %%time
# MAGIC from sklearn.metrics import classification_report
# MAGIC y_pred = nb.predict(X_test)
# MAGIC
# MAGIC print('accuracy %s' % accuracy_score(y_pred, y_test))
# MAGIC print(classification_report(y_test, y_pred,target_names=my_tags, zero_division=True))

# COMMAND ----------

# MAGIC %md
# MAGIC ### SGD Class

# COMMAND ----------

from sklearn.linear_model import SGDClassifier

sgd = Pipeline([('vect', CountVectorizer()),
                ('tfidf', TfidfTransformer()),
                ('clf', SGDClassifier(loss='hinge', penalty='l2',alpha=1e-3, random_state=42, max_iter=5, tol=None)),
               ])
sgd.fit(X_train, y_train)

# COMMAND ----------

# MAGIC %%time
# MAGIC
# MAGIC y_pred = sgd.predict(X_test)
# MAGIC
# MAGIC print('accuracy %s' % accuracy_score(y_pred, y_test))
# MAGIC print(classification_report(y_test, y_pred,target_names=my_tags))

# COMMAND ----------

# MAGIC %md
# MAGIC ## HF Dataset

# COMMAND ----------

from datasets import Dataset

# COMMAND ----------

from transformers import DistilBertTokenizer, BertForSequenceClassification

# Load the pre-trained tokenizer
tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')

# Load the pre-trained model for sequence classification
num_labels = len(sentiments)
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=num_labels)

# COMMAND ----------

texts = ["I loved the movie. It was great!",
         "The food was terrible.",
         "The weather is okay."]
sentiments = ["positive", "negative", "neutral"]

# COMMAND ----------

# Tokenize the text samples
encoded_texts = tokenizer(texts, padding=True, truncation=True, return_tensors='pt')

# Extract the input IDs and attention masks
input_ids = encoded_texts['input_ids']
attention_mask = encoded_texts['attention_mask']

# Convert the sentiment labels to numerical form
sentiment_labels = [sentiments.index(sentiment) for sentiment in sentiments]
sentiment_labels = torch.tensor(sentiment_labels).view(-1)

# COMMAND ----------

import torch.nn as nn

# Add a custom classification head on top of the pre-trained model
num_classes = len(set(sentiment_labels))
classification_head = nn.Linear(model.config.hidden_size, num_classes)

# Replace the pre-trained model's classification head with our custom head
model.classifier = classification_head

# COMMAND ----------

import torch
import torch.optim as optim

# Define the optimizer and loss function
optimizer = optim.AdamW(model.parameters(), lr=2e-5)
criterion = nn.CrossEntropyLoss()

# Fine-tune the model
num_epochs = 3
for epoch in range(num_epochs):
    optimizer.zero_grad()
    outputs = model(input_ids, attention_mask=attention_mask, labels=torch.tensor(sentiment_labels))
    loss = outputs.loss
    loss.backward()
    optimizer.step()

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Fine tuning with instructions

# COMMAND ----------

from transformers import GPT2Tokenizer, GPT2ForSequenceClassification

# Load the pre-trained tokenizer
tokenizer = GPT2Tokenizer.from_pretrained('gpt2')

# Load the pre-trained model for sequence classification
model = GPT2ForSequenceClassification.from_pretrained('gpt2')

# COMMAND ----------

texts = ["I loved the movie. It was great!",
         "The food was terrible.",
         "The weather is okay."]
sentiments = ["positive", "negative", "neutral"]
instructions = ["Analyze the sentiment of the text and identify if it is positive.",
                "Analyze the sentiment of the text and identify if it is negative.",
                "Analyze the sentiment of the text and identify if it is neutral."]

# COMMAND ----------

# Tokenize the texts, sentiments, and instructions
tokenizer.add_special_tokens({'pad_token': '[PAD]'})
encoded_texts = tokenizer(texts, padding=True, truncation=True, return_tensors='pt')
encoded_instructions = tokenizer(instructions, padding=True, truncation=True, return_tensors='pt')

# Extract input IDs, attention masks, and instruction IDs
input_ids = encoded_texts['input_ids']
attention_mask = encoded_texts['attention_mask']
instruction_ids = encoded_instructions['input_ids']

# COMMAND ----------

import torch

# Concatenate instruction IDs with input IDs and adjust attention mask
input_ids = torch.cat([instruction_ids, input_ids], dim=1)
attention_mask = torch.cat([torch.ones_like(instruction_ids), attention_mask], dim=1)

# COMMAND ----------

import torch.optim as optim

# Define the optimizer and loss function
optimizer = optim.AdamW(model.parameters(), lr=2e-5)
criterion = torch.nn.CrossEntropyLoss()

# Fine-tune the model
num_epochs = 3
for epoch in range(num_epochs):
    optimizer.zero_grad()
    outputs = model(input_ids, attention_mask=attention_mask, labels=torch.tensor(sentiments))
    loss = outputs.loss
    loss.backward()
    optimizer.step()

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Provare a mettere insieme le info

# COMMAND ----------

from transformers import DistilBertTokenizer, BertForSequenceClassification

# Load the pre-trained tokenizer
tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')

# Load the pre-trained model for sequence classification
num_labels = len(sentiments)
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=num_labels)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Prova da Notebook HF 
# MAGIC "Fine-tuning BERT (and friends) for multi-label text classification.ipynb"

# COMMAND ----------

# MAGIC %pip install --upgrade pip

# COMMAND ----------

# MAGIC %pip install -q transformers[torch] torch datasets wandb

# COMMAND ----------

!pip install accelerate -U

# COMMAND ----------

# MAGIC %pip install transformers datasets torch  --upgrade numpy

# COMMAND ----------

from datasets import load_dataset

dataset = load_dataset("sem_eval_2018_task_1", "subtask5.english")

# COMMAND ----------

dataset

# COMMAND ----------

labels = [label for label in dataset['train'].features.keys() if label not in ['ID', 'Tweet']]
id2label = {idx:label for idx, label in enumerate(labels)}
label2id = {label:idx for idx, label in enumerate(labels)}
labels

# COMMAND ----------

from transformers import AutoTokenizer
import numpy as np

tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

def preprocess_data(examples):
  # take a batch of texts
  text = examples["Tweet"]
  # encode them
  encoding = tokenizer(text, padding="max_length", truncation=True, max_length=128)
  # add labels
  labels_batch = {k: examples[k] for k in examples.keys() if k in labels}
  # create numpy array of shape (batch_size, num_labels)
  labels_matrix = np.zeros((len(text), len(labels)))
  # fill numpy array
  for idx, label in enumerate(labels):
    labels_matrix[:, idx] = labels_batch[label]

  encoding["labels"] = labels_matrix.tolist()
  
  return encoding

# COMMAND ----------

encoded_dataset = dataset.map(preprocess_data, batched=True, remove_columns=dataset['train'].column_names)

# COMMAND ----------

example = encoded_dataset['train'][0]
print(example.keys())

# COMMAND ----------

tokenizer.decode(example['input_ids'])

# COMMAND ----------

encoded_dataset.set_format("torch")

# COMMAND ----------

from transformers import AutoModelForSequenceClassification

model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased", 
                                                           problem_type="multi_label_classification", 
                                                           num_labels=len(labels),
                                                           id2label=id2label,
                                                           label2id=label2id)

# COMMAND ----------

batch_size = 8
metric_name = "f1"

# COMMAND ----------

from transformers import TrainingArguments, Trainer

args = TrainingArguments(
    f"/tmp/bert-finetuned-sem_eval-english",
    evaluation_strategy = "epoch",
    save_strategy = "epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=batch_size,
    per_device_eval_batch_size=batch_size,
    num_train_epochs=5,
    weight_decay=0.01,
    load_best_model_at_end=True,
    metric_for_best_model=metric_name,
    #push_to_hub=True,
)

# COMMAND ----------

from sklearn.metrics import f1_score, roc_auc_score, accuracy_score
from transformers import EvalPrediction
import torch
    
# source: https://jesusleal.io/2021/04/21/Longformer-multilabel-classification/
def multi_label_metrics(predictions, labels, threshold=0.5):
    # first, apply sigmoid on predictions which are of shape (batch_size, num_labels)
    sigmoid = torch.nn.Sigmoid()
    probs = sigmoid(torch.Tensor(predictions))
    # next, use threshold to turn them into integer predictions
    y_pred = np.zeros(probs.shape)
    y_pred[np.where(probs >= threshold)] = 1
    # finally, compute metrics
    y_true = labels
    f1_micro_average = f1_score(y_true=y_true, y_pred=y_pred, average='micro')
    roc_auc = roc_auc_score(y_true, y_pred, average = 'micro')
    accuracy = accuracy_score(y_true, y_pred)
    # return as dictionary
    metrics = {'f1': f1_micro_average,
               'roc_auc': roc_auc,
               'accuracy': accuracy}
    return metrics

def compute_metrics(p: EvalPrediction):
    preds = p.predictions[0] if isinstance(p.predictions, 
            tuple) else p.predictions
    result = multi_label_metrics(
        predictions=preds, 
        labels=p.label_ids)
    return result

# COMMAND ----------

encoded_dataset['train'][0]['labels'].type()

# COMMAND ----------

encoded_dataset['train']['input_ids'][0]

# COMMAND ----------

#forward pass
outputs = model(input_ids=encoded_dataset['train']['input_ids'][0].unsqueeze(0), labels=encoded_dataset['train'][0]['labels'].unsqueeze(0))
outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configure WandB

# COMMAND ----------

import wandb

my_api_key = dbutils.secrets.get(scope="secretscopedc", key="wandb")
wandb.login(key=my_api_key)

# COMMAND ----------

wandb.init(project="my-project-iundev", save_code=False, dir="/tmp")

# COMMAND ----------

import os

#These will not be necessary in the future
#os.environ["WANDB_ENTITY"] = "my-entity"
#os.environ["WANDB_PROJECT"] = "my-project-that-exists"

# COMMAND ----------

#os.environ["WANDB_PROJECT"] = "my-amazing-iuve"  # name your W&B project
#os.environ["WANDB_LOG_MODEL"] = "checkpoint"

# COMMAND ----------

# MAGIC %md
# MAGIC # Training

# COMMAND ----------

trainer = Trainer(
    model,
    args,
    train_dataset=encoded_dataset["test"],
    eval_dataset=encoded_dataset["validation"],
    tokenizer=tokenizer,
    compute_metrics=compute_metrics
)

# COMMAND ----------

trainer.train()

# COMMAND ----------



# COMMAND ----------

from accelerate import Accelerator

# Initialize the accelerator. We will let the accelerator handle device placement for us in this example. 
accelerator = Accelerator()

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Prova Classification

# COMMAND ----------

# MAGIC %pip install transformers datasets evaluate accelerate torch  --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Login To HuggingFace

# COMMAND ----------

!pip install huggingface-hub==0.14.1
!huggingface-cli login --token hf_yourtokentext

# COMMAND ----------

dbutils.widgets.text("huggingface_token", "", "huggingface_token")

# COMMAND ----------

huggingface_token = dbutils.widgets.get("huggingface_token")


# COMMAND ----------

!huggingface-cli login --token $huggingface_token

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Login to WandB

# COMMAND ----------

import wandb

my_api_key = dbutils.secrets.get(scope="secretscopedc", key="wandb")
wandb.login(key=my_api_key)

# COMMAND ----------

wandb.init(project="my-project-iundev", save_code=False, dir="/tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova Flow

# COMMAND ----------

from datasets import load_dataset

imdb = load_dataset("imdb")

# COMMAND ----------

imdb["train"]

# COMMAND ----------

from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")

# COMMAND ----------

def preprocess_function(examples):
    return tokenizer(examples["text"], truncation=True)

# COMMAND ----------

tokenized_imdb = imdb.map(preprocess_function, batched=True)

# COMMAND ----------

from transformers import DataCollatorWithPadding

data_collator = DataCollatorWithPadding(tokenizer=tokenizer)

# COMMAND ----------

import evaluate

accuracy = evaluate.load("accuracy")

# COMMAND ----------

import numpy as np


def compute_metrics(eval_pred):
    predictions, labels = eval_pred
    predictions = np.argmax(predictions, axis=1)
    return accuracy.compute(predictions=predictions, references=labels)

# COMMAND ----------

id2label = {0: "NEGATIVE", 1: "POSITIVE"}
label2id = {"NEGATIVE": 0, "POSITIVE": 1}

# COMMAND ----------

from transformers import AutoModelForSequenceClassification, TrainingArguments, Trainer

model = AutoModelForSequenceClassification.from_pretrained(
    "distilbert-base-uncased", num_labels=2, id2label=id2label, label2id=label2id
)

# COMMAND ----------

training_args = TrainingArguments(
    output_dir="/tmp/prova_NLP",
    learning_rate=2e-5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs=2,
    weight_decay=0.01,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
    push_to_hub=True,
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_imdb["train"],
    eval_dataset=tokenized_imdb["test"],
    tokenizer=tokenizer,
    data_collator=data_collator,
    compute_metrics=compute_metrics,
)

trainer.train()

# COMMAND ----------

