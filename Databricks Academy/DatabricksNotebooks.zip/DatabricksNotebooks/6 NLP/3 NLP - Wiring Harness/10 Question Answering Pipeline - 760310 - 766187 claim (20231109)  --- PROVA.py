# Databricks notebook source
# MAGIC %pip install transformers torch  --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

#specs
path = "/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/"
filename = "760310___766187_claim__20231109__CLEANED_TRANSLATED"

# COMMAND ----------

import pandas as pd

#load df
df = pd.read_csv(path + filename + ".csv").loc[0:100]


# COMMAND ----------

#aggiunta del commento totale (per dare più info al classificatore)

#drop dei missing in uno dei translate
df = df.dropna(subset=["complaint_translated", "cause_translated", "correction_translated"]).reset_index(drop=True)

df["allCommentTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"] + ". CORRECTION: " + x["correction_translated"], axis = 1)

df["ComplaintAndCauseTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"], axis = 1)

for i in df.index:
    for col in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]:
        if type(df.loc[i, col])==str:
            df.loc[i, col] = df.loc[i, col].lower()

import re
for commentVar in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]: 
    df[commentVar] = df.apply(lambda x: re.sub("trl", "trailer", x[commentVar]), axis =1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova ricerca causa

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggiungere colonne

# COMMAND ----------

from transformers import pipeline

question_answerer = pipeline("question-answering")

def answer(question: str, text: str) -> str:
    """function that ask question to text and return answer"""
    answ = question_answerer(
                question = question,
                context = text
                )["answer"]
    
    print(f"TEXT: {text} - - - ANSWER: {answ}")  

    return answ
    



# COMMAND ----------

# MAGIC %md
# MAGIC ## Complaint

# COMMAND ----------

#apply to df

#qual'è la lamentela?
question = "what is the problem?"

df["complaint_predict"] = df.apply(lambda x: answer(question = question, text = x["complaint_translated"] ), axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cause

# COMMAND ----------

#apply to df

#qual'è il componente difettoso?
question = "which is the main defective component?"

df["defective_component_predict"] = df.apply(lambda x: answer(question = question, text = x["cause_translated"] ), axis = 1)

# COMMAND ----------

#apply to df

#qual'è la ragione del guasto?
question = "what is the main reason that caused the fault??"

df["fault_reason_predict"] = df.apply(lambda x: answer(question = question, text = x["cause_translated"] ), axis = 1)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Correction

# COMMAND ----------

#apply to df

#qual'è la ragione del guasto?
question = "How have they fixed the issue?"

df["correction_predict"] = df.apply(lambda x: answer(question = question, text = x["correction_translated"] ), axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare il df in csv e sul catalog

# COMMAND ----------

#df.to_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_Cleaned_Translated_QuestionAnswering.csv", index = False)

# COMMAND ----------

#cambio nome colonne
newColNames = [col.lower().replace(" ", "_").replace("\t", "").replace("\n", "") for col in df.columns]

df.columns = newColNames

# COMMAND ----------

#salvare il df come tabella sul catalog
dfSpark = spark.createDataFrame(df)

#change to True if not exists
toSave = False

#if toSave:
#    dfSpark.write.saveAsTable(path + filename + "_QuestionsAnswered")


# COMMAND ----------

# MAGIC %md 
# MAGIC ## Con UDF

# COMMAND ----------

question_an

# COMMAND ----------

from transformers import pipeline
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType

question_answerer = pipeline("question-answering")

@pandas_udf(StringType())
def answer(question, text):
    """function that ask question to text and return answer"""
    answ = question_answerer(
                question = question,
                context = text
                )["answer"]
    
    print(f"TEXT: {text} - - - ANSWER: {answ}")  

    return answ

# COMMAND ----------

dfSpark = spark.createDataFrame(df)

# COMMAND ----------

from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType, StructType, StructField


# COMMAND ----------

question_answerer = pipeline("question-answering")

# COMMAND ----------

dfSpark

# COMMAND ----------

textSample = df.loc[0:10, "cause_translated"].to_list()

# COMMAND ----------

pd.DataFrame(df.loc[0:10, "cause_translated"].apply(lambda x: question_answerer(context=x, question="who is broken?")["answer"]))

# COMMAND ----------

schema = StructType([
        StructField('answer', StringType())
])


@pandas_udf(schema)
def predict(text: pd.Series) -> pd.DataFrame:
    pred = text.apply(lambda x: question_answerer(context=x, question="what'up?")["answer"])
    res = pd.DataFrame(pred)
    res.columns=["answer"]
    return res

# COMMAND ----------

display(dfSpark.limit(10).select("*", predict("cause_translated").alias("prova")))

# COMMAND ----------

# MAGIC %md
# MAGIC #### prova2 - funziona ma non è possibile parallelizzare la pipeline

# COMMAND ----------

from pyspark.sql.types import StringType


@pandas_udf(StringType())
def predict2(text: pd.Series) -> pd.Series:
    pred = text.apply(lambda x: question_answerer(context=x, question="what'up?")["answer"])
    res = pd.Series(pred)
    return res

# COMMAND ----------

display(dfSpark.limit(10).select("*", predict2("cause_translated")))

# COMMAND ----------

