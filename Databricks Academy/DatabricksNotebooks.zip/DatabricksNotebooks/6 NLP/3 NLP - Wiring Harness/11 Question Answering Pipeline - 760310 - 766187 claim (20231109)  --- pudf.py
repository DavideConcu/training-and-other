# Databricks notebook source
# MAGIC %pip install transformers torch  --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

#specs
path = "/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/"
filename = "760310___766187_claim__20231109__CLEANED_TRANSLATED"

# COMMAND ----------

import pandas as pd

#load df
df = pd.read_csv(path + filename + ".csv").loc[0:100]

# COMMAND ----------

#aggiunta del commento totale (per dare più info al classificatore)

#drop dei missing in uno dei translate
df = df.dropna(subset=["complaint_translated", "cause_translated", "correction_translated"]).reset_index(drop=True)

df["allCommentTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"] + ". CORRECTION: " + x["correction_translated"], axis = 1)

df["ComplaintAndCauseTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"], axis = 1)

for i in df.index:
    for col in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]:
        if type(df.loc[i, col])==str:
            df.loc[i, col] = df.loc[i, col].lower()

import re
for commentVar in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]: 
    df[commentVar] = df.apply(lambda x: re.sub("trl", "trailer", x[commentVar]), axis =1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Con Pandas UDF

# COMMAND ----------

from transformers import pipeline

question_answerer = pipeline("question-answering")

# COMMAND ----------

#creare spark df
sdf = spark.createDataFrame(df)

# COMMAND ----------

#apply to df
#qual'è la lamentela?
questionComplaint = "what is the problem?"

#qual'è la ragione del guasto?
questionCause = "what is the main reason that caused the fault?"

#qual'è il componente difettoso?
questionDefectiveComponent = "which is the main defective component?"

#qual'è la ragione del guasto?
questionCorrection = "how was fixed?"

# COMMAND ----------

from pyspark.sql.types import StringType


@pandas_udf(StringType())
def predict2(text: pd.Series, quest:pd.Series) -> pd.Series:
    pred = text.apply(lambda x: question_answerer(context=x, question=quest[0])["answer"])
    res = pd.Series(pred)
    return res

# COMMAND ----------

sdf.withColumn("complaint")