# Databricks notebook source
# MAGIC %pip install transformers torch  --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_CLEANED_TRANSLATED.csv")

# COMMAND ----------

#FILTRARE PER PART NUMBER:
part_code = [5803030976,5803030980]

#split del file (tenere solo i 600)
originalDf = pd.read_excel("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023.xlsx")

#restrict
originalDf = originalDf.loc[originalDf["Causal Part Code"].isin(part_code), ["VP Code", "Chassis", "Claim Number"]]

#merge con df
#df = pd.merge(df, originalDf, on = ["VP Code", "Chassis", "Claim Number"], how="inner"
df = pd.merge(df, originalDf, on = ["VP Code", "Chassis", "Claim Number"], how="outer", indicator=True)
df = df.loc[df._merge=="left_only", :].drop("_merge",axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleaning

# COMMAND ----------

#aggiunta del commento totale (per dare più info al classificatore)
df["allCommentTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"] + ". CORRECTION: " + x["correction_translated"], axis = 1)

df["ComplaintAndCauseTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"], axis = 1)


# COMMAND ----------

import re
for commentVar in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]: 
    df[commentVar] = df.apply(lambda x: re.sub("trl", "trailer", x[commentVar]), axis =1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova Classificazione

# COMMAND ----------

from transformers import pipeline
import torch

# use the GPU if available
device = 0 if torch.cuda.is_available() else -1
classifier = pipeline("zero-shot-classification", device=device) 

# COMMAND ----------



# COMMAND ----------

#labels = [
#    "engine issue",
#    "AEBS issue",
#    "ABS issue", 
#    "ECU issue",  
#    "tyres issue",  
#    "defective contacts",
#    "edc issue",
#    "trailer issue",
#    "water infiltration",
#    "brakes lights issue",
#    "the engine warning light is on",
#    "the ABS warning light is on",
#    "the AEBS warning light is on",
#    "the ECU warning light is on",
#    "the EDC warning light is on",
#    "some warning light is on but it's neither engine nor abs nor ecu nor edc"
#    "stop light",
#    "other issue"]

# COMMAND ----------

labels = [
   "engine",
   "ABS",
   "AEBS", 
   "ECU",  
   "tyres",  
   "defective contacts",
   "EDC",
   "trailer warning light",
   "trailer light",
   "trailer short circuit",
   "towbar/towing",
   "ALM",
   "brakes",
   "gearbox",
   "airbag",
   "water infiltration",
   "other"]

# COMMAND ----------

for i in df.index:
    print(i)
    for commentVar in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated"]: 
        print(commentVar)   
        df.loc[i, commentVar+"_predicted"] = classifier(df.loc[i, commentVar], candidate_labels = labels)["labels"][0]
        print("done\n")

# COMMAND ----------

#df.to_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_CLEANED_TRANSLATED_600_predicted.csv")

#df.to_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_CLEANED_TRANSLATED_RemainingSample_predicted.csv")


# COMMAND ----------

import pandas as pd 

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_CLEANED_TRANSLATED_600_predicted.csv")

# COMMAND ----------



print(df.loc[riga, "complaint_translated"] + "  ------------> PREDICTED: " + df.loc[riga, "allCommentTranslated_predicted"])


# COMMAND ----------

print("ORIGINAL: " , df.loc[df["Market Repair Code"]=="DK", "cause"].iloc[0] + " ------------> TRANSLATED: " +  df.loc[df["Market Repair Code"]=="DK", "cause_translated"].iloc[0])

# COMMAND ----------

 classifier("today i was fired", candidate_labels = ["good", "bad", "neutral"])

# COMMAND ----------

