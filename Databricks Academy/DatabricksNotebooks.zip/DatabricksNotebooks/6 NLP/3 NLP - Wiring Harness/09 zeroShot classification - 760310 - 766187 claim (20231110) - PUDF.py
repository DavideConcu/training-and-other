# Databricks notebook source
# MAGIC %pip install transformers torch  --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

path = "/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/"
filename = "760310___766187_claim__20231109__CLEANED_TRANSLATED"

# COMMAND ----------

import pandas as pd

df = pd.read_csv(path + filename + ".csv")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleaning

# COMMAND ----------

#aggiunta del commento totale (per dare più info al classificatore)

#drop dei missing in uno dei translate
df = df.dropna(subset=["complaint_translated", "cause_translated", "correction_translated"]).reset_index(drop=True)

df["allCommentTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"] + ". CORRECTION: " + x["correction_translated"], axis = 1)

df["ComplaintAndCauseTranslated"] = df.apply(lambda x: "COMPLAINT: " + x["complaint_translated"] + ". CAUSE: " +  x["cause_translated"], axis = 1)

for i in df.index:
    for col in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]:
        if type(df.loc[i, col])==str:
            df.loc[i, col] = df.loc[i, col].lower()


# COMMAND ----------

import re
for commentVar in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]: 
    df[commentVar] = df.apply(lambda x: re.sub("trl", "trailer", x[commentVar]), axis =1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova Classificazione

# COMMAND ----------

from transformers import pipeline
import torch

# use the GPU if available
device = 0 if torch.cuda.is_available() else -1
classifier = pipeline("zero-shot-classification", device=device, multiclass=True) 

# COMMAND ----------

labels = [
   "Alternator,  Radio, Adblue, camera, ECM".lower(), 
   "Immobilizer, Vehicle does not start".lower(),
   "Window, fuses, Power supply, relay, defective contacts, internal error, short circuit, water".lower(),
   "Software update, doors, software correction, update BCM, automatic closing".lower(),  
   "Km or kilometers or mileage not correct, body, low efficency".lower()]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Zero Shot Classifier

# COMMAND ----------

#inizializzare il dataframe
reset_file = True
if reset_file:
    predicted_df = pd.DataFrame()
    predicted_df.to_csv(path + filename  + "_0shotPredicted.csv")    

try: 
    predicted_df = pd.read_csv(path + filename + "_0shotPredicted.csv")
except:
    predicted_df = pd.DataFrame()
    predicted_df.to_csv(path + filename  + "_0shotPredicted.csv")

#righe da tradurre
index = [riga for riga in df.index if riga not in predicted_df.index]

# COMMAND ----------

