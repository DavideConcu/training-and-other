# Databricks notebook source
# MAGIC   %pip install transformers

# COMMAND ----------

# MAGIC %pip install torch

# COMMAND ----------

# MAGIC %pip install --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Primo File

# COMMAND ----------

import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/20230712_translateAll.csv")

df = df.loc[pd.isnull(df["ComplaintTranslate"])==False]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare Classifier

# COMMAND ----------

from transformers import pipeline
import torch
# use the GPU if available
device = 0 if torch.cuda.is_available() else -1
zeroShotClassifier = pipeline("zero-shot-classification", device=device) 

# COMMAND ----------

labels = ['TPMS',
 'Immobilizer',
 'Gearbox',
 'Lack of power',
 'Hand Brake',
 'Ad-blue',
 'Hill hold',
 'Immobilizer',
 'Ground Point',
 'Chassis loom',
 'ABS',
 'EPB',
 'Park brake',
 'Unconclusive',
 'Trailer',
 'Engine power cuts',
 'Bulb',
 "the Vehicle doesn't start",
 'Air Bag',
 'Oil light',
 'Heater Fan',
 'Horn',
 'Temp. Sensor',
 'Gearbox',
 'Aebs',
 'EML (Engine)',
 'Limp MODE',
 'Brake',
 'Expansion module',
 'Plate light',
 'Connector',
 'EPS',
 'Side Marker',
 'Warning Light on DASH',
 'Headlamp',
 'PAS Ecu - EPS',
 'Radio',
 'Rear lights']

# COMMAND ----------

import numpy as np

prova = zeroShotClassifier(df.loc[3, "ComplaintTranslate"] , candidate_labels=labels)

# COMMAND ----------

prova["labels"][0]

# COMMAND ----------

#prova
df.loc[:, "category"] = df.loc[:, "ComplaintTranslate"].apply(lambda x: zeroShotClassifier(x, candidate_labels=labels)["labels"][0])

# COMMAND ----------

df

# COMMAND ----------

#df.to_csv("/dbfs/FileStore/tables/reliab/20230712_translateAll_zeroShotClassified.csv")

# COMMAND ----------

import pandas as pd
df = pd.read_csv("/dbfs/FileStore/tables/reliab/20230712_translateAll_zeroShotClassified.csv")

# COMMAND ----------

display(spark.createDataFrame(df))

# COMMAND ----------

