# Databricks notebook source
# MAGIC %pip install transformers torch  --upgrade numpy

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_CLEANED_TRANSLATED_600_predicted.csv")


# COMMAND ----------

import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_CLEANED_TRANSLATED.csv")


#FILTRARE PER PART NUMBER:
part_code = [5803030976,5803030980]

#split del file (tenere solo i 600)
originalDf = pd.read_excel("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023.xlsx")

#restrict
originalDf = originalDf.loc[originalDf["Causal Part Code"].isin(part_code), ["VP Code", "Chassis", "Claim Number"]]

#merge con df
#df = pd.merge(df, originalDf, on = ["VP Code", "Chassis", "Claim Number"], how="inner"
df = pd.merge(df, originalDf, on = ["VP Code", "Chassis", "Claim Number"], how="outer", indicator=True)
df = df.loc[df._merge=="left_only", :].drop("_merge",axis = 1)



#aggiunta del commento totale (per dare più info al classificatore)
df["allCommentTranslated"] = df.apply(lambda x:   x["complaint_translated"] + ". " +  x["cause_translated"] + ". " + x["correction_translated"], axis = 1)

df["ComplaintAndCauseTranslated"] = df.apply(lambda x:   x["complaint_translated"] + ". " +  x["cause_translated"], axis = 1)



import re
for commentVar in ["complaint_translated", "cause_translated", "correction_translated", "allCommentTranslated", "ComplaintAndCauseTranslated"]: 
    df[commentVar] = df.apply(lambda x: re.sub("trl", "trailer", x[commentVar]), axis =1)

# COMMAND ----------

from transformers import pipeline

question_answerer = pipeline("question-answering")
question_answerer(
    question = "what is the root cause of the fault?",
    context = "Electrical defect in the socket due to water ingress"
)

# COMMAND ----------

from transformers import pipeline

question_answerer = pipeline("question-answering")
question_answerer(
    question = "where is the fault and what component is faulty?",
    context = "Electrical defect in the socket due to water ingress")

# COMMAND ----------

from transformers import pipeline

question_answerer = pipeline("question-answering")
question_answerer(
    question = "which are the root cause of the fault?",
    context = ": trailer control loom inop. : faulty control loom. : strip front end of vehicle to allow access to front loom plug and disconnect remove from vehicle fit new loom in place securing it and connecting all plugs up rebuild front end up and plug in udt clear all codes take vehicle on road test")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova ricerca causa

# COMMAND ----------

from transformers import pipeline

question_answerer = pipeline("question-answering")
def answer(x):
    
    print(x, " -- WHAT:", question_answerer(
        question = "which is the main defective component?",
        context = x
        )["answer"])     
    
    print( " - - - REASON:", question_answerer(
        question = "what is the main reason that caused the fault?",
        context = x
        )["answer"] )



# COMMAND ----------

df.columns

# COMMAND ----------

df  df.apply(lambda x: answer(x["cause_translated"]),axis=1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggiungere colonne

# COMMAND ----------

from transformers import pipeline

question_answerer = pipeline("question-answering")

def answer(question: str, text: str) -> str:
    """function that ask question to text and return answer"""
    answ = question_answerer(
                question = question,
                context = text
                )["answer"]
    
    print(f"TEXT: {text} - - - ANSWER: {answ}")  

    return answ
    



# COMMAND ----------

# MAGIC %md
# MAGIC ## Complaint

# COMMAND ----------

#apply to df

#qual'è la lamentela?
question = "which is the object of the complaint?"

df["complaint_predict"] = df.apply(lambda x: answer(question = question, text = x["complaint_translated"] ), axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cause

# COMMAND ----------

#apply to df

#qual'è il componente difettoso?
question = "which is the main defective component?"

df["defective_component_predict"] = df.apply(lambda x: answer(question = question, text = x["cause_translated"] ), axis = 1)

# COMMAND ----------

#apply to df

#qual'è la ragione del guasto?
question = "what is the main reason that caused the fault??"

df["fault_reason_predict"] = df.apply(lambda x: answer(question = question, text = x["cause_translated"] ), axis = 1)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Correction

# COMMAND ----------

#apply to df

#qual'è la ragione del guasto?
question = "How have they fixed the issue?"

df["correction_predict"] = df.apply(lambda x: answer(question = question, text = x["correction_translated"] ), axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare il df in csv e sul catalog

# COMMAND ----------

#df.to_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_Cleaned_Translated_QuestionAnswering.csv", index = False)

# COMMAND ----------

#cambio nome colonne
newColNames = [col.lower().replace(" ", "_").replace("\t", "").replace("\n", "") for col in df.columns]

df.columns = newColNames

# COMMAND ----------

#salvare il df come tabella sul catalog
dfSpark = spark.createDataFrame(df)

#change to True if not exists
toSave = False

if toSave:
    dfSpark.write.saveAsTable("reliab.20231108_NLPCavi_Estrazione_Failure_Presa_13_poli_07092023_Cleaned_Translated_QuestionAnswering")


# COMMAND ----------

