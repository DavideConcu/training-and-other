# Databricks notebook source
# MAGIC %pip install langdetect langid   

# COMMAND ----------

# MAGIC %sh
# MAGIC pip install transformers[sentencepiece] torch  --upgrade numpy
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Data

# COMMAND ----------

import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_CLEANED.csv")

commentVar = "Failure Comment"

mask = (pd.isnull(df.complaint ) == True) |( pd.isnull(df.cause ) == True) |( pd.isnull(df.correction ) == True) 

df.loc[mask, commentVar]


# COMMAND ----------

# MAGIC %md 
# MAGIC ## Language Detection -- non affidabile

# COMMAND ----------

df.columns

# COMMAND ----------

df.apply(lambda x: detect_limba(x["complaint"]), axis=1)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Prova con LangID --- NON AFFIDABILE

# COMMAND ----------

import langid

def langDetect(text):
    '''Function for detecting language with langid'''
    lang = langid.classify(text)[0]
    print(f"TEXT: {text} --- LANGUAGE: {lang}")
    return lang


# COMMAND ----------

df.apply(lambda x: langDetect(x[commentVar]), axis=1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## m2m

# COMMAND ----------

import sentencepiece

# COMMAND ----------

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

en_text = "Do not meddle in the affairs of wizards, for they are subtle and quick to anger."
fi_text = "Älä sekaannu velhojen asioihin, sillä ne ovat hienovaraisia ja nopeasti vihaisia."

tokenizer = AutoTokenizer.from_pretrained("facebook/mbart-large-50-many-to-many-mmt", src_lang="fi_FI")
model = AutoModelForSeq2SeqLM.from_pretrained("facebook/mbart-large-50-many-to-many-mmt")

# COMMAND ----------

