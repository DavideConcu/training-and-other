# Databricks notebook source
# MAGIC %pip install setfit torch

# COMMAND ----------

import pandas as pd

df = pd.read_excel("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/20230718_wiringHarness_Translated_manual_addressing.xlsx")

# COMMAND ----------

feature = "ComplaintTranslate"
target = "AREA OF COMPLAINT"

df = df.loc[pd.isnull(df[target])==False, [feature, target]]

# COMMAND ----------

# Load SetFit model from Hub
from datasets import load_dataset
from sentence_transformers.losses import CosineSimilarityLoss

from setfit import SetFitModel, SetFitTrainer

model = SetFitModel.from_pretrained("sentence-transformers/paraphrase-mpnet-base-v2")

# COMMAND ----------

dataset = load_dataset("SetFit/SentEval-CR")


train_ds = dataset["train"].shuffle(seed=42).select(range(8 * 2))
test_ds = dataset["test"]

# COMMAND ----------

from sklearn.model_selection import train_test_split

X_train,X_test,y_train,y_test = train_test_split(df[feature], df[target])

trainDf = pd.merge(X_train, y_train,left_index=True, right_index=True)
testDf = pd.merge(X_test, y_test,left_index=True, right_index=True)

trainDf.columns = ['text', 'label']
testDf.columns = ['text', 'label']


# COMMAND ----------

from datasets import Dataset, DatasetDict

hfDf = DatasetDict({"train" : Dataset.from_pandas(trainDf),"test": Dataset.from_pandas(testDf)})

train_ds = hfDf["train"]
test_ds = hfDf["test"]

# COMMAND ----------

from datasets import load_dataset
from sentence_transformers.losses import CosineSimilarityLoss

from setfit import SetFitModel, SetFitTrainer

# Load SetFit model from Hub
model = SetFitModel.from_pretrained("sentence-transformers/paraphrase-mpnet-base-v2")

# Create trainer
trainer = SetFitTrainer(
    model=model,
    train_dataset=train_ds,
    eval_dataset=test_ds,
    loss_class=CosineSimilarityLoss,
    batch_size=16,
    num_iterations=20, # Number of text pairs to generate for contrastive learning
    num_epochs=1 # Number of epochs to use for contrastive learning
)

# COMMAND ----------

# Train and evaluate!
trainer.train()
metrics = trainer.evaluate()

# COMMAND ----------

