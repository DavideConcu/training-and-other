# Databricks notebook source
# MAGIC %md
# MAGIC # Preparazione nuovo File 07092023

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
df = pd.read_excel("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023.xlsx")

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Basic Cleaning 

# COMMAND ----------

#keep only some vars
colsToKeep = ["VP Code", "Chassis", "Claim Number", 
            "Failure Code Description", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
df = df.loc[:, colsToKeep]

#failure comment to lowercase
commentVar = "Failure Comment"

#to lowercase
#df.loc[:, commentVar] = df.loc[:, commentVar].apply(lambda x: x.lower())
#remove tabs
df.loc[: , commentVar] = df.loc[: , commentVar].str.replace("\t", "")
#remove tabs
df.loc[: , commentVar] = df.loc[: , commentVar].str.replace("&", "and")
#strip
df.loc[: , commentVar] = df.loc[: , commentVar].str.strip()
#remove complaint
df.loc[: , commentVar] = df.loc[: , commentVar].apply(lambda x: " ".join(x.split(" ")[1:]))

# COMMAND ----------

#funzioni per pulire e separare 
import re

#clean
def basicCleaning(stringa):
   cleaned = None
   if type(stringa)==str:
      cleaned = re.sub("[\t]", "", stringa)
      cleaned = re.sub("[\-]", "", cleaned)
      cleaned = re.sub("[\/]", "", cleaned)
      cleaned = re.sub("[\d]", "", cleaned)
      cleaned = re.sub("[\&]", "and", cleaned)
      cleaned = re.sub("[\:]", "", cleaned)

   return cleaned

df.loc[: , commentVar] = df.loc[: , commentVar].apply(lambda x: basicCleaning(x))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Trovare Cause - Correction nelle varie Lingue

# COMMAND ----------

#numero claim per lingua
market = "Market Repair Code"

df.groupby(market)[commentVar].count().sort_values(ascending=False).head(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Trovare Cause - Correction nelle varie lingue

# COMMAND ----------

for language in [lang for lang in df.groupby(market)[commentVar].count().sort_values(ascending=False).index]:
    print(f"LANGUAGE: {language}: ", df.loc[df[market] == language, commentVar].iloc[0], "\n")

# COMMAND ----------

#elenco parole che separano causa e correzione
cause = ["grund", "cause", "oorzak", "oorzaak", "cprz", "causa" , "årsak", "årsag", "orsak", "příč"]
correction = ["correction", "solution", "correctie", "korecta", "correzione", "korrectur", "correcao", "solucion" , "korreksjon", "rettelse", "ändring", "oprava",]


# COMMAND ----------

# MAGIC %md
# MAGIC ## Pattern Complaint - Cause - Correction

# COMMAND ----------

#pattern Complaint
patternComplaint = ".*?("
for causa in cause[0:-1]:
    patternComplaint += f"(?={causa})|"
    
patternComplaint += f"(?={cause[-1]}))"

# COMMAND ----------

#pattern Cause
patternCause = "("
for causa in cause[0:-1]:
    patternCause += f"(?<={causa})|"

patternCause += f"(?<={cause[-1]}))"

patternCause += ".*?(?="
for correzione in correction[0:-1]:
    patternCause += f"{correzione}|"

patternCause += f"{correction[-1]})"

# COMMAND ----------

#pattern Correction
patternCorrection = "("
for correzione in correction[0:-1]:
    patternCorrection += f"(?<={correzione})|"

patternCorrection += f"(?<={correction[-1]})"

patternCorrection += ").*"


# COMMAND ----------

patternCorrection

# COMMAND ----------

# MAGIC %md
# MAGIC ## Split 

# COMMAND ----------

#funzioni per pulire e separare 
import re


#extract pezzo 
def extractPezzo(stringa, pattern):
    pezzo = None
    match = re.search(pattern, stringa.lower())
    if match:
       pezzo = match.group(0).strip().lower()
    return pezzo
       

# COMMAND ----------

#apply funzioni

df["complaint"] = df.apply(lambda x: extractPezzo(x[commentVar], patternComplaint), axis=1)
df["cause"] = df.apply(lambda x: extractPezzo(x[commentVar], patternCause), axis=1)
df["correction"] = df.apply(lambda x: extractPezzo(x[commentVar], patternCorrection), axis=1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Trovare i null

# COMMAND ----------

var = "complaint"
(pd.isnull(df[var])==True).sum()

# COMMAND ----------

df.loc[(pd.isnull(df["complaint"])==True) | (df["complaint"]=="")]

# COMMAND ----------

df.loc[223].complaint

# COMMAND ----------

# MAGIC %md
# MAGIC ## Eliminare i null o i record vuoti

# COMMAND ----------


mask = (pd.isnull(df["complaint"])==True) | (df["complaint"]=="") |(pd.isnull(df["cause"])==True) | (df["cause"]=="") |(pd.isnull(df["correction"])==True) | (df["correction"]=="")
                                                      
df = df.loc[~mask, :]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare il file pulito

# COMMAND ----------

#in csv perchè in excel non fa
df.to_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/Estrazione_Failure_Presa_13_poli_07092023_CLEANED.csv", index=False)

# COMMAND ----------

