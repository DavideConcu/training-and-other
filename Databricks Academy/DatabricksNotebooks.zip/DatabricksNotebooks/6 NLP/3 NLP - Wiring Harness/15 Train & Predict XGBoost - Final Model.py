# Databricks notebook source
# MAGIC %pip install xgboost nltk dataprep
# MAGIC

# COMMAND ----------

#load training data 
import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/training_cleaned_766187_splitted.xlsx_TRANSLATED.csv")

df["complete_comment_translated"] = df["complaint_translated"] + " ." + df["cause_translated"] + " ." + df["correction_translated"] + " ." 

cols_to_keep = ["complete_comment_translated", "target"]

df = df.loc[: , cols_to_keep]

df.head(5)

# COMMAND ----------

import pandas as pd
from dataprep.eda import create_report

# COMMAND ----------

#load stop words list 
import nltk
nltk.download('stopwords')
nltk.download('wordnet')

# COMMAND ----------

# importing the relevant packages
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import re

# Pre Processing
stop_words = stopwords.words('english') # creates a list of English stop words
wnl = WordNetLemmatizer() # I used lemmatizing instead of stemming
def preprocess(text_column):
    """
    Function:    This function aims to remove links, special 
                 characters, symbols, stop words and thereafter 
                 lemmatise each word in the sentence to transform 
                 the dataset into something more usable for a 
                 machine learning model.
    Input:       A text column
    Returns:     A text column (but transformed)
    """
    new_review = []
    for review in text_column:
        # for every sentence, we perform the necessary pre-processing
        text = re.sub("@\S+|https?:\S+|http?:\S|[^A-Za-z0-9]+", 
                        ' ', 
                        str(review).lower()).strip()
        text = [wnl.lemmatize(i) for i in text.split(' ') if i not in stop_words]
        new_review.append(' '.join(text)) 

    return new_review


df['complete_comment_translated_cleaned'] = preprocess(df['complete_comment_translated'])

# COMMAND ----------

#assign a numerical label to text
labels_swapped = dict(enumerate(set(df.target)))
labels_num = {v: k for k, v in labels_swapped.items()}

#apply new labels
df["target_num"] = df["target"].apply(lambda x: labels_num[x])

print(labels_num)

# COMMAND ----------

# Text data and labels
#testo e labels
texts_train = df["complete_comment_translated_cleaned"].to_list()
labels_train = df["target_num"].to_list()

# COMMAND ----------

#visualize classes
import seaborn as sns
print(labels_num)
sns.countplot(labels_train)

# COMMAND ----------

#create df train resampled
df_train_resample = pd.DataFrame({"texts":texts_train , "label":labels_train})

count_per_label = df_train_resample.groupby("label").count()
max_count = count_per_label.iloc[-1].values[0]
max_label = count_per_label.iloc[-1].name


#upsample minority classes - ONLY TRAIN DATA
from sklearn.utils import resample

new_train_df = df_train_resample[df_train_resample["label"]==max_label].copy()

for label in [x for x in set(labels_train) if x != max_label]:
    df_resample = resample(df_train_resample[df_train_resample["label"]==label],
                            replace=True,
                            n_samples=max_count)
    
    new_train_df = pd.concat([new_train_df, df_resample])



#visualize classes
import seaborn as sns
print(labels_num)
sns.countplot(new_train_df["label"])

# COMMAND ----------

#riportare text e labels come liste
#testo e labels
texts_train = new_train_df["texts"].to_list()
labels_train = new_train_df["label"].to_list()

# COMMAND ----------

#istanze di diversi vectorizer
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer

tfidf_vect_ngram_chars = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000)


#scegliere un vectorizer
vectorizer = tfidf_vect_ngram_chars

# COMMAND ----------

# Convert text data into numerical features using chosen vectorizer
X_train = vectorizer.fit_transform(texts_train)


# COMMAND ----------

#creare la DMatrix
import xgboost as xgb

dtrain = xgb.DMatrix(X_train, labels_train , enable_categorical=True)


# COMMAND ----------

model = xgb.XGBClassifier(max_depth= 2, 
                        n_estimators=1000,
                        eta= 0.01, 
                        objective="multi:softmax",
                        eval_metric="merror",
                        seed= 0,
                        num_class= len(labels_num))


# COMMAND ----------

model = model.fit(X_train, labels_train)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Predict Data

# COMMAND ----------

import pandas as pd

file_to_predict = "/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/760310___766187_claim__20231109_sheet766187_CLEANED_TRANSLATED.csv"

df = pd.read_csv(file_to_predict)


df["complete_comment_translated"] = df["complaint_translated"] + " " + df["cause_translated"] + " " + df["correction_translated"]


# COMMAND ----------

#clean the comment column

df['complete_comment_translated_cleaned'] = preprocess(df['complete_comment_translated'])

# COMMAND ----------

#riportare text e labels come liste
#testo e labels
texts_predict = df["complete_comment_translated_cleaned"].to_list()


# COMMAND ----------

#vettorizzare 
X_predict = vectorizer.transform(texts_predict)

# COMMAND ----------

#predict new dataset
predictions = model.predict(X_predict)

# COMMAND ----------

#predictions to column
df["predicted_cat_num"] = predictions

# COMMAND ----------

#back to string cat
df["predicted_cat"] = df["predicted_cat_num"].apply(lambda x: labels_swapped[x])



# COMMAND ----------

#cambio nome colonne
newColNames = [col.lower().replace(" ", "_").replace("\t", "").replace("\n", "") for col in df.columns]

df.columns = newColNames

# COMMAND ----------

#salvare come tabella nel catalog
sdf = spark.createDataFrame(df)

# COMMAND ----------

to_save = False

if to_save:
    sdf.write.mode("overwrite").saveAsTable("reliab.20231219_NLP_766187_XGBoostPredictions")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Output

# COMMAND ----------

df = spark.read.table("reliab.20231219_NLP_766187_XGBoostPredictions")

# COMMAND ----------

from pyspark.sql.functions import regexp_replace, col

for colu in  [x for x in df.columns if x not in ["vp_code", "chassis", "claim_number", "failure_code_description" ,"invoice_market_code", "market_repair_code"]]:
    df = df.withColumn(colu, regexp_replace(col(colu), ",", " "))
    df = df.withColumn(colu, regexp_replace(col(colu), ";", " "))





# COMMAND ----------

display(df)

# COMMAND ----------

for col in [x for x in df.columns if x not in ["vp_code", "chassis", "claim_number", "failure_code_description" ,"invoice_market_code", "market_repair_code"]]:
    df.loc[: , col] = df.loc[: , col].apply(lambda x: x.replace(",", " ") if type(x)==str else x)


# COMMAND ----------

for col in [x for x in df.columns if x not in ["vp_code", "chassis", "claim_number", "failure_code_description" ,"invoice_market_code", "market_repair_code"]]:
    for riga in range(len(df)):
        if type(df.loc[riga , col])==str and "," in  df.loc[riga , col]:
            print("OLD: ", df.loc[riga , col] )
            df.loc[riga , col] = df.loc[riga , col].replace(",", " ") 
            print("NEW: ", df.loc[riga , col] )

# COMMAND ----------

display(df)

# COMMAND ----------

df.loc[df.loc[:, "predicted_cat_num"].isnull()==False,:].count()

# COMMAND ----------

df.loc[df.loc[:, "predicted_cat_num"].isnull()==True,:].count()

# COMMAND ----------

display(df)

# COMMAND ----------

