# Databricks notebook source
# MAGIC %md
# MAGIC # Failure Comment Translation 

# COMMAND ----------

pip install -U deep-translator

# COMMAND ----------

# MAGIC %md
# MAGIC ## load file

# COMMAND ----------

path = "/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/"
filename = "training_cleaned_766187_splitted.xlsx"

# COMMAND ----------

import pandas as pd

df = pd.read_excel(f"{path}/{filename}")

commentVar = "dealer_comment"

# COMMAND ----------

mask = (pd.isnull(df.complaint ) == True) |( pd.isnull(df.cause ) == True) |( pd.isnull(df.correction ) == True) 

df.loc[mask, commentVar]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Translate

# COMMAND ----------

#inizializzare il dataframe
try: 
    translatedDf = pd.read_csv(path + filename + "_TRANSLATED.csv")
except:
    translatedDf = pd.DataFrame()
    translatedDf.to_csv(path + filename  + "_TRANSLATED.csv")

#righe da tradurre
index = [riga for riga in df.index if riga not in translatedDf.index]

# COMMAND ----------

#load dataset
#translatedDf = pd.read_csv(path + filename + "_TRANSLATED.csv")
#index = [riga for riga in df.index if riga not in translatedDf.index]

# COMMAND ----------

#riga per riga è più facile per debug
from deep_translator import GoogleTranslator

index = [riga for riga in df.index if riga not in translatedDf.index]
count = 0
for riga in index:
    try:
        for varToTranslate in ["complaint", "cause", "correction"]:
            
            #stringa da tradurre
            stringToTranslate = df.loc[riga, varToTranslate]
          
            df.loc[riga, varToTranslate+ "_translated"] = GoogleTranslator(source='auto', target='en').translate(stringToTranslate)


    except:
        translatedDf.to_csv(path + filename + "_TRANSLATED.csv", index=False)
        raise

    #append a finalDf
    translatedDf = pd.concat([translatedDf, df.loc[riga:riga, :]], axis = 0)

    count+=1
    if count == 100:
        print("100 rows appended, riga: ",riga)
        count=0

print("!!!DONE!!!")
translatedDf.to_csv(path + filename + "_TRANSLATED.csv", index=False)
        


# COMMAND ----------

display(spark.createDataFrame(translatedDf.loc[100:, :]))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Usare Pandas UDF per velocizzare il processo

# COMMAND ----------

import pandas as pd

df = pd.read_csv(path + filename + "_TRANSLATED.csv")



# COMMAND ----------

