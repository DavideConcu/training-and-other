# Databricks notebook source
# MAGIC %pip install google-cloud-translate==2.0.1

# COMMAND ----------

import os
#os.environ['GOOGLE_APPLICATION_CREDENTIALS'] ="/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/amazing_insight_411413_d7ebbd4134a0.json"

# COMMAND ----------

#from google.cloud import translate_v2

# COMMAND ----------

#def translate_text(target: str, text: str) -> dict:
#    """Translates text into the target language.
#
#    Target must be an ISO 639-1 language code.
#    See https://g.co/cloud/translate/v2/translate-reference#supported_languages
#    """
#    from google.cloud import translate_v2 as translate
#
#    translate_client = translate.Client()
#
#    if isinstance(text, bytes):
#        text = text.decode("utf-8")
#
#    # Text can also be a sequence of strings, in which case this method
#    # will return a sequence of results for each text.
#    result = translate_client.translate(text, target_language=target)
#
#    print("Text: {}".format(result["input"]))
#    print("Translation: {}".format(result["translatedText"]))
#    print("Detected source language: {}".format(result["detectedSourceLanguage"]))
#
#    return result

# COMMAND ----------

#translate_text("it", "I have an Databricks account on Azure, and the goal is to compare different image tagging services from Azure, GCP, AWS via corresponding API calls, with Python. I have problems with GCP vision API calls, specifically with credentials: as far as I understand, the one necessary step is to set 'GOOGLE_APPLICATION_CREDENTIALS' environment variable in my databricks notebook with something like")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Altre prove

# COMMAND ----------

import os
from google.oauth2 import service_account
from google.cloud import translate_v2 as translate

credentials = service_account.Credentials.from_service_account_file("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/amazing_insight_411413_d7ebbd4134a0.json")

translate_client = translate.Client(credentials=credentials)


# COMMAND ----------

translate_client.translate("I have an Databricks account on Azure, and the goal is to compare different image tagging services from Azure, GCP, AWS via corresponding API calls, with Python. I have problems with GCP vision API calls, specifically with credentials: as far as I understand, the one necessary step is to set 'GOOGLE_APPLICATION_CREDENTIALS' environment variable in my databricks notebook with something like", target_language="it", format_="text")

# COMMAND ----------

transText = translate_client.translate("I have an Databricks account on Azure, and the goal is to compare different image tagging services from Azure, GCP, AWS via corresponding API calls, with Python. I have problems with GCP vision API calls, specifically with credentials: as far as I understand, the one necessary step is to set 'GOOGLE_APPLICATION_CREDENTIALS' environment variable in my databricks notebook with something like", target_language="it", format_="text" )["translatedText"]

# COMMAND ----------

