# Databricks notebook source
import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Progetti Vari/dealer_comments_subgroup_5532_cleanedsplitted_translated.csv")

# COMMAND ----------

df

# COMMAND ----------

