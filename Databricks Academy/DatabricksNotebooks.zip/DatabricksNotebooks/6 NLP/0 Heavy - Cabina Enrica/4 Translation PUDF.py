# Databricks notebook source
# MAGIC %md
# MAGIC # Translation Test with PUDF

# COMMAND ----------

pip install -U deep-translator

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load CSV File and create Spark DataFrame

# COMMAND ----------

import pandas as pd 

#percorso del file
path = "/dbfs/FileStore/tables/reliab/Progetti Vari/"
file = "dealer_comments_subgroup_5532_cleanedsplitted"
ext = ".csv"

#failure comment var 
failure_comment_var = "Dealer Comment (Failure)"


df = pd.read_csv(path + file + ext)

# COMMAND ----------

#change column names - for writing spark dataframe to catalog
invalid_characters = " ,;{}()\n\t="

cols = df.columns

newcols = []
for col in cols:
    newcol = col
    for char in invalid_characters:
        newcol = newcol.replace(char, "")
    newcols.append(newcol)

df.columns = newcols

# COMMAND ----------

#create spark dataframe
sdf = spark.createDataFrame(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Translation PUDF

# COMMAND ----------

#pandas udf for translating text
import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType
from deep_translator import GoogleTranslator

# Create pandas_udf()
@pandas_udf(StringType())
def translate_pudf(comment_column: pd.Series) -> pd.Series:
    translated_column = comment_column.apply(lambda text: GoogleTranslator(source='auto', target='en').translate(text))
    return translated_column

# COMMAND ----------

# MAGIC %md
# MAGIC ## Apply Function to Spark Dataframe

# COMMAND ----------

from pyspark.sql.functions import col

for column in ["complaint", "cause", "correction"]:
    sdf = sdf.withColumn(f"{column}_translated", translate_pudf(col(column)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Spark Dataframe to Catalog

# COMMAND ----------

sdf.write.saveAsTable("reliab.20240116_NLP_CabinHeavy_translated")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check Results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM reliab.20240116_NLP_CabinHeavy_translated

# COMMAND ----------

