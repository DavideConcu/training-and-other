# Databricks notebook source
# MAGIC %md
# MAGIC # Translate to English

# COMMAND ----------

pip install -U deep-translator


# COMMAND ----------

# MAGIC %md
# MAGIC ## Params

# COMMAND ----------

#percorso del file
path = "/dbfs/FileStore/tables/reliab/Progetti Vari/"
file = "dealer_comments_subgroup_5532_cleanedsplitted"
ext = ".csv"

#failure comment var 
failure_comment_var = "Dealer Comment (Failure)"

#!!!!!!!!!!!! UNIQUE KEY !!!!!!!!!!!!!
UNIQUE_KEY = "index"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

import pandas as pd 

df = pd.read_csv(path + file + ext)

# COMMAND ----------

#vedere se ci sono dei missing
mask = (df.complaint.isnull() == True)|( df.cause.isnull()  == True)|( df.correction.isnull() == True) 
mask2 = (df.complaint== "")|( df.cause  == "")|( df.correction == "")

df.loc[(mask|mask2)].count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Initialize Translated Dataset 

# COMMAND ----------

#inizializzare il dataframe
reset = True
if reset:
    translatedDf = pd.DataFrame()
    translatedDf.to_csv(path + file  + "_translated.csv", index=False)   

try: 
    translatedDf = pd.read_csv(path + file + "_translated.csv", index=False)
except:
    translatedDf = pd.DataFrame()
    translatedDf.to_csv(path + file  + "_translated.csv", index=False)

#righe da tradurre
index = [riga for riga in df.index if riga not in translatedDf.index]

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Translate

# COMMAND ----------

#riga per riga è più facile per debug
from deep_translator import GoogleTranslator

index = [riga for riga in df.index if riga not in translatedDf.index]
count = 0
for riga in index:
    try:
        for varToTranslate in ["complaint", "cause", "correction"]:
            
            #stringa da tradurre
            stringToTranslate = df.loc[riga, varToTranslate]
          
            df.loc[riga, varToTranslate+ "_translated"] = GoogleTranslator(source='auto', target='en').translate(stringToTranslate)


    except:
        #translatedDf.to_csv(path + file + "_translated.csv", index=False)
        raise

    #append a finalDf
    translatedDf = pd.concat([translatedDf, df.loc[riga:riga, :]], axis = 0)
    print("done row ", riga)

    count+=1
    if count == 100:
        print("100 rows appended, riga: ",riga)
        translatedDf.to_csv(path + file + "_translated.csv", index=False)
        count=0

print("!!!DONE!!!")
translatedDf.to_csv(path + file + "_translated.csv", index=False)
        


# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare come tabella sul catalog
# MAGIC

# COMMAND ----------

translatedDf_copy = translatedDf.copy()

#change column names
invalid_characters = " ,;{}()\n\t="

cols = translatedDf_copy.columns

newcols = []
for col in cols:
    newcol = col
    for char in invalid_characters:
        newcol = newcol.replace(char, "")
    newcols.append(newcol)

translatedDf_copy.columns = newcols


# COMMAND ----------

# MAGIC %md 
# MAGIC ## eliminare le virgole dalle variabili
# MAGIC

# COMMAND ----------

#elimina virgole (creano problemi col csv)
for col in translatedDf_copy.columns:
    translatedDf_copy[col] = translatedDf_copy[col].apply(lambda x: x.replace(",", "") if type(x)==str else x)
    translatedDf_copy[col] = translatedDf_copy[col].apply(lambda x: x.replace("(", "") if type(x)==str else x)
    translatedDf_copy[col] = translatedDf_copy[col].apply(lambda x: x.replace(")", "") if type(x)==str else x)



# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggiunta commento intero tradotto
# MAGIC

# COMMAND ----------

translatedDf_copy["entire_comment_translated"] = translatedDf_copy["complaint_translated"] + ". " + translatedDf_copy["cause_translated"] + ". " + translatedDf_copy["correction_translated"]

# COMMAND ----------

translatedDf_copy["entire_comment_translated"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare sul catalog spark

# COMMAND ----------

translated_sdf = spark.createDataFrame(translatedDf_copy)

# COMMAND ----------

translated_sdf.write.saveAsTable("reliab.20240111_NLP_cabinaHeavy_translated")

# COMMAND ----------

display(translated_sdf)

# COMMAND ----------

