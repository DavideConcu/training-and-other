# Databricks notebook source
# MAGIC %md
# MAGIC # Pre-Processing e Cleaning

# COMMAND ----------

# MAGIC %md
# MAGIC ## Params

# COMMAND ----------

#percorso del file
path = "/dbfs/FileStore/tables/reliab/Progetti Vari/"
file = "dealer_comments_subgroup_5532"
ext = ".xlsx"

#failure comment var 
failure_comment_var = "Dealer Comment (Failure)"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

import pandas as pd 

df_all_variables = pd.read_excel(path + file + ext)


#row number come id
df_all_variables = df_all_variables.reset_index()

vars_to_keep = ["index", failure_comment_var]


# COMMAND ----------

#eliminare i commenti vuoti
mask = df_all_variables[failure_comment_var].isnull() == False
 
df = df_all_variables.loc[mask, vars_to_keep].copy()

df = df.reset_index(drop = True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleaning 

# COMMAND ----------

#eliminare asterischi e simboli
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace("*", ""))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace("-", ""))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace(".", ""))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace("\t", ""))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace("\n", ""))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace(":", ""))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace(",", ""))



#strip
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.strip())

#to lowercase
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.lower())


# COMMAND ----------

#sostituire parole scritte male
import re

df[failure_comment_var] = df[failure_comment_var].apply(lambda x: re.sub(r"\bsost\b", "sostituzione", x))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: re.sub(r"\bsostcompressore\b", "sostituzione compressore", x))

df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace("&", " and "))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace("+", " plus "))
df[failure_comment_var] = df[failure_comment_var].apply(lambda x: x.replace("2", " two "))



# COMMAND ----------

# MAGIC %md
# MAGIC ## Eliminazione di Complaint

# COMMAND ----------

#eliminare COMPLAINT
to_eliminate = False
if to_eliminate:
    df[failure_comment_var] = df[failure_comment_var].apply(lambda x: " ".join(x.split()[1:]))
    to_eliminate = False

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Split in Complaint, Cause e Correction

# COMMAND ----------

#elenco parole che separano causa e correzione
cause = ["grund", "cause", "oorzak", "oorzaak", "cprz", "causa" , "årsak", "årsag", "orsak", "příč"]
correction = ["correction", "solution", "correctie", "korecta", "correzione", "korrectur", "correcao", "solucion" , "korreksjon", "rettelse", "ändring", "oprava",]


# COMMAND ----------

#pattern Complaint
patternComplaint = ".*?("
for causa in cause[0:-1]:
    patternComplaint += f"(?={causa})|"
    
patternComplaint += f"(?={cause[-1]}))"


#pattern Cause
patternCause = "("
for causa in cause[0:-1]:
    patternCause += f"(?<={causa})|"

patternCause += f"(?<={cause[-1]}))"

patternCause += ".*?(?="
for correzione in correction[0:-1]:
    patternCause += f"{correzione}|"

patternCause += f"{correction[-1]})"


#pattern Correction
patternCorrection = "("
for correzione in correction[0:-1]:
    patternCorrection += f"(?<={correzione})|"

patternCorrection += f"(?<={correction[-1]})"

patternCorrection += ").*"


# COMMAND ----------

#funzioni per pulire e separare 
import re

#extract pezzo 
def extractPezzo(stringa, pattern):
    pezzo = None
    match = re.search(pattern, stringa.lower())
    if match:
       pezzo = match.group(0).strip().lower()
    return pezzo
       

# COMMAND ----------

#apply funzioni
df["complaint"] = df.apply(lambda x: extractPezzo(x[failure_comment_var], patternComplaint), axis=1)
df["cause"] = df.apply(lambda x: extractPezzo(x[failure_comment_var], patternCause), axis=1)
df["correction"] = df.apply(lambda x: extractPezzo(x[failure_comment_var], patternCorrection), axis=1)

# COMMAND ----------

df.head(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Eliminare i Missing

# COMMAND ----------

#vedere se ci sono dei missing
mask = (df.complaint.isnull() == True)|( df.cause.isnull()  == True)|( df.correction.isnull() == True) 
mask2 = (df.complaint== "")|( df.cause  == "")|( df.correction == "")

df.loc[mask|mask2].count()

# COMMAND ----------

df.loc[(mask|mask2)]

# COMMAND ----------

#drop
df = df.loc[~(mask|mask2), :]

#reset_index
df = df.reset_index(drop = True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare

# COMMAND ----------

df.to_csv(path + file + "_cleanedsplitted" + ".csv", index=False)