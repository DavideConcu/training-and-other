# Databricks notebook source
# MAGIC %md
# MAGIC ## Merge with original data 

# COMMAND ----------

#percorso del file
path = "/dbfs/FileStore/tables/reliab/Progetti Vari/"
file = "dealer_comments_subgroup_5532"
ext = ".xlsx"

#failure comment var 
failure_comment_var = "Dealer Comment (Failure)"

# COMMAND ----------

import pandas as pd 

df_all_variables = pd.read_excel(path + file + ext)

#row number come id
df_all_variables = df_all_variables.reset_index()


# COMMAND ----------

#eliminare i commenti vuoti
mask = df_all_variables[failure_comment_var].isnull() == False
 
df_all_variables = df_all_variables.loc[mask].copy()

df_all_variables = df_all_variables.reset_index(drop = True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Basic Cleaning

# COMMAND ----------

df_all_variables = df_all_variables.drop("Unnamed: 37", axis=1)

# COMMAND ----------


#change column names
invalid_characters = " ,;{}()\n\t="

cols = df_all_variables.columns

newcols = []
for col in cols:
    newcol = col
    for char in invalid_characters:
        newcol = newcol.replace(char, "")
    newcols.append(newcol)

df_all_variables.columns = newcols


# COMMAND ----------

# MAGIC %md
# MAGIC ## Load translated Df

# COMMAND ----------

translated_df = spark.read.table("reliab.20240111_NLP_cabinaHeavy_translated").toPandas()

# COMMAND ----------

translated_df = translated_df.drop("DealerCommentFailure", axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## merge

# COMMAND ----------

import pandas as pd

merged_df = pd.merge(df_all_variables, translated_df, on = "index")

# COMMAND ----------

merged_df = merged_df.drop("index", axis = 1)

# COMMAND ----------

#ELIMINARE EVENTUALI VIRGOLE!!
#elimina virgole (creano problemi col csv)
for col in merged_df.columns:
    merged_df[col] = merged_df[col].apply(lambda x: x.replace(",", "") if type(x)==str else x)


# COMMAND ----------

merged_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Download

# COMMAND ----------

sdf_1 = spark.createDataFrame(merged_df.loc[0:1000,:])
sdf_2 = spark.createDataFrame(merged_df.loc[1001:2000,:])
sdf_3 = spark.createDataFrame(merged_df.loc[2001:3000,:])
sdf_4 = spark.createDataFrame(merged_df.loc[3001:,:])



# COMMAND ----------

display(sdf_4)

# COMMAND ----------

