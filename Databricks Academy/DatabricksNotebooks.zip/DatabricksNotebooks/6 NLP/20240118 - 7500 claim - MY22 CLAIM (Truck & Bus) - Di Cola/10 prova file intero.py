# Databricks notebook source
import pandas as pd

file = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/MY22_CLAIM__Truck___Bus____7500_claims___translated___training___all_variables.xlsx")

file.drop("wheelbase", axis = 1 , inplace=True)
file.drop("unnamed:_65", axis = 1 , inplace=True)

# COMMAND ----------

spark.createDataFrame(file)

# COMMAND ----------

