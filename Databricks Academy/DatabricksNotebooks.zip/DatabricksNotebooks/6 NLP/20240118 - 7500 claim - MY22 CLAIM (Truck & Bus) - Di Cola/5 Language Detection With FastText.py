# Databricks notebook source
# MAGIC %md
# MAGIC # FastText For Language Identification

# COMMAND ----------

# MAGIC %pip install transformers torch sentencepiece fasttext

# COMMAND ----------

# MAGIC %md
# MAGIC ##Pandas UDF

# COMMAND ----------

#pandas udf for translating text
import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType
from huggingface_hub import hf_hub_download
import fasttext


# Create pandas_udf()
@pandas_udf(StringType())
def detect_language(failure_comment: pd.Series) -> pd.Series:
    model_path = hf_hub_download(repo_id="facebook/fasttext-language-identification", filename="model.bin")
    model = fasttext.load_model(model_path)
    prediction = failure_comment.apply(lambda x: model.predict(x)[0][0])
    return prediction

# COMMAND ----------

# MAGIC %md
# MAGIC ## Apply to Df 

# COMMAND ----------

import pandas as pd

df = pd.read_csv("/dbfs/FileStore/tables/reliab/NLP Projects/20240118 7500 claim/only_7500_claims_cleanedsplitted.csv")

sdf = spark.createDataFrame(df)\
                .withColumnRenamed("Failure Comment", "failure_comment")



# COMMAND ----------

from pyspark.sql.functions import col

sdf = sdf.withColumn("language", detect_language(col("failure_comment")))

# COMMAND ----------

display(sdf)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save sdf To Catalog
# MAGIC

# COMMAND ----------

sdf.write.saveAsTable("reliab.20240124_NLP_7500claims_LanguageDetection")

# COMMAND ----------

