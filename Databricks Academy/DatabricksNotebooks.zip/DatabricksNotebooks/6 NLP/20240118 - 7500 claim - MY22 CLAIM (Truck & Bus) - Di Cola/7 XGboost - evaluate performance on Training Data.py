# Databricks notebook source
# MAGIC %pip install xgboost nltk dataprep

# COMMAND ----------

import pandas as pd

df = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/MY22_CLAIM__Truck___Bus____7500_claims___translated___training___all_variables.xlsx")

df.drop("wheelbase", axis = 1 , inplace=True)
df.drop("unnamed:_65", axis = 1 , inplace=True)


def clean_column_names(df):
    cleaned_columns = [col.replace('"', '')
                             .replace(',', '')
                             .replace(';', '')
                             .replace('{', '')
                             .replace('}', '')
                             .replace('(', '')
                             .replace(')', '')
                             .replace('\n', '')
                             .replace('\t', '')
                             .replace('=', '')
                             .strip() for col in df.columns]
    df.columns = cleaned_columns
    return df



# Clean column names
df = clean_column_names(df)

# COMMAND ----------

df.columns

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare Train Dataset with Function

# COMMAND ----------

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import numpy as np

def prepare_train_data(dataset:pd.DataFrame, variabile_testo:str, variabile_classe:str, soglia:int):
    """funzione per ottenere X e y di training (pd.Series)"""

    #dataset
    df = dataset.copy()

    #target
    y_var = variabile_classe
    X_var = variabile_testo

    #categorie to lower
    #df[y_var] = df[y_var].apply(lambda x: x.lower() if type(x)==str else x)
    #df[y_var] = df[y_var].apply(lambda x: x.title().replace(" ","").strip() if type(x)==str else x)
    df[y_var] = df[y_var].apply(lambda x: " ".join(x.lower().split()) if type(x)==str else x)


    #aggregazione delle categorie simili
    #complaint
    df[y_var] = df[y_var].apply(lambda x: "DifettiVerniciatura" if x in ["DifettiDiVerniciatura", "BolleDiVernice/DifettoDiVernice"]  else x)
    df[y_var] = df[y_var].apply(lambda x: "SospensioniPneumatiche" if x in ["SpiaSospensioniPneumatiche", "SospensioniNonFunzionanti" , "FaultSospensioniPneumatiche"]  else x)
    df[y_var] = df[y_var].apply(lambda x: "Disallineamento" if x in ["DisallineamentoComponenti", "DisallineamentoStero/DirezioneIrregolare"] else x)
    df[y_var] = df[y_var].apply(lambda x: "InfiltrazioneAcqua" if x in ["WaterInfiltration", "IngressoAcqua"] else x)
    df[y_var] = df[y_var].apply(lambda x: "ChiusuraPortiera" if x in ["ChiusuraPorteErrata", "MancataChiusura", "MancataChiusuraPortiera"] else x)

    #cause
    df[y_var] = df[y_var].apply(lambda x: "SensoreGuasto" if x in ["SensoreGuasto", "GuastoInternoSensore"] else x)

    #complaint
    df[y_var] = df[y_var].apply(lambda x: "Rimontaggio/SostituzioneSensore" if x in ["RimontaggioSensore", "RegolazioneSensore", "SostituzioneSensore"] else x)
    df[y_var] = df[y_var].apply(lambda x: "SostituzioneFaro" if x in ["SostituzioneFanale", "SostituzioneFaro"] else x)




    #righe per categoria
    count_by_cat = df.groupby(y_var).row_number.count().sort_values()


    #raggruppare le categorie che hanno poche acquisizioni
    other_cat = [x for x in count_by_cat.index if count_by_cat[x] < soglia]

    #Your list of issues
    #issues = df.loc[df[y_var].isin(other_cat), X_var]
    issues = other_cat

    # Convert issues to numerical vectors
    vectorizer = TfidfVectorizer()
    #vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(issues)

    # Apply k-means clustering
    num_clusters = 5  # Adjust the number of clusters as needed
    kmeans = KMeans(n_clusters=num_clusters, random_state=42)
    kmeans.fit(X)

    # Get the cluster labels
    cluster_labels = kmeans.labels_

    # Group issues based on cluster labels
    issue_groups = {}
    for issue, label in zip(issues, cluster_labels):
        if label not in issue_groups:
            issue_groups[label] = []
        issue_groups[label].append(issue)


    #rinominare le categorie che non hanno abbastanza osservazioni come "other"
    df[y_var] = df[y_var].apply(lambda x: "other" if x in other_cat else x)
    #df[y_var] = df[y_var].apply(lambda x: next((f"other - cluster {int(key)+1}" for key,value in issue_groups.items() if x in value), x))
    #df.loc[df[y_var].isin(other_cat), y_var] = pd.Series(cluster_labels).map(lambda x: f"other: cluster {int(x + 1)}")


    #rows where target is not null
    train_mask = ~df[y_var].isnull()

    #tenere solo il dataset di training
    #df_train = df.loc[train_mask, : ]
    X_train = df.loc[train_mask, X_var]
    y_train = df.loc[train_mask, y_var]


    #rows where target is not null
    predict_mask = df[y_var].isnull()
    X_predict = df.loc[predict_mask, X_var]


    return X_train, y_train , X_predict, issue_groups


# COMMAND ----------

# MAGIC %md
# MAGIC import pandas as pd
# MAGIC from sklearn.feature_extraction.text import TfidfVectorizer
# MAGIC from sklearn.cluster import KMeans
# MAGIC import numpy as np
# MAGIC
# MAGIC def prepare_train_data(dataset:pd.DataFrame, variabile_testo:str, variabile_classe:str, soglia:int):
# MAGIC     """funzione per ottenere X e y di training (pd.Series)"""
# MAGIC
# MAGIC     #dataset
# MAGIC     df = dataset.copy()
# MAGIC
# MAGIC     #target
# MAGIC     y_var = variabile_classe
# MAGIC     X_var = variabile_testo
# MAGIC
# MAGIC     #categorie to lower
# MAGIC     #df[y_var] = df[y_var].apply(lambda x: x.lower() if type(x)==str else x)
# MAGIC     #df[y_var] = df[y_var].apply(lambda x: x.title().replace(" ","").strip() if type(x)==str else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: " ".join(x.lower().split()) if type(x)==str else x)
# MAGIC
# MAGIC
# MAGIC     #aggregazione delle categorie simili
# MAGIC     #complaint
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "DifettiVerniciatura" if x in ["DifettiDiVerniciatura", "BolleDiVernice/DifettoDiVernice"]  else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "SospensioniPneumatiche" if x in ["SpiaSospensioniPneumatiche", "SospensioniNonFunzionanti" , "FaultSospensioniPneumatiche"]  else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "Disallineamento" if x in ["DisallineamentoComponenti", "DisallineamentoStero/DirezioneIrregolare"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "InfiltrazioneAcqua" if x in ["WaterInfiltration", "IngressoAcqua"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "ChiusuraPortiera" if x in ["ChiusuraPorteErrata", "MancataChiusura", "MancataChiusuraPortiera"] else x)
# MAGIC
# MAGIC     #cause
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "SensoreGuasto" if x in ["SensoreGuasto", "GuastoInternoSensore"] else x)
# MAGIC
# MAGIC     #complaint
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "Rimontaggio/SostituzioneSensore" if x in ["RimontaggioSensore", "RegolazioneSensore", "SostituzioneSensore"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "SostituzioneFaro" if x in ["SostituzioneFanale", "SostituzioneFaro"] else x)
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC     #righe per categoria
# MAGIC     count_by_cat = df.groupby(y_var).row_number.count().sort_values()
# MAGIC
# MAGIC
# MAGIC     #raggruppare le categorie che hanno poche acquisizioni
# MAGIC     other_cat = [x for x in count_by_cat.index if count_by_cat[x] < soglia]
# MAGIC
# MAGIC     #Your list of issues
# MAGIC     issues = other_cat
# MAGIC
# MAGIC     # Convert issues to numerical vectors
# MAGIC     vectorizer = TfidfVectorizer()
# MAGIC     #vectorizer = CountVectorizer()
# MAGIC     X = vectorizer.fit_transform(issues)
# MAGIC
# MAGIC     # Apply k-means clustering
# MAGIC     num_clusters = 3  # Adjust the number of clusters as needed
# MAGIC     kmeans = KMeans(n_clusters=num_clusters, random_state=42)
# MAGIC     kmeans.fit(X)
# MAGIC
# MAGIC     # Get the cluster labels
# MAGIC     cluster_labels = kmeans.labels_
# MAGIC
# MAGIC     # Group issues based on cluster labels
# MAGIC     issue_groups = {}
# MAGIC     for i, label in enumerate(cluster_labels):
# MAGIC         if label not in issue_groups:
# MAGIC             issue_groups[label] = []
# MAGIC         issue_groups[label].append(issues[i])
# MAGIC
# MAGIC
# MAGIC     #rinominare le categorie che non hanno abbastanza osservazioni come "other"
# MAGIC     #df[y_var] = df[y_var].apply(lambda x: "other" if x in other_cat else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: next((f"other - cluster {int(key)+1}" for key,value in issue_groups.items() if x in value), x))
# MAGIC
# MAGIC
# MAGIC
# MAGIC     #rows where target is not null
# MAGIC     train_mask = ~df[y_var].isnull()
# MAGIC
# MAGIC     #tenere solo il dataset di training
# MAGIC     #df_train = df.loc[train_mask, : ]
# MAGIC     X_train = df.loc[train_mask, X_var]
# MAGIC     y_train = df.loc[train_mask, y_var]
# MAGIC
# MAGIC
# MAGIC     #rows where target is not null
# MAGIC     predict_mask = df[y_var].isnull()
# MAGIC     X_predict = df.loc[predict_mask, X_var]
# MAGIC
# MAGIC
# MAGIC     return X_train, y_train , X_predict, issue_groups
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC import pandas as pd
# MAGIC from sklearn.feature_extraction.text import TfidfVectorizer
# MAGIC from sklearn.cluster import KMeans
# MAGIC import numpy as np
# MAGIC from sklearn.decomposition import LatentDirichletAllocation
# MAGIC from sklearn.feature_extraction.text import CountVectorizer
# MAGIC
# MAGIC def prepare_train_data(dataset: pd.DataFrame, variabile_testo: str, variabile_classe: str, soglia: int):
# MAGIC     """Funzione per ottenere X e y di training (pd.Series)"""
# MAGIC
# MAGIC     # dataset
# MAGIC     df = dataset.copy()
# MAGIC
# MAGIC     # target
# MAGIC     y_var = variabile_classe
# MAGIC     X_var = variabile_testo
# MAGIC
# MAGIC     # Lowercase categories
# MAGIC     df[y_var] = df[y_var].apply(lambda x: " ".join(x.lower().split()) if isinstance(x, str) else x)
# MAGIC
# MAGIC     # Aggregating similar categories
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "DifettiVerniciatura" if x in ["DifettiDiVerniciatura", "BolleDiVernice/DifettoDiVernice"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "SospensioniPneumatiche" if x in ["SpiaSospensioniPneumatiche", "SospensioniNonFunzionanti", "FaultSospensioniPneumatiche"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "Disallineamento" if x in ["DisallineamentoComponenti", "DisallineamentoStero/DirezioneIrregolare"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "InfiltrazioneAcqua" if x in ["WaterInfiltration", "IngressoAcqua"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "ChiusuraPortiera" if x in ["ChiusuraPorteErrata", "MancataChiusura", "MancataChiusuraPortiera"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "SensoreGuasto" if x in ["SensoreGuasto", "GuastoInternoSensore"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "Rimontaggio/SostituzioneSensore" if x in ["RimontaggioSensore", "RegolazioneSensore", "SostituzioneSensore"] else x)
# MAGIC     df[y_var] = df[y_var].apply(lambda x: "SostituzioneFaro" if x in ["SostituzioneFanale", "SostituzioneFaro"] else x)
# MAGIC
# MAGIC     # Rows per category
# MAGIC     count_by_cat = df.groupby(y_var).size()
# MAGIC
# MAGIC     # Group categories with few observations
# MAGIC     other_cat = count_by_cat[count_by_cat < soglia].index.tolist()
# MAGIC
# MAGIC     # Convert issues to numerical vectors using CountVectorizer
# MAGIC     vectorizer = CountVectorizer()
# MAGIC     vectorizer = TfidfVectorizer()
# MAGIC     X = vectorizer.fit_transform(df[X_var])
# MAGIC
# MAGIC     # Apply Latent Dirichlet Allocation (LDA) for topic modeling
# MAGIC     num_topics = 10  # Adjust the number of topics as needed
# MAGIC     lda = LatentDirichletAllocation(n_components=num_topics, random_state=42)
# MAGIC     topic_assignments = lda.fit_transform(X)
# MAGIC
# MAGIC     # Determine dominant topic for each document
# MAGIC     dominant_topic = topic_assignments.argmax(axis=1)
# MAGIC
# MAGIC     # Group issues based on dominant topic
# MAGIC     issue_groups = {}
# MAGIC     for i, label in enumerate(dominant_topic):
# MAGIC         if label not in issue_groups:
# MAGIC             issue_groups[label] = []
# MAGIC         if i < len(other_cat):
# MAGIC             issue_groups[label].append(other_cat[i])
# MAGIC
# MAGIC     # Rename categories with fewer observations as "other"
# MAGIC     df[y_var] = df[y_var].apply(lambda x: next((f"other - topic {key}" for key, value in issue_groups.items() if x in value), x))
# MAGIC
# MAGIC     # Rows where target is not null
# MAGIC     train_mask = ~df[y_var].isnull()
# MAGIC
# MAGIC     # Training dataset
# MAGIC     X_train = df.loc[train_mask, X_var]
# MAGIC     y_train = df.loc[train_mask, y_var]
# MAGIC
# MAGIC     # Rows where target is null
# MAGIC     predict_mask = df[y_var].isnull()
# MAGIC     X_predict = df.loc[predict_mask, X_var]
# MAGIC
# MAGIC     return X_train, y_train, X_predict, other_cat

# COMMAND ----------

# MAGIC %md
# MAGIC ## Evaluate Performance of XGBoost with Function

# COMMAND ----------

#load stop words list 
import nltk
nltk.download('stopwords')
nltk.download('wordnet')

# importing the relevant packages
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import re

# Pre Processing
stop_words = stopwords.words('english') # creates a list of English stop words
wnl = WordNetLemmatizer() # I used lemmatizing instead of stemming
def preprocess(text_column):
    """
    Function:    This function aims to remove links, special 
                 characters, symbols, stop words and thereafter 
                 lemmatise each word in the sentence to transform 
                 the dataset into something more usable for a 
                 machine learning model.
    Input:       A text column
    Returns:     A text column (but transformed)
    """
    new_review = []
    for review in text_column:
        # for every sentence, we perform the necessary pre-processing
        text = re.sub("@\S+|https?:\S+|http?:\S|[^A-Za-z0-9]+", 
                        ' ', 
                        str(review).lower()).strip()
        text = [wnl.lemmatize(i) for i in text.split(' ') if i not in stop_words]
        new_review.append(' '.join(text)) 

    return new_review

# COMMAND ----------

#istanze di diversi vectorizer
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer

count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
tfidf_vect = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000)
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=15000)
tfidf_vect_ngram2 = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,4), max_features=5000)

tfidf_vect_ngram_chars = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000)
tfidf_vect_ngram_chars2 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(1,10), max_features=5000)
tfidf_vect_ngram_chars3 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(1,5), max_features=15000)
tfidf_vect_ngram_chars4 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(1,10), max_features=50000)
tfidf_vect_ngram_chars5 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(1,5), max_features=50000)
tfidf_vect_ngram_chars6 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(2,5), max_features=50000)
tfidf_vect_ngram_chars7 = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(1,5), max_features=100000)




# COMMAND ----------

#Splittare in train-test
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report


def evaluate_performance(X: pd.Series, y: pd.Series, vettorizzatore, test_size=0.3):
    
    #preprocessing della X
    X_preproc = preprocess(X)

    #assign a numerical label to text
    labels_swapped = dict(enumerate(set(y)))
    labels_num = {v: k for k, v in labels_swapped.items()}
    #apply new labels
    y_numeric = y.apply(lambda x: labels_num[x])


    # Text data and labels
    #testo e labels
    texts = X_preproc
    labels = y_numeric.to_list()

    # Split the data into train and test sets
    texts_train, texts_test, labels_train, labels_test = train_test_split(texts, labels, test_size=test_size, random_state=0)

    #scegliere un vectorizer
    vectorizer = vettorizzatore

    # Convert text data into numerical features using chosen vectorizer
    X_train = vectorizer.fit_transform(texts_train)
    X_test = vectorizer.transform(texts_test)

    #modello
    model = xgb.XGBClassifier(max_depth= 2, 
                                n_estimators=1000,
                                eta= 0.01, 
                                objective="multi:softmax",
                                eval_metric="merror",
                                seed= 1,
                                num_class= len(labels_num))
    
    #fit del modello sui dati di training 
    model = model.fit(X_train, labels_train)

    #predizioni del modello
    predictions = model.predict(X_test)

    print(classification_report(predictions, labels_test , target_names=labels_num.keys(), zero_division=True))

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

#dizio con variabili label e testo associate
text_and_label_dict = {"complaint": {"text":"complaint_translated" , "label":'Problem Statement ' },
                        "cause": {"text": "cause_translated", "label": 'Cluster Cause '},
                        "correction": {"text": "correction_translated", "label":"Correction"}}

# COMMAND ----------

# MAGIC %md
# MAGIC #test entire process
# MAGIC
# MAGIC ################## PARAMS #############
# MAGIC comment_part = "cause"
# MAGIC
# MAGIC soglia = 30
# MAGIC #vettorizzatore = tfidf_vect_ngram_chars5
# MAGIC vettorizzatore = count_vect
# MAGIC single_vect = True
# MAGIC ######################################
# MAGIC
# MAGIC other_cat_dict = dict()
# MAGIC
# MAGIC for comment_part in ["complaint", "cause", "correction"]:
# MAGIC
# MAGIC
# MAGIC     #prepare training data
# MAGIC     var_testo = text_and_label_dict[comment_part]["text"]
# MAGIC     var_classe = text_and_label_dict[comment_part]["label"]
# MAGIC
# MAGIC     #obtain X and y from training data
# MAGIC     X_train, y_train, X_predict, other_cat = prepare_train_data(dataset=df, variabile_testo=var_testo, variabile_classe=var_classe, soglia=soglia)
# MAGIC
# MAGIC     other_cat_dict[comment_part] = other_cat
# MAGIC
# MAGIC     #evaluate performance
# MAGIC
# MAGIC     print(f"\n\n++++++++++++++++++++++++++++++++++++ {comment_part.upper()} ++++++++++++++++++++++++++++++++++++\n\n")
# MAGIC
# MAGIC     #test su un singolo vettorizzatore
# MAGIC     if single_vect:
# MAGIC         print("vectorizer: " , vettorizzatore)
# MAGIC         evaluate_performance(X_train, y_train, vettorizzatore=vettorizzatore)
# MAGIC
# MAGIC
# MAGIC     #test su tutti i vettorizzatori
# MAGIC     if single_vect==False:
# MAGIC
# MAGIC         #lista dei vettorizzatori da testare
# MAGIC         vectorizers_list = [tfidf_vect_ngram_chars5, tfidf_vect_ngram_chars6, tfidf_vect_ngram_chars7]
# MAGIC
# MAGIC         for num, vetto in enumerate(vectorizers_list):
# MAGIC             print("\nvectorizer: " , vetto)
# MAGIC             evaluate_performance(X,y, vettorizzatore=vetto, test_size=0.3)
# MAGIC             print("\n")
# MAGIC
# MAGIC

# COMMAND ----------

#other_cat_dict

# COMMAND ----------

#winner : tfidf_vect_ngram_chars5

# COMMAND ----------

# MAGIC %md
# MAGIC # Predict

# COMMAND ----------

#dizio con variabili label e testo associate
text_and_label_dict = {"complaint": {"text":"complaint_translated" , "label":'problem_statement' },
                        "cause": {"text": "cause_translated", "label": 'cluster_cause'},
                        "correction": {"text": "correction_translated", "label":"correction"}}

# COMMAND ----------

#Splittare in train-test
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report


def predict_xgbusta(X_train: pd.Series, y_train: pd.Series, X_predict:pd.Series, vettorizzatore):
    
    #preprocessing della X
    X_preproc = preprocess(X_train)

    #assign a numerical label to text
    labels_swapped = dict(enumerate(set(y_train)))
    labels_num = {v: k for k, v in labels_swapped.items()}
    #apply new labels
    y_numeric = y_train.apply(lambda x: labels_num[x])


    # Text data and labels
    #testo e labels
    texts = X_preproc
    labels = y_numeric.to_list()

    #scegliere un vectorizer
    vectorizer = vettorizzatore

    # Convert text data into numerical features using chosen vectorizer
    X_train_vectorized = vectorizer.fit_transform(X_train)
    X_predict_vectorized = vectorizer.transform(X_predict)

    #modello
    model = xgb.XGBClassifier(max_depth= 2, 
                                n_estimators=1000,
                                eta= 0.01, 
                                objective="multi:softmax",
                                eval_metric="merror",
                                seed= 1,
                                num_class= len(labels_num))
    
    #fit del modello sui dati di training 
    model = model.fit(X_train_vectorized, labels)

    #predizioni del modello
    predictions = model.predict(X_predict_vectorized)

    predictions_labeled = pd.Series(predictions, index=X_predict.index).map(lambda x: labels_swapped[x])

    return predictions_labeled

# COMMAND ----------


################## PARAMS #############
comment_part = "cause"

soglia = 30
vettorizzatore = tfidf_vect_ngram_chars5

######################################

for comment_part in ["complaint", "cause", "correction"]:

    #prepare training data
    var_testo = text_and_label_dict[comment_part]["text"]
    var_classe = text_and_label_dict[comment_part]["label"]

    #obtain X and y from training data
    X_train, y_train, X_predict, other_cat = prepare_train_data(dataset=df, variabile_testo=var_testo, variabile_classe=var_classe, soglia=soglia)

    predictions = predict_xgbusta(X_train=X_train, y_train=y_train, X_predict=X_predict, vettorizzatore=vettorizzatore)
    predictions.name = comment_part + "_predicted"

    df = pd.merge(df, predictions, left_index=True, right_index=True, how="left")


# COMMAND ----------

df.to_csv(f"/dbfs/FileStore/tables/reliab/NLP Projects/20240118 7500 claim/MY22_CLAIM_7500_claims_translated_xgboost_predicted_{soglia}.csv", index = False)

# COMMAND ----------

df.groupby("complaint_predicted").row_number.count()

# COMMAND ----------

# MAGIC %md
# MAGIC display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Flag Training Data

# COMMAND ----------

df.columns

# COMMAND ----------

for part, values in text_and_label_dict.items():
    df[part + "_predicted_partition"] = df.apply(lambda x:
                                                 "TRAINING" if pd.isnull(x[values["label"]])==False
                                                 else ("PREDICTION" if pd.isnull(x[values["text"]])==False else "NULL"),
                                                 axis = 1)

# COMMAND ----------

df

# COMMAND ----------

# MAGIC %md
# MAGIC ### Topic Modeling for "OTHER" category

# COMMAND ----------

df

# COMMAND ----------

# MAGIC %md
# MAGIC # To Catalog for SAS migration

# COMMAND ----------

#correct df names for saving to catalog
new_col_names = [x.lower().replace(" ", "").strip() for x in df.columns]
df.columns = new_col_names

sdf = spark.createDataFrame(df)

# COMMAND ----------

sdf.write.mode("overwrite").saveAsTable(f"reliab.20240314_NLP_7500Claims_xgboost_predicted_soglia{soglia}")

# COMMAND ----------

print(f"reliab.20240314_NLP_7500Claims_xgboost_predicted_soglia{soglia}")

# COMMAND ----------

