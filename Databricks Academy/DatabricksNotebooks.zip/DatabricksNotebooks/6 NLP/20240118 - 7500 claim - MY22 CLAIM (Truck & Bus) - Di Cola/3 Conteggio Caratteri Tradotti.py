# Databricks notebook source
sdf = spark.read.table("reliab.20240118_NLP_7500claims")

# COMMAND ----------

from pyspark.sql.functions import length,sum

sdf.select(sum(length("Failure_Comment"))).show()

# COMMAND ----------

