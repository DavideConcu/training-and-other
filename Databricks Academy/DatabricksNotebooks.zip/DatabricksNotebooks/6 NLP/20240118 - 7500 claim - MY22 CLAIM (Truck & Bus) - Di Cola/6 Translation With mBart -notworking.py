# Databricks notebook source
# MAGIC %pip install transformers torch sentencepiece fasttext

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Data

# COMMAND ----------

sdf = spark.read.table("reliab.20240124_NLP_7500claims_LanguageDetection")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Convert FastText Label to Mbart Language Source Input Label

# COMMAND ----------

import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType
from typing import Iterator

@pandas_udf(StringType())
def convert_language_label(batch_labels:pd.Series) -> pd.Series: 
    """function for converting label from fasttext to language input for translation"""
    def convert_label(label):
        #ceco
        if label == "__label__ces_Latn":
            label_new = "cs_CZ"
        #tedesco
        elif label == "__label__deu_Latn":
            label_new = "de_DE"
        #inglese
        elif label == "__label__eng_Latn":
            label_new = "en_XX"
        #spagnolo
        elif label == "__label__spa_Latn":
            label_new = "es_XX"
        #portoghese
        elif label == "__label__por_Latn":
            label_new = "pt_XX"
        #francese
        elif label == "__label__fra_Latn":
            label_new = "fr_XX"
        #italiano
        elif label == "__label__ita_Latn":
            label_new = "it_IT"
        #olandese
        elif label == "__label__nld_Latn":
            label_new = "nl_XX"
        #croato
        elif label == "__label__hrv_Latn":
            label_new = "hr_HR"
        #polacco
        elif label == "__label__pol_Latn":
            label_new = "pl_PL"
        #turco
        elif label == "__label__tur_Latn":
            label_new = "tr_TR"
        #svedese
        elif label == "__label__swe_Latn":
            label_new = "sv_SE"
        #finlandese
        elif label == "__label__fin_Latn":
            label_new = "fi_FI"
        #lituano
        elif label == "__label__lit_Latn":
            label_new = "lt_LT"
        #lettone
        elif label == "__label__lvs_Latn":
            label_new = "lv_LV"
        #estone
        elif label == "__label__est_Latn":
            label_new = "et_EE"
        #ucraino
        elif label == "__label__ukr_Cyrl":
            label_new = "uk_UA"
        #slovacco
        elif label == "__label__slk_Latn":
            label_new = "sl_SI"    
        #georgiano
        elif label == "__label__kat_Geor":
            label_new = "ka_GE" 
        #macedone
        elif label == "__label__mkd_Cyrl":
            label_new = "mk_MK" 
        #other
        else:
            label_new = "OTHER"
            
        return label_new
    
    converted_labels = batch_labels.apply(lambda x: convert_label(x))
    
    return converted_labels


# COMMAND ----------

from pyspark.sql.functions import col 

sdf = sdf.withColumn("new_label", convert_language_label(col("language")))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Eliminazione delle lingue non supportate

# COMMAND ----------

from pyspark.sql.functions import col

#drop if not supported
sdf = sdf.filter(col("new_label")!="OTHER")

sdf =sdf.select("new_label", "failure_comment")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Translation For Single Language

# COMMAND ----------

#from pyspark.sql.functions import first
#
#sdf_mock = sdf.groupBy("new_label").agg(first("failure_comment").alias("failure_comment"))
#
#display(sdf_mock)

# COMMAND ----------

#lista delle lingue supportate
supported_languages_list = sdf.select("new_label").distinct().rdd.flatMap(lambda x: x).collect()

# COMMAND ----------

#inizializzare il nuovo df
from pyspark.sql.types import StructField, StructType, StringType


schema = StructType([StructField("new_label",StringType(),True), 
                     StructField("failure_comment",StringType(),True), 
                     StructField("translation",StringType(),True)])

#dataset finale 
emptyRDD = spark.sparkContext.emptyRDD()
final_sdf = spark.createDataFrame(emptyRDD,schema=schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Translation PUDF

# COMMAND ----------

#pandas udf for translating text
import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType
from typing import Iterator, Tuple
from transformers import MBartForConditionalGeneration, MBart50TokenizerFast

model = MBartForConditionalGeneration.from_pretrained("facebook/mbart-large-50-many-to-many-mmt")
#tokenizer = MBart50TokenizerFast.from_pretrained("facebook/mbart-large-50-many-to-many-mmt")
#tokenizer.src_lang = "it_IT"

# Create pandas_udf()
@pandas_udf(StringType())
def translate(failure_comment_batch: pd.Series) -> pd.Series:
        encoded = failure_comment_batch.apply(lambda x: tokenizer(x, return_tensors="pt"))
        generated_tokens = encoded.apply(lambda x: model.generate(**x, forced_bos_token_id=tokenizer.lang_code_to_id["en_XX"]))
        translation = generated_tokens.apply(lambda x: tokenizer.batch_decode(x, skip_special_tokens=True)[0])
        return translation


# COMMAND ----------


#traduzione una lingua alla volta
for language in supported_languages_list:

    print(language)

    #reload per sicurezza
    tokenizer = MBart50TokenizerFast.from_pretrained("facebook/mbart-large-50-many-to-many-mmt")

    #source language
    tokenizer.src_lang = language

    #filtrare il df
    sdf_single_language = sdf.filter(col("new_label")==language)

    #added translation
    sdf_single_language = sdf_single_language.withColumn("translation",  translate("failure_comment"))

    #union
    final_sdf = final_sdf.union(sdf_single_language)




# COMMAND ----------

final_sdf.write.saveAsTable("reliab.20240125_NLP_7500claims_translationAllLanguagesLoop")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM reliab.20240125_NLP_7500claims_translationAllLanguagesLoop

# COMMAND ----------

americans = spark.createDataFrame(
    [("bob", 42), ("lisa", 59)], ["first_name", "age"]
)
colombians = spark.createDataFrame(
    [("maria", 20), ("camilo", 31)], ["first_name", "age"]
)
res = americans.union(colombians)
res.show()

# COMMAND ----------

americans = spark.createDataFrame(
    [("bob", 42), ("lisa", 59)], ["first_name", "age"]
)
colombians = spark.createDataFrame(
    [( 20, "eee"), ( 31, "ddddd")], ["age", "first_name"]
)
res = americans.unionByName(colombians)
res.show()

# COMMAND ----------

