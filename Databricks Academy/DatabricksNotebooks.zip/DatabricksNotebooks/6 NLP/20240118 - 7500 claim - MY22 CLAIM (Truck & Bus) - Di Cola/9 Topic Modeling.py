# Databricks notebook source
# MAGIC %pip install xgboost nltk dataprep gensim tensorflow -U spacy

# COMMAND ----------

# MAGIC %sh
# MAGIC python -m spacy download en_core_web_sm

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load Data

# COMMAND ----------

import pandas as pd

df = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/MY22_CLAIM__Truck___Bus____7500_claims___translated___training___all_variables.xlsx" , dtype={'claim_number': str, 'dealer_claim_number': str})

df.drop("wheelbase", axis = 1 , inplace=True)
df.drop("unnamed:_65", axis = 1 , inplace=True)


# COMMAND ----------

df["dealer_claim_number"].sort_values(ascending=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pre-processing

# COMMAND ----------

#load stop words list 
import nltk
nltk.download('stopwords')
nltk.download('wordnet')

# importing the relevant packages
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import re

# Pre Processing
stop_words = stopwords.words('english') # creates a list of English stop words

stop_words += ["fault", "faulty"]

wnl = WordNetLemmatizer() # I used lemmatizing instead of stemming
def preprocess(text_column):
    """
    Function:    This function aims to remove links, special 
                 characters, symbols, stop words and thereafter 
                 lemmatise each word in the sentence to transform 
                 the dataset into something more usable for a 
                 machine learning model.
    Input:       A text column
    Returns:     A text column (but transformed)
    """
    new_review = []
    for review in text_column:
        # for every sentence, we perform the necessary pre-processing
        text = re.sub("@\S+|https?:\S+|http?:\S|[^A-Za-z0-9]+", 
                        ' ', 
                        str(review).lower()).strip()
        text = [wnl.lemmatize(i) for i in text.split(' ') if i not in stop_words]
        new_review.append(' '.join(text)) 

    return new_review

# COMMAND ----------

df.columns

# COMMAND ----------

#rimuovere i numeri e simboli
import re

def remove_numbers_and_symbols(text):
    # Define the regex pattern to match numbers and symbols
    pattern = r'[^a-zA-Z\s]'  # Matches anything that is not a letter or whitespace

    text = re.sub(r'\bwpa\b', '', text)
    text = re.sub(r'\btwo\b', '', text)
    text = re.sub(r'\bfault\b', '', text)



    # Use sub() method to replace matches with an empty string

    cleaned_text = re.sub(pattern, '', text)
    
    return cleaned_text


for col_to_clean in [x for x in df.columns if "translated" in x]:
    print(col_to_clean)
    df[col_to_clean + "_clean"] = preprocess(df[col_to_clean].apply(lambda x: remove_numbers_and_symbols(x)))

# COMMAND ----------

import pandas as pd
import spacy

# Load the spaCy English language model
nlp = spacy.load("en_core_web_sm")

# Function to filter out non-noun tokens from a document
def filter_nouns(text:str, pos:list):
    doc = nlp(text)
    return ' '.join([token.text for token in doc if token.pos_ in pos])


for col_to_clean in [x for x in df.columns if "translated_clean" in x]:

    # Sample documents
    documents = df[col_to_clean].tolist()

    # Filter out non-nouns from each document
    if col_to_clean == "correction_translated_clean":
        pos_to_keep = ["NOUN", "VERB"]
    else:
        pos_to_keep = ["NOUN"]


    filtered_documents = [filter_nouns(doc, pos_to_keep) for doc in documents]

    # Replace the original column with the filtered documents
    df[col_to_clean + "_pos"] = filtered_documents


# COMMAND ----------

#mettere il commento intero quando il part of speech è mancante
import pandas as pd

for col in ["complaint_translated_clean", "cause_translated_clean", "correction_translated_clean", "entire_comment_translated_clean"]:
    print(f"missing in {col}:", df[(pd.isnull(df[col + "_pos"])==True) | (df[col + "_pos"]=="")].row_number.count())
    df[col + "_pos"] = df.apply(lambda x: x[col] if ((pd.isnull(x[col + "_pos"])==True) | (x[col + "_pos"]=="")) else x[col + "_pos"], axis=1)
    print(f"now missing in {col}:", df[(pd.isnull(df[col + "_pos"])==True) | (df[col + "_pos"]=="")].row_number.count(), "\n")


# COMMAND ----------

df[(pd.isnull(df[col + "_pos"])==True) | (df[col + "_pos"]=="")]

# COMMAND ----------

df

# COMMAND ----------

df.to_csv("/dbfs/FileStore/tables/reliab/Progetti Vari/MY22_7500_claims_translated_training_allvar_readytoTopicModeling.csv", index=False)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Topic Modeling

# COMMAND ----------

df = pd.read_csv("/dbfs/FileStore/tables/reliab/Progetti Vari/MY22_7500_claims_translated_training_allvar_readytoTopicModeling.csv")


# COMMAND ----------

import pandas as pd
import gensim
from gensim import corpora
from gensim.models import LdaModel
from pprint import pprint



def giro_di_topi(dataframe:pd.DataFrame,column:str, num_topics:int):

    df = dataframe.copy()

    # Sample documents
    documents = df[column].to_list()

    # Tokenize documents
    tokenized_documents = [doc.lower().split() for doc in documents]

    # Create dictionary
    dictionary = corpora.Dictionary(tokenized_documents)

    # Create corpus (bag-of-words representation)
    corpus = [dictionary.doc2bow(doc) for doc in tokenized_documents]

    # Build LDA model using bag-of-words corpus
    lda_model_bow = LdaModel(corpus=corpus, id2word=dictionary, num_topics=num_topics, passes=200)

    # Function to get the most prominent topic for each document
    def get_most_prominent_topic(lda_model, doc):
        bow = dictionary.doc2bow(doc)
        return max(lda_model[bow], key=lambda x: x[1])[0]

    # Get most prominent topic for each document
    most_prominent_topics = [get_most_prominent_topic(lda_model_bow, doc) for doc in tokenized_documents]

    # Add 'most_prominent_topic' column to the dataframe
    df[f'{column}_topic'] = most_prominent_topics

    # Function to get the most prominent words for each topic
    def get_most_prominent_words(lda_model, num_words=10):
        topic_words = []
        for topic_id in range(lda_model.num_topics):
            topic_words.append([word for word, _ in lda_model.show_topic(topic_id, topn=num_words)])
        return topic_words

    # Get most prominent words for each topic
    topic_words = get_most_prominent_words(lda_model_bow)

    # Function to describe each topic
    def describe_topic(topic_words):
        # You can add more sophisticated methods to describe topics here
        return ', '.join(topic_words)

    # Describe each topic
    topic_descriptions = [describe_topic(words) for words in topic_words]

    # Add topic information to the dataframe
    topic_info = pd.DataFrame({'topic_id': range(lda_model_bow.num_topics),
                            f'{column}_topic_words': topic_words})

    # Merge topic information with the dataframe
    df = pd.merge(df, topic_info, left_on=f'{column}_topic', right_on='topic_id', how='left')

    # Drop redundant columns
    df.drop(columns=['topic_id'], inplace=True)

    return df


# COMMAND ----------

col_to_topic_model = ['complaint_translated_clean_pos',
                      'cause_translated_clean_pos',
                      'correction_translated_clean_pos',
                      'entire_comment_translated_clean_pos']

for colonna in col_to_topic_model:
    #drop null
    df_dropnulls = df.loc[~df[colonna].isnull(),  ["row_number", colonna]]

    #df topi
    df_topi = giro_di_topi(dataframe=df_dropnulls, column=colonna, num_topics=15)

    #drop della colonna analizzata
    df_topi.drop(columns=[colonna], inplace=True)

    #merge con il dataset intero
    df = pd.merge(df, df_topi, on="row_number", how="left")

# COMMAND ----------

df.to_csv("/dbfs/FileStore/tables/reliab/Progetti Vari/MY22_7500_claims_translated_training_allvar_topicresults.csv", index=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### To catalog

# COMMAND ----------

def clean_column_names(df):
    cleaned_columns = [col.replace('"', '')
                             .replace(',', '')
                             .replace(';', '')
                             .replace('{', '')
                             .replace('}', '')
                             .replace('(', '')
                             .replace(')', '')
                             .replace('\n', '')
                             .replace('\t', '')
                             .replace('=', '')
                             .strip() for col in df.columns]
    df.columns = cleaned_columns
    return df



# Clean column names
df = clean_column_names(df)

sdf = spark.createDataFrame(df)

# COMMAND ----------

#save to catalog
sdf.write.mode("overwrite").saveAsTable("reliab.20240308_NLP_7500_topicModeling_pos")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Visualize Results

# COMMAND ----------

# MAGIC %md
# MAGIC import matplotlib.pyplot as plt
# MAGIC
# MAGIC # Function to plot histogram for top words of each topic
# MAGIC def plot_topic_histogram(lda_model, num_words=5):
# MAGIC     topics = lda_model.show_topics(formatted=False, num_topics=-1, num_words=num_words)
# MAGIC     for topic_id, topic in topics:
# MAGIC         words = [word for word, _ in topic]
# MAGIC         weights = [weight for _, weight in topic]
# MAGIC         plt.figure(figsize=(10, 5))
# MAGIC         plt.barh(words, weights, color='skyblue')
# MAGIC         plt.xlabel('Word Importance')
# MAGIC         plt.title(f'Topic {topic_id} - Top {num_words} Words')
# MAGIC         plt.gca().invert_yaxis()
# MAGIC         plt.show()
# MAGIC
# MAGIC # Plot histogram for top words of each topic
# MAGIC plot_topic_histogram(lda_model_bow)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM reliab.20240308_NLP_7500_topicModeling_pos
# MAGIC limit 10

# COMMAND ----------

