# Databricks notebook source
# MAGIC %md
# MAGIC # Merge with Original Dataset

# COMMAND ----------

sdf = spark.read.table("reliab.20240118_NLP_7500claims")

# COMMAND ----------

#percorso del file
path = "/dbfs/FileStore/tables/reliab/NLP Projects/20240118 7500 claim/"
file = "only_7500_claims"
ext = ".xlsx"

import pandas as pd 

original_file = pd.read_excel(path + file + ext)


#row number come id
original_file = original_file.reset_index()


# COMMAND ----------

# MAGIC %md
# MAGIC ## Cambiare il nome delle colonne

# COMMAND ----------

#change column names - for writing spark dataframe to catalog
invalid_characters = " ,;{}()\n\t="

cols = original_file.columns

newcols = []
for col in cols:
    newcol = col
    for char in invalid_characters:
        newcol = newcol.replace(char, "_")
    newcols.append(newcol)

original_file.columns = newcols

# COMMAND ----------

