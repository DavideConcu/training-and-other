# Databricks notebook source
# MAGIC %md
# MAGIC # Translation Test with PUDF

# COMMAND ----------

# MAGIC %pip install google-cloud-translate==2.0.1

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load CSV File and create Spark DataFrame

# COMMAND ----------

import pandas as pd

#percorso del file
path = "/dbfs/FileStore/tables/reliab/NLP Projects/20240118 7500 claim/"
file = "only_7500_claims_cleanedsplitted"
ext = ".csv"

#failure comment var 
failure_comment_var = "Failure Comment"


df = pd.read_csv(path + file + ext)

# COMMAND ----------

#change column names - for writing spark dataframe to catalog
invalid_characters = " ,;{}()\n\t="

cols = df.columns

newcols = []
for col in cols:
    newcol = col
    for char in invalid_characters:
        newcol = newcol.replace(char, "_")
    newcols.append(newcol)

df.columns = newcols


# COMMAND ----------

#create spark dataframe
sdf = spark.createDataFrame(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Translation PUDF - GC Translate API

# COMMAND ----------

import os
from google.oauth2 import service_account
from google.cloud import translate_v2 as translate

credentials = service_account.Credentials.from_service_account_file("/dbfs/FileStore/tables/reliab/Text Mining - Wiring Harness/amazing_insight_411413_d7ebbd4134a0.json")

translate_client = translate.Client(credentials=credentials)

# COMMAND ----------

#pandas udf for translating text
import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType

# Create pandas_udf()
@pandas_udf(StringType())
def translate_pudf_en(comment_column: pd.Series) -> pd.Series:
    translate_client = translate.Client(credentials=credentials)
    translated_column = comment_column.apply(lambda text: translate_client.translate(text, target_language="en", format_="text")["translatedText"])
    translated_column_series = pd.Series(translated_column)
    return translated_column_series

# COMMAND ----------

# MAGIC %md
# MAGIC ## Apply Function to Spark Dataframe

# COMMAND ----------

from pyspark.sql.functions import col

for column in ["complaint", "cause", "correction"]:
    sdf = sdf.withColumn(f"{column}_translated", translate_pudf_en(col(column)))

# COMMAND ----------

from pyspark.sql.functions import col, concat, lit
sdf = sdf.withColumn("entire_comment_translated" , concat(col("complaint_translated"), lit(". "), col("cause_translated"), lit(". "), col("correction_translated"), lit(".")))

# COMMAND ----------

#tradurre in italiano
# Create pandas_udf()
@pandas_udf(StringType())
def translate_pudf_it(comment_column: pd.Series) -> pd.Series:
    translate_client = translate.Client(credentials=credentials)
    translated_column = comment_column.apply(lambda text: translate_client.translate(text, target_language="it", format_="text")["translatedText"])
    translated_column_series = pd.Series(translated_column)
    return translated_column_series

sdf = sdf.withColumn(f"entire_comment_translated_italian", translate_pudf_it(col("entire_comment_translated")))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Eliminare le virgole

# COMMAND ----------

from pyspark.sql.functions import col, concat, lit
sdf = spark.read.table("reliab.20240118_NLP_7500claims")

sdf = sdf.withColumn("entire_comment_translated" , concat(col("complaint_translated"), lit(". "), col("cause_translated"), lit(". "), col("correction_translated"), lit(".")))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import regexp_replace, col


for column in [x for x in sdf.columns if x != "index" ]:
    sdf = sdf.withColumn(column , regexp_replace(col(column), "[,@\+\#\$\^\!\,]+", ""))



# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Spark Dataframe to Catalog

# COMMAND ----------

sdf.write.mode("overwrite").saveAsTable("reliab.20240118_NLP_7500claims")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check Results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM reliab.20240118_NLP_7500claims

# COMMAND ----------

