# Databricks notebook source
# MAGIC %pip install nltk transformers torch  --upgrade numpy

# COMMAND ----------

#load stop words list 
import nltk
nltk.download('stopwords')
nltk.download('wordnet')

# importing the relevant packages
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import re

# Pre Processing
stop_words = stopwords.words('english') # creates a list of English stop words
wnl = WordNetLemmatizer() # I used lemmatizing instead of stemming
def preprocess(text_column):
    """
    Function:    This function aims to remove links, special 
                 characters, symbols, stop words and thereafter 
                 lemmatise each word in the sentence to transform 
                 the dataset into something more usable for a 
                 machine learning model.
    Input:       A text column
    Returns:     A text column (but transformed)
    """
    new_review = []
    for review in text_column:
        # for every sentence, we perform the necessary pre-processing
        text = re.sub("@\S+|https?:\S+|http?:\S|[^A-Za-z0-9]+", 
                        ' ', 
                        str(review).lower()).strip()
        text = [wnl.lemmatize(i) for i in text.split(' ') if i not in stop_words]
        new_review.append(' '.join(text)) 

    return new_review

# COMMAND ----------

#specs
path = "/dbfs/FileStore/tables/reliab/NLP Projects/20240118 7500 claim/"
filename = "MY22_CLAIM__Truck___Bus____7500_claims___translated___training"
ext = ".xlsx"

# COMMAND ----------

import pandas as pd

#load df
df = pd.read_excel(path + filename + ext)

new_colnames = [x.lower().strip().replace(" ","_") for x in df.columns]

df.columns = new_colnames

for col in ["complaint", "cause", "correction"]:
    df[col+"_translated_clean"] = preprocess(df[col+"_translated"])
    df = df.loc[~df[col+"_translated_clean"].isnull()]


#creare spark df
sdf = spark.createDataFrame(df)

# COMMAND ----------

display(sdf)

# COMMAND ----------

#apply to df
#qual'è la lamentela?
questionComplaint = "what is the problem?"
questionComplaint = "what is the main complaint?"


#qual'è la ragione del guasto?
questionCause = "what is the main reason that caused the fault?"

#qual'è il componente difettoso?
questionDefectiveComponent = "which is the main defective component?"



#qual'è la ragione del guasto?
questionCorrection = "how was fixed?"
questionCorrection = "what main action was done for correcting the issue?"




# COMMAND ----------

from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType
from transformers import pipeline

question_answerer = pipeline("question-answering")



@pandas_udf(StringType())
def predict_complaint(text: pd.Series) -> pd.Series:

    pred = text.apply(lambda x: question_answerer(context=x, question=questionComplaint)["answer"])
    res = pd.Series(pred)
    return res

@pandas_udf(StringType())
def predict_cause(text: pd.Series) -> pd.Series:

    pred = text.apply(lambda x: question_answerer(context=x, question=questionCause)["answer"])
    res = pd.Series(pred)
    return res


@pandas_udf(StringType())
def predict_correction(text: pd.Series) -> pd.Series:

    pred = text.apply(lambda x: question_answerer(context=x, question=questionCorrection)["answer"])
    res = pd.Series(pred)
    return res

@pandas_udf(StringType())
def predict_defectivecomponent(text: pd.Series) -> pd.Series:

    pred = text.apply(lambda x: question_answerer(context=x, question=questionDefectiveComponent)["answer"])
    res = pd.Series(pred)
    return res

# COMMAND ----------

from pyspark.sql.functions import col


predicted = sdf\
                .withColumn("complaint_predict",          predict_complaint(col("complaint_translated")))\
                .withColumn("cause_predict",              predict_cause(col("cause_translated")))\
                .withColumn("correction_predict",         predict_correction(col("correction_translated")))\



    

# COMMAND ----------

predicted.write.saveAsTable("reliab.20240306_NLP_7500Claims_zeroshotprediction_2")

# COMMAND ----------

df = spark.read.table("reliab.20240306_NLP_7500Claims_zeroshotprediction_2")

# COMMAND ----------

display(df)

# COMMAND ----------

