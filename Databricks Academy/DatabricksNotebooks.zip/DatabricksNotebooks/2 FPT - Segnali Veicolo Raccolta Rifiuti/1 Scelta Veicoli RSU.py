# Databricks notebook source
# MAGIC %md
# MAGIC # Segnali Veicoli RSU 

# COMMAND ----------

from pyspark.sql.functions import col

df = spark.read.table("reliab.20230713_rgdailycng_allchassisclusteredwithbothmethods")\
            .filter(col("onlyMtbfVehiclesLess5000") == False)\
            .filter(col("mtbf").isNotNull())


# COMMAND ----------

#il cluster con l'mbtf più basso è il 5
display(df.groupBy("cluster").mean().sort(col("avg(mtbf)").desc()))

df = df.filter(col("cluster")==5)

# COMMAND ----------

#vedere gli chassis con più percentuale di ecology e con almeno 10k km
display(df
        .filter(col("totaldistance")>10000)
        .sort(col("ECOLOGY").desc()))

# COMMAND ----------

#chassis scelto - TOP
chassisRSU = "ZCFCN35A605305452"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Vedere tutte le Mission aggregate del veicolo scelto

# COMMAND ----------

df = spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
            .filter(col("chassis")==chassisRSU)

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### check altri veicoli tekneko

# COMMAND ----------

teknekoChassis = spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
            .filter(col("customer")=="TEKNEKO").select("chassis").distinct()

# COMMAND ----------

display(teknekoChassis)

# COMMAND ----------

# MAGIC %md
# MAGIC #VEICOLO SCELTO: ZCFCN35A605305452