# Databricks notebook source
# MAGIC %md
# MAGIC #Extract Raw Signals

# COMMAND ----------

dataset = "datacollector.datacollector_tabular_mission_for_wti_daily_prod"

chassisRSU = "ZCFCN35A605305452"

# COMMAND ----------

from pyspark.sql.functions import col

#spark.read.table(dataset)\
#        .filter(col("chassis")==chassisRSU)\
#        .filter(col("Accumulator")>0)\
#        .write.saveAsTable("reliab.20230906_FPTsegnaliGrezziRSU_prova1")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT nameitem
# MAGIC FROM reliab.20230906_FPTsegnaliGrezziRSU_prova1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT nameitem
# MAGIC FROM reliab.20230906_FPTsegnaliGrezziRSU_prova1
# MAGIC WHERE nameitem like "%OilLevel%"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM reliab.20230906_FPTsegnaliGrezziRSU_prova1
# MAGIC WHERE nameitem in ("EngOilLevelLampAtEnd_v01", "EngineOilLevelAvg_v02" ,"EngineOilLevelAtEnd_v02" , "CALC_EngineOilLevelAvg_v02", "EngineOilLevelAtStart_v02")

# COMMAND ----------

