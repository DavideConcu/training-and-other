# Databricks notebook source
import pandas as pd 

chassis = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/crankshaft_chassis_list_UPDATED.xlsx")

chassis_sdf = spark.createDataFrame(chassis).distinct()

# COMMAND ----------

vehicles = spark.read.table("edwh.vehicle")\
                        .selectExpr("pvan_cd_vin_code as chassis", 
                                    "pvcb_ds_sub_product_cl as product_fromedwh",
                                    "pvan_id_warranty_start_date as warr_startdate_fromedwh",
                                    "cust_ds_cust_nm_customer as customer_fromedwh", 
                                    "cust_ds_cust_nm_dealer as dealer_fromedwh",
                                    "saor_ds_sales_organizat_sdes as sale_org_fromedwh")
                        

chassis_edwh_sdf = chassis_sdf.join(vehicles, "chassis", "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## List of Lost Vehicles

# COMMAND ----------

df = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data").select("chassis").distinct()

# COMMAND ----------

display(chassis_edwh_sdf.join(df, "chassis", "leftanti"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Extract Data

# COMMAND ----------

from pyspark.sql.functions import col

dati_collector = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")

chassis_datacoll_sdf = chassis_edwh_sdf.join(dati_collector, "chassis","left")\
                                            .filter((col("startofsampling")>col("warr_startdate_fromedwh"))|(col("endofsampling")>col("warr_startdate_fromedwh")))


# COMMAND ----------

# MAGIC %md
# MAGIC ## Save

# COMMAND ----------

chassis_datacoll_sdf.write.mode("overwrite")\
                        .option("overwriteschema", "true")\
                        .saveAsTable("reliab.20240130_Vari_Weibullf1ccrankshaft_data")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(*) 
# MAGIC from reliab.20240130_Vari_Weibullf1ccrankshaft_data

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(DISTINCT Chassis) 
# MAGIC from reliab.20240130_Vari_Weibullf1ccrankshaft_data

# COMMAND ----------

