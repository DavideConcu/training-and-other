# Databricks notebook source
# MAGIC %md
# MAGIC ## Collect Data For Every Daily F1C
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import col

vehicles = spark.read.table("edwh.vehicle")\
                        .selectExpr("pvan_cd_vin_code as chassis", 
                                    "pvcb_ds_sub_product_cl as product_fromedwh",
                                    "pvan_id_warranty_start_date as warr_startdate_fromedwh",
                                    "cust_ds_cust_nm_customer as customer_fromedwh", 
                                    "cust_ds_cust_nm_dealer as dealer_fromedwh",
                                    "saor_ds_sales_organizat_sdes as sale_org_fromedwh")\
                                        .filter(col("product_fromedwh")=="44 DAILY CV- MY21 F1C - DIESEL")
                        



# COMMAND ----------

#join con datacollector
dati_collector = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")


dati_allf1c = vehicles.join(dati_collector, "chassis")\
                      .filter(col("startofsampling")>col("warr_startdate_fromedwh"))

# COMMAND ----------

#save data
#dati_allf1c.write.saveAsTable("reliab.20240201_Vari_DailyMy21F1C_alldata")

# COMMAND ----------

from pyspark.sql.functions import col, when

lista_broken = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data").select("chassis").distinct().rdd.flatMap(lambda x: x).collect()

spark.read.table("reliab.20240201_Vari_DailyMy21F1C_alldata")\
                .withColumn("is_bad", when(col("chassis").isin(lista_broken), True).otherwise(False))\
                    .write.mode("overwrite").saveAsTable("reliab.20240201_Vari_DailyMy21F1C_alldata")

# COMMAND ----------

from pyspark.sql.functions import col

spark.read.table("reliab.20240201_Vari_DailyMy21F1C_alldata").filter(col("is_bad")==True).select("chassis").distinct().count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Confronto

# COMMAND ----------

#lista dei veicoli rotti
broken_vehicles_list = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data")\
                         .select("chassis").distinct()


#antijoin con i veicoli rotti dal dataset com tutti i dati (leftantijoin)
good_vehicles_data = spark.read.table("reliab.20240201_Vari_DailyMy21F1C_alldata")\
                          .join(broken_vehicles_list, "chassis", "leftanti")



# COMMAND ----------

print(broken_vehicles_list.count(),
good_vehicles_data.select("chassis").distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolo avg speed veicoli sani

# COMMAND ----------

from pyspark.sql.functions import col, sum, avg

good_vehicles_avgspeed = good_vehicles_data.groupBy("chassis")\
                                        .agg(sum("totaldistance").alias("distance"), (sum("totaltime")/(60**2)).alias("time_hour"))\
                                          .select("*", (col("distance")/col("time_hour")).alias("avg_speed")) 

# COMMAND ----------

good_vehicles_avgspeed\
                .filter(col("distance")>1000)\
                        .select(avg(col("avg_speed"))).collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolo AAU Ore e KM per i Veicoli Sani

# COMMAND ----------

from pyspark.sql.functions import col, min, max

df = good_vehicles_data

first_and_last_acquisition =   df\
                                   .groupBy(col("chassis"))\
                                   .agg(min(col("endofsampling")).alias("minDate"), max(col("endofsampling")).alias("maxDate"))

df_filtered = df.join(first_and_last_acquisition, "chassis")\
        .filter((col("endofsampling")==col("minDate")) | (col("endofsampling")==col("maxDate")))\
        .selectExpr("chassis",  "minDate", "maxDate", "endofsampling", "engineWorkHours",  "odoAtEnd/1000 as odoAtEnd")\
        .orderBy("chassis", "startofsampling")\
        .distinct()

# COMMAND ----------

#dataset con tutte le mission

from pyspark.sql.functions import row_number, desc,col, collect_list, datediff, pow, abs

dateVariable = "endofsampling"

df_1rowPerVin = df_filtered\
                    .groupBy("chassis")\
                    .agg(collect_list(col(dateVariable)).alias("dates"), 
                            collect_list(col("engineWorkHours")).alias("engine"),
                            collect_list(col("odoAtEnd")).alias("odoAtEnd"))\
                    .select("*", 
                                abs(datediff(col("dates")[1], col("dates")[0])).alias("daysBetween"),
                                abs((col("engine")[1]-col("engine")[0])).alias("engineDiff"),
                                abs((col("odoAtEnd")[1]-col("odoAtEnd")[0])).alias("odoDiff")
                                )\
                    .select("*", ((365/col("daysBetween"))*col("engineDiff")).alias("AAU_Hours"),
                                    ((365/col("daysBetween"))*col("odoDiff")).alias("AAU_Km"))\
                    .filter(col("daysBetween")>0)\
                    .filter(col("AAU_Hours")>0)\
                    .filter(col("AAU_Km")>0)
                        #.filter(col("daysBetween")>180)
                    


                            

# COMMAND ----------

from pyspark.sql.functions import mean

overall_mean = df_1rowPerVin.filter(col("daysBetween")>0)\
                        .select(mean(col("AAU_Hours")).alias("Mean AAU Hours"), mean(col("AAU_Km")).alias("Mean AAU Km"))

# COMMAND ----------

display(overall_mean)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Merge con avg speed

# COMMAND ----------

aau = df_1rowPerVin.select("chassis", "daysbetween", "enginediff", "ododiff", "aau_hours", "aau_km")


good_vehicles_avgspeed.join(aau, "chassis", "left")\
                                          .write.mode("overwrite")\
                                              .option("overwriteschema", "true")\
                                                  .saveAsTable("reliab.20240130_Vari_Weibullf1ccrankshaft_data_good_aauandavgspeed")

# COMMAND ----------

good_vehicles_avgspeed.select("chassis").distinct().count()


# COMMAND ----------

# MAGIC %md
# MAGIC ## Unire Good e Bad 

# COMMAND ----------

from pyspark.sql.functions import lit

good = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data_good_aauandavgspeed")\
                        .withColumn("is_bad", lit(False))


bad = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data_bad_aauandavgspeed")\
                        .withColumn("is_bad", lit(True))\
                            .withColumnRenamed("time_hours", "time_hour")


good_and_bad = bad.unionByName(good)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save

# COMMAND ----------

good_and_bad.write.mode("overwrite").saveAsTable("reliab.20240130_Vari_Weibullf1ccrankshaft_data_all_aauandavgspeed")

# COMMAND ----------

