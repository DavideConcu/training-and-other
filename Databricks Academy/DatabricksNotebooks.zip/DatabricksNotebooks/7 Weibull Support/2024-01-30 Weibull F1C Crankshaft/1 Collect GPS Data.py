# Databricks notebook source
spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
                FROM  reliab.20240130_Vari_Weibullf1ccrankshaft_data a 
                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b                 
                  ON a.chassis = b.chassis 
                    AND b.startofsampling >= a.startofsampling 
                    AND b.endOfSampling   <= a.endOfSampling """)\
                        .write.saveAsTable("reliab.20240130_Vari_Weibullf1ccrankshaft_data_gpspaths")


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(DISTINCT missionId)
# MAGIC FROM reliab.20240130_Vari_Weibullf1ccrankshaft_data_gpspaths

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(DISTINCT chassis)
# MAGIC FROM reliab.20240130_Vari_Weibullf1ccrankshaft_data_gpspaths

# COMMAND ----------

