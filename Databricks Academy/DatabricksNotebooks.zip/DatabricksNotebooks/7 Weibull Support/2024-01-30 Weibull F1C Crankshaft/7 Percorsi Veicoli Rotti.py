# Databricks notebook source
# MAGIC %md
# MAGIC # Selezionare un Campione di Percorsi per Dashboard crankshaft

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tenere solo n missionId per Vin

# COMMAND ----------

from pyspark.sql.functions import col

#lista delle mission dei vin 
missionList = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data")\
                    .selectExpr("chassis", "missionId", "totaltime/(3600) as time_h", "totaldistance as distance_km", "missiontype")\
                        .withColumn("average_speed", col("distance_km")/col("time_h"))\
                        .distinct()

# COMMAND ----------

#ordinare le mission in base alla distanza percorsa  oppure in base a missiontype?
#utilizzare le finestre

from pyspark.sql.functions import col, row_number
from pyspark.sql.window import Window

window = Window.partitionBy("chassis").orderBy(col("distance_km").desc())

missionList = missionList.withColumn("row_number", row_number().over(window))

#filtrare solo le 20 mission più lunghe
missionList = missionList.filter(col("row_number")<=20)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filtare il df dei percorsi

# COMMAND ----------

sdf = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data_gpspaths")\


sdf = missionList.join(sdf, ["chassis", "missionid"])


# COMMAND ----------

sdf.select("chassis", "missionid").distinct().count()

# COMMAND ----------

sdf.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save table

# COMMAND ----------

sdf.write.saveAsTable("reliab.20240212_Vari_Weibullf1ccrankshaft_gpssamplepathfordashboard")