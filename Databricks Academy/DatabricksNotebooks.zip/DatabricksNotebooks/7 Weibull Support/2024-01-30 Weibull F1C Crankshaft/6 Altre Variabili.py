# Databricks notebook source
# MAGIC %md
# MAGIC ## Calcolare medie per Veicolo di Stop, Peso, consumo carburante ecc

# COMMAND ----------

sdf = spark.read.table("reliab.20240201_Vari_DailyMy21F1C_alldata")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Media di stop per distanza

# COMMAND ----------

from pyspark.sql.functions import col, mean, sum

sum_by_chassis = sdf.groupBy("chassis", "is_bad")\
                              .agg(sum("totaldistance").alias("distance"),
                                   sum("stops").alias("stops"))\
                                .select("*", (col("stops")/(col("distance"))*100).alias("stopsPer1000km"))

# COMMAND ----------

display(sum_by_chassis.groupBy("is_bad").agg(mean("stopsPer1000km")))

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Gvw

# COMMAND ----------

from pyspark.sql.functions import substring, col
from pyspark.sql.types import IntegerType

df = df.withColumn("massa_massima", substring(col("chassis"), 6, 2).cast(IntegerType()))

#check con edwh
vehicles = spark.read.table("edwh.vehicle")\
                        .selectExpr("pvan_cd_vin_code as chassis",
                                    "prvp_ds_vp_sdes as massa_edwh")\
                                        .distinct()

df = df.join(vehicles, "chassis", "left")


df = df.withColumn("massa_massima", substring(col("chassis"), 6, 2).cast(IntegerType())*100)
df = df.withColumn("massa_massima_edwh", substring(col("massa_edwh"), 1, 2).cast(IntegerType())*100)
df = df.withColumn("gvw_ratio", col("gvw")/col("massa_massima"))
df = df.withColumn("gvw_ratio_edwh", col("gvw")/col("massa_massima_edwh"))


