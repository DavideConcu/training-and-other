# Databricks notebook source
# MAGIC %md
# MAGIC ## Load Data

# COMMAND ----------

df = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data")

# COMMAND ----------

print(df.count())
print(df.select("chassis").distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolo della data min e max 

# COMMAND ----------

from pyspark.sql.functions import col, min, max

first_and_last_acquisition =   df\
                                   .groupBy(col("chassis"))\
                                   .agg(min(col("endofsampling")).alias("minDate"), max(col("endofsampling")).alias("maxDate"))

df_filtered = df.join(first_and_last_acquisition, "chassis")\
        .filter((col("endofsampling")==col("minDate")) | (col("endofsampling")==col("maxDate")))\
        .selectExpr("chassis",  "minDate", "maxDate", "endofsampling", "engineWorkHours",  "odoAtEnd/1000 as odoAtEnd")\
        .orderBy("chassis", "startofsampling")\
        .distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolo AAU

# COMMAND ----------

#dataset con tutte le mission

from pyspark.sql.functions import row_number, desc,col, collect_list, datediff, pow, abs

dateVariable = "endofsampling"

df_1rowPerVin = df_filtered\
                    .groupBy("chassis")\
                    .agg(collect_list(col(dateVariable)).alias("dates"), 
                            collect_list(col("engineWorkHours")).alias("engine"),
                            collect_list(col("odoAtEnd")).alias("odoAtEnd"))\
                    .select("*", 
                                abs(datediff(col("dates")[1], col("dates")[0])).alias("daysBetween"),
                                abs((col("engine")[1]-col("engine")[0])).alias("engineDiff"),
                                abs((col("odoAtEnd")[1]-col("odoAtEnd")[0])).alias("odoDiff")
                                )\
                    .select("*", ((365/col("daysBetween"))*col("engineDiff")).alias("AAU_Hours"),
                                    ((365/col("daysBetween"))*col("odoDiff")).alias("AAU_Km"))\
                    .filter(col("daysBetween")>0)\
                    .filter(col("AAU_Hours")>0)\
                    .filter(col("AAU_Km")>0)
                    


                            

# COMMAND ----------

display(df_1rowPerVin)

# COMMAND ----------

from pyspark.sql.functions import mean

overall_mean = df_1rowPerVin.filter(col("daysBetween")>0)\
                        .select(mean(col("AAU_Hours")).alias("Mean AAU Hours"), mean(col("AAU_Km")).alias("Mean AAU Km"))


# COMMAND ----------

display(overall_mean)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Chassis with AAU

# COMMAND ----------

df_1rowPerVin.write.mode("overwrite").saveAsTable("reliab.20240130_Vari_Weibullf1ccrankshaft_data_AAU1rowpervin")

# COMMAND ----------

# MAGIC %md
# MAGIC ## AVG Speed

# COMMAND ----------

sdf = spark.read.table("reliab.20240130_Vari_Weibullf1ccrankshaft_data")

# COMMAND ----------

from pyspark.sql.functions import col, avg, sum

sdf_sumbyvin = sdf.groupby("chassis")\
                        .agg(sum("totaldistance").alias("distance"), (sum("totaltime")/(60**2)).alias("time_hours"))\
                            .select("*", (col("distance")/col("time_hours")).alias("avg_speed"))


# COMMAND ----------

# MAGIC %md
# MAGIC ## Merge con AAU

# COMMAND ----------

aau = df_1rowPerVin.select("chassis", "daysbetween", "enginediff", "ododiff", "aau_hours", "aau_km")


sdf_sumbyvin.join(aau, "chassis", "left")\
                    .write.mode("overwrite").saveAsTable("reliab.20240130_Vari_Weibullf1ccrankshaft_data_bad_aauandavgspeed")

# COMMAND ----------

sdf_sumbyvin.distinct().count()

# COMMAND ----------

sdf.select("chassis").distinct().count()

# COMMAND ----------

