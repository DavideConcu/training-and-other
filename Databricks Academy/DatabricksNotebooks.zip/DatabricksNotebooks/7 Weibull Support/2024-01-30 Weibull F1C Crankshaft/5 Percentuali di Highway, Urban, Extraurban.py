# Databricks notebook source
from pyspark.sql.functions import col

all_data_sdf = spark.read.table("reliab.20240201_Vari_DailyMy21F1C_alldata")

bad_data_sdf = all_data_sdf.filter(col("is_bad")==True)
good_data_sdf = all_data_sdf.filter(col("is_bad")==False)


# COMMAND ----------

bad_data_sdf.filter(col("is_bad")==True).select("chassis").distinct().count()

# COMMAND ----------

from pyspark.sql.functions import mean

all_data_sdf.groupBy("missionType").agg(mean(col("avg_speed"))).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolo percentuali per veicolo

# COMMAND ----------

from pyspark.sql.functions import sum, first

#raggruppare per sommare le distanze per vin e mission type
grouped = all_data_sdf.groupBy("chassis", "is_bad", "missionType").agg(sum(col("totaldistance")).alias("distance"))

#somma dei km totali per chassis
distance = all_data_sdf.groupBy("chassis").agg(sum(col("totaldistance")).alias("distance_sum"))

#merge con grouped
grouped = grouped.join(distance, "chassis")

#calcolare la percentuale
grouped = grouped.withColumn("distance_percent", col("distance")/col("distance_sum"))

#pivotare missiontype
grouped_pivoted = grouped.groupBy("chassis", "is_bad").pivot("missionType").agg(first("distance_percent"))

#aggiungere il km totale per vin
grouped_pivoted = grouped_pivoted.join(distance, "chassis")

# COMMAND ----------

display(grouped_pivoted)

# COMMAND ----------

grouped_pivoted.filter(col("is_bad")==True).count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Average Mission Type by is_bad

# COMMAND ----------

from pyspark.sql.functions import mean


mission = grouped_pivoted.groupBy("is_bad").agg( 
                                      mean("urbanHeavy").alias("urbanHeavy"),
                                      mean("urbanLight").alias("urbanLight"),
                                      mean("extraurban").alias("extraurban"), 
                                      mean("highway").alias("highway"))

# COMMAND ----------

display(mission)

# COMMAND ----------

display(grouped_pivoted)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare Tabella con Percentuali di tipo mission per ogni veicolo
# MAGIC

# COMMAND ----------

grouped_pivoted.write.mode("overwrite").saveAsTable("reliab.20240205_Vari_DailyMy21F1C_MissionTypePercentByVin")

# COMMAND ----------

