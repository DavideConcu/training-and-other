# Databricks notebook source
# MAGIC %md
# MAGIC ## Nuova Estrazione Completa CNG e NP

# COMMAND ----------

from pyspark.sql.functions import col

#lista dei veicoli da edwh
listaChassisDaEDWH = (spark.read.table("edwh.vehicle")\
                .filter((col("pvcb_ds_sub_product_cl").like("%DAILY%POWER%"))|(col("pvcb_ds_sub_product_cl").like("%DAILY%CNG%")))\
                .filter((col("pvan_ds_preliminary_model_year")=="MY2019")|(col("pvan_ds_preliminary_model_year")=="MY2021")))\
                .select(col("pvan_cd_vin_code").alias("chassis"), col("pvan_id_warranty_start_date").alias("warr_startdate"))

listaChassisDaEDWH.count()

# COMMAND ----------

#download super flat data
from pyspark.sql.functions import col


dati_collector = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")

dati_cngnp = listaChassisDaEDWH.join(dati_collector, "chassis")\
                    .filter(col("startofsampling") > col("warr_startdate"))


# COMMAND ----------

#write
#dati_cngnp.write.saveAsTable("reliab.20240216_Daily_CNGNP_my1921_alldata")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(DISTINCT chassis)
# MAGIC FROM reliab.20240216_Daily_CNGNP_my1921_alldata

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(DISTINCT chassis)
# MAGIC FROM  reliab.20230713_rgdailycng_allchassisclusteredwithbothmethods

# COMMAND ----------

