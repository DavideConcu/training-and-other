# Databricks notebook source
# MAGIC %md
# MAGIC ## Engine Work Hours al guasto e Totali

# COMMAND ----------

#flaggare i bad sui totali 
import pandas as pd 

chassis = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/vfailures_con_data_OLIO.xlsx")
chassis.columns = ["chassis", "failure_date"]
chassis_sdf = spark.createDataFrame(chassis).distinct()


chassis_oil_list = chassis_sdf.select("chassis").distinct()\
                            .rdd.flatMap(lambda x: x).collect()





# COMMAND ----------

from pyspark.sql.functions import col, lit, when

#tabella dei dati cng e np
all_cng_sdf = spark.read.table("reliab.20240216_Daily_CNGNP_my1921_alldata")

#aggiungere il flag del problema all'olio
all_cng_flag_sdf = all_cng_sdf.withColumn("oil_problem", when(col("chassis").isin(chassis_oil_list), True).otherwise(False))

#aggiunta della failure date
all_cng_flag_faildate_sdf = all_cng_flag_sdf.join(chassis_sdf, "chassis", "left")

all_cng_flag_faildate_sdf = all_cng_flag_faildate_sdf.withColumn("failure_date_all", 
                                                                 when(col("failure_date").isNotNull(), col("failure_date"))
                                                                 .otherwise(col("startofsampling")))

#filtrare i dati di quelli rotti
all_cng_filtered_sdf = all_cng_flag_faildate_sdf.filter(col("startofsampling")<=col("failure_date_all"))

# COMMAND ----------

from pyspark.sql.functions import col, when, max, to_date

# Aggregating the last acquisition date for each chassis
last_dates = all_cng_filtered_sdf.groupBy("chassis").agg(max(to_date(col("startofsampling"))).alias("last_acquisition_day"))

# Joining the last acquisition date with the dataframe and updating the failure_date column
all_cng_filtered_sdf = all_cng_filtered_sdf.join(last_dates, "chassis")\
                                .withColumn("failure_date", 
                                                when(col("oil_problem") == True, col("failure_date"))
                                                .otherwise(col("last_acquisition_day")))

# COMMAND ----------

prova = all_cng_filtered_sdf\
            .groupBy("chassis", "oil_problem", "failure_date")\
            .agg(first(to_date(col("warr_startdate"))).alias("warr_startdate"),
                                                                                max(col("engineWorkHours")).alias("max_engineworkhours"),
                                                                                max((col("odoAtEnd"))/1000).alias("max_distance_km"),
                                                                                max(to_date(col("startofsampling"))).alias("last_startofsampling"),
                                                                                max(to_date(col("endofsampling"))).alias("last_endofsampling"))\
                                            .withColumn("delta", (to_date(col("failure_date"))-to_date(col("last_startofsampling"))).cast("integer"))\
                                            .withColumn("days_service", (to_date(col("last_startofsampling"))-to_date(col("warr_startdate"))).cast("integer"))

# COMMAND ----------

#aggiunta delle proiezioni
prova_projection = prova\
                .withColumn("KM_DAYS", col("max_distance_km")/col("days_service"))\
                .withColumn("KM_LOST", col("KM_DAYS")*col("delta"))\
                .withColumn("KM_TOTAL_PROJECTION", col("max_distance_km")+col("KM_LOST"))\
                .withColumn("HOUR_DAYS", col("max_engineworkhours")/col("days_service"))\
                .withColumn("HOUR_LOST", col("HOUR_DAYS")*col("delta"))\
                .withColumn("HOUR_TOTAL_PROJECTION", col("max_engineworkhours")+col("HOUR_LOST"))
                
                


# COMMAND ----------

prova_projection.columns

# COMMAND ----------

to_null = [
 'delta',
 'KM_DAYS',
 'KM_LOST',
 'KM_TOTAL_PROJECTION',
 'HOUR_DAYS',
 'HOUR_LOST',
 'HOUR_TOTAL_PROJECTION']


for colu in to_null:
     prova_projection = prova_projection.withColumn(colu, when(col("oil_problem")==True, col(colu)).otherwise(None) )

# COMMAND ----------

display(prova_projection)

# COMMAND ----------

# MAGIC %md
# MAGIC ## BACKUP

# COMMAND ----------

# MAGIC %md
# MAGIC ## Keep Engine Work Hours

# COMMAND ----------

from pyspark.sql.functions import max, to_date, first

engineworkhours_sdf = all_cng_filtered_sdf.groupBy("chassis", "oil_problem").agg(
                                                                                first(to_date(col("warr_startdate"))).alias("warr_startdate"),
                                                                                max(col("engineWorkHours")).alias("max_engineworkhours"),
                                                                                max((col("odoAtEnd"))/1000).alias("max_distance_km"),
                                                                                max(to_date(col("startofsampling"))).alias("last_startofsampling"),
                                                                                max(to_date(col("endofsampling"))).alias("last_endofsampling"),                                                                               
                                                                                max(to_date(col("failure_date"))).alias("failure_date"))\
                                            .withColumn("delta", (col("failure_date")-col("last_startofsampling")).cast("integer"))\
                                            .withColumn("days_service", (col("last_startofsampling")-col("warr_startdate")).cast("integer"))
                                            
                                                                                

# COMMAND ----------

display(engineworkhours_sdf.sort(col("oil_problem").desc(), col("max_distance_km").desc()))

# COMMAND ----------

from pyspark.sql.functions import mean,count

display(engineworkhours_sdf.groupBy("oil_problem").agg(count("chassis"), mean("max_engineworkhours")))

# COMMAND ----------

import pandas as pd

engine_pd = engineworkhours_sdf.toPandas()

# COMMAND ----------

import random
import numpy
from matplotlib import pyplot

pyplot.hist(engine_pd.loc[engine_pd.oil_problem==True, "max_engineworkhours"],  alpha=1, label='bad')
pyplot.hist(engine_pd.loc[engine_pd.oil_problem==False, "max_engineworkhours"], alpha=0.3, label='good')
pyplot.legend(loc='upper right')
pyplot.show()

# COMMAND ----------

import random
import numpy
from matplotlib import pyplot

x = [random.gauss(3,1) for _ in range(400)]
y = [random.gauss(4,2) for _ in range(400)]

bins = numpy.linspace(-10, 10, 100)

pyplot.hist(x, bins, alpha=0.5, label='x')
pyplot.hist(y, bins, alpha=0.5, label='y')
pyplot.legend(loc='upper right')
pyplot.show()

# COMMAND ----------

