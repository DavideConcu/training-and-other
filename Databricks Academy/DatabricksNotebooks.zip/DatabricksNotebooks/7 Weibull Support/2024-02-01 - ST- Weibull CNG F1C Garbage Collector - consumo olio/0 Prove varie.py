# Databricks notebook source
import pandas as pd 

chassis =pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/20240201_weibullCNGgcConsumoOlio_chassis2.xlsx")

chassis_sdf = spark.createDataFrame(chassis).distinct()

# COMMAND ----------

vehicle = spark.read.table("edwh.vehicle").selectExpr(
    "pvan_cd_vin_code as chassis",
    "cust_ds_cust_nm_customer as customer",
    "cust_ds_cust_nm_dealer as dealer"
)


chassis_sdf = chassis_sdf.join(vehicle, "chassis")

# COMMAND ----------

#file con i dati dei cng
sdf = spark.read.table("reliab.20230713_rgdailycng_allchassisclusteredwithbothmethods")

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.functions import mean
sdf.groupBy("cluster").agg(mean("ecology")).sort("avg(ecology)").collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join con gli chassis rotti

# COMMAND ----------

sdf_broken = sdf.join(chassis_sdf, "chassis")

# COMMAND ----------

sdf_broken.groupBy("cluster").count().sort("cluster").collect()

# COMMAND ----------

sdf_broken.toPandas().groupby("cluster").chassis.count()

# COMMAND ----------

sdf.groupBy("cluster").count().collect()

# COMMAND ----------

from pyspark.sql.functions import col

sdf.filter(col("onlyMtbfVehiclesLess5000") == False).toPandas().groupby("cluster").mean()

# COMMAND ----------

sdf_broken.toPandas().mean()

# COMMAND ----------

display(sdf_broken.select("customer").distinct())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Manova per critici vs meno critici

# COMMAND ----------

import pandas as pd 
from pyspark.sql.functions import col, lit

#vin critici
critici = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/vin__critici_olio.xlsx")
critici_sdf = spark.createDataFrame(critici).selectExpr("Serial_Number as chassis").distinct()\
                                .withColumn("critici", lit(True))


#vin meno critici
meno_critici = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/vin_meno_critici_olio.xlsx")
meno_critici_sdf = spark.createDataFrame(meno_critici).selectExpr("Serial_Number as chassis").distinct()\
                                .withColumn("critici", lit(False))


tutti_sdf = meno_critici_sdf.union(critici_sdf)

# COMMAND ----------

display(critici_sdf.join(mission,"chassis"))

# COMMAND ----------

from pyspark.sql.functions import col

#join con le mission urban ecc
mission = spark.read.table("reliab.20230713_rgdailycng_allchassisclusteredwithbothmethods")\
                        .filter(col("onlyMtbfVehiclesLess5000") == False)


tutti_mission_sdf = tutti_sdf.join(mission, "chassis")

# COMMAND ----------

tutti_mission_sdf.toPandas().groupby("critici").mean()

# COMMAND ----------

tutti_mission_sdf.select("chassis").distinct().count()

# COMMAND ----------

