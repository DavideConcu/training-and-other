# Databricks notebook source
from pyspark.sql.functions import col

#read all data
all_cng_data = spark.read.table("reliab.20240216_daily_cngnp_my1921_alldata")

#tenere solo i vin my19
vehicle = spark.read.table("edwh.vehicle")\
                    .selectExpr("pvan_cd_vin_code as chassis", 
                                "pvan_ds_preliminary_model_year as model_year")\
                                    .filter(col("model_year")=="MY2019")
                    


#tutti i modelyear 19 connessi
all_cng_data_my19 = all_cng_data.join(vehicle, "chassis")

# COMMAND ----------

#MODEL YEAR 19 + 21
all_cng_data.select("chassis").distinct().count()

# COMMAND ----------

#SOLO I MODEL YEAR 19
all_cng_data_my19.select("chassis").distinct().count()

# COMMAND ----------

import pandas as pd

#lista dei critici
critici = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/vin_critici___consumo_olio___arianna.xlsx")

critici_sdf = spark.createDataFrame(critici).distinct()

lista_vin_critici = critici_sdf.select("chassis").distinct().rdd.flatMap(lambda x: x).collect()

# COMMAND ----------

from pyspark.sql.functions import col, max

#veicoli rotti
rotti = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/vfailures_con_data_OLIO.xlsx")


rotti_sdf = spark.createDataFrame(rotti)\
                    .selectExpr("Serial_Number as chassis", "Failure_date as failure_date")\
                    .distinct()\
                    .groupBy("chassis")\
                        .agg(max("failure_date").alias("failure_date"))


lista_vin_rotti = rotti_sdf.select("chassis").distinct().rdd.flatMap(lambda x: x).collect()

# COMMAND ----------

from pyspark.sql.functions import when 

#flag per i critici
all_cng_data_my19 = all_cng_data_my19.withColumn(
                                    "flag_critici", when(col("chassis").isin(lista_vin_critici), True).otherwise(False)
                                    )

# COMMAND ----------

#flag rotti
all_cng_data_my19 = all_cng_data_my19.withColumn(
                            "flag_rotti", when(col("chassis").isin(lista_vin_rotti), True).otherwise(False)
                                    )

# COMMAND ----------


display(all_cng_data_my19.select("chassis", "flag_rotti", "flag_critici").distinct().groupBy("flag_rotti", "flag_critici").count())

# COMMAND ----------

