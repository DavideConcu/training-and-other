# Databricks notebook source
# MAGIC %md
# MAGIC #Download Data

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "eurocargo"
notebook = "downloadData_perFra"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE reliab.20231116_eurocargo_downloadData_perFRA AS
# MAGIC SELECT * 
# MAGIC FROM datacollector.datacollector_gps_tabular_prod
# MAGIC WHERE chassis IN ("ZCFA81JJ902722297") 
# MAGIC -- AND EXTRACT(YEAR FROM startofsampling) >= 2022

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM reliab.20231116_eurocargo_downloadData_perFRA

# COMMAND ----------

