# Databricks notebook source
# MAGIC %md
# MAGIC # One x Vin - Sway

# COMMAND ----------

#da programma onexvin - Francesco

# COMMAND ----------

# MAGIC %md
# MAGIC #### Var da dividere per totaltime (loop)

# COMMAND ----------

#variabili da sommare e dividere per somma di totaltime
varTime = """totalTimeDriving
		totalTimeIdling
		totalTimeEcoSwitch
		totalTimeCC
		totalTimePCC
		totalTimeACC
		totalTimeEcoRollInt
		totalTimeBrakePedal
		totalTimeBrakeSwitch
		totalTimeLowIdleSwitch
		totalTimeKickDownSwitch
		overWeightAccumul
		coastingRollingTime
		vehicleSpeedTimeLess30
		vehicleSpeedTime30to50
		vehicleSpeedTime50to60
		vehicleSpeedTime60to70
		vehicleSpeedTime70to85
		vehicleSpeedTime85to150
		weightTimeLess15
		weightTime15to22
		weightTime22to37
		weightTime37to42
		weightTimeGrater42
		totalTimePtoDriving
		totalTimePtoIdling
		totalTimeAccPedal
		totalTimePositiveAllowance
		totalTimeNegativeAllowance
		wiperTime
		totalTimePtoOn
		totalTimeAllowance
		engineAccumul""".replace("\n", " ").replace("\t", "").split(" ")

varTime

# COMMAND ----------

varDaDividerePerMille = """overWeightAccumul
vehicleSpeedTimeLess30
vehicleSpeedTime30to50
vehicleSpeedTime50to60
vehicleSpeedTime60to70
vehicleSpeedTime70to85
vehicleSpeedTime85to150
weightTimeLess15
weightTime15to22
weightTime22to37
weightTime37to42
weightTimeGrater42
engineAccumul""".replace("\n", " ").replace("\t", "").split(" ")

# COMMAND ----------

varTimeStr = str()

weight = "totalTime"

for var in varTime:
    if var not in varDaDividerePerMille:
        varTimeStr += f" sum({var})/sum(CASE WHEN {var} IS NOT NULL THEN {weight} ELSE NULL END) as {var},"
    else:
        varTimeStr += f" (sum({var})/sum(CASE WHEN {var} IS NOT NULL THEN {weight} ELSE NULL END)/1000) as {var},"
        
varTimeStr = varTimeStr[0:-1].replace("\n", " ")

varTimeStr

# COMMAND ----------

# MAGIC %md
# MAGIC #### Var da dividere per totaldistance (loop1)

# COMMAND ----------

#variabili da sommare e dividere per somma totaldistance
varDistance = """totalDistancePtoOn
		totalDistanceCC
		totalDistancePCC
		totalDistanceACC
		DistanceOnlyEngineBrake
		DistanceOnlyRetared
		DistanceOnlyBrake
		DistanceBrakeAndEngineBrake
		DistanceBrakeAndRetarder
		CoastingDistance
		RollingDistance
		totalDistanceOver85
		totalDistanceEcoSwitch
		stops
		harshSteering
		harshAcceleration
		absOccurrences
		asrOccurrences
		vdcOccurrences
		handBrake
		harshBraking
		aebsCollision
		vehicleSpeedOver
		badGearshiftingOccurences
		co2
		fuelConsumption
		fuelConsumptionDriving
		fuelConsumptionIdling
		fuelConsumptionPtoOn
		fuelConsumptionPtoIdling
		fuelConsumptionPtoDriving""".replace("\n", " ").replace("\t", "").split(" ")

varDistance

# COMMAND ----------

varDividerMil = "CoastingDistance RollingDistance".split(" ")

# COMMAND ----------

varDistanceStr = str()

weight = "totalDistance"

for var in varDistance:
    if var not in varDividerMil:
        varDistanceStr += f" sum({var})/sum(CASE WHEN {var} IS NOT NULL THEN {weight} ELSE NULL END) as {var},"
    else:
        varDistanceStr += f" (sum({var})/sum(CASE WHEN {var} IS NOT NULL THEN {weight} ELSE NULL END) / 1000) as {var},"
        
varDistanceStr = varDistanceStr[0:-1].replace("\n", " ").replace("\t", "")

varDistanceStr

# COMMAND ----------

# MAGIC %md
# MAGIC #### Variabili con denominatore specifico (loop2)

# COMMAND ----------

#variabili al numeratore 
varNum = """ccUsageNum
		harshBrakingCondNum
		ldwsUsageNum
		ldwsWarnNum
		accUsageNum
		accDistanceNum
		aebsUsageNum
		aebsStateNum
		aebsStateTimeNum
		aebsTimeCollisionNum
		vehicleSpeedTimeoverNum
		hoursLawLimitNum
		engineSpeedOptimalTime
		engineOverspeedTime
		totalTimeEcoRoll""".replace("\n", " ").replace("\t", "").split(" ")

varNum

# COMMAND ----------

#variabili al denominatore
varDen = """ccUsageDen
		harshBrakingCondDen
		ldwsUsageDen
		ldwsWarnDen
		accUsageDen
		accDistanceDen
		aebsUsageDen
		aebsStateDen
		aebsStateTimeDen
		aebsTimeCollisionDen
		vehicleSpeedTimeoverDen
		hoursLawLimitDen
		engineSpeedTimeAll
		engineSpeedTimeAll
		totalTimeEcoRollTotal""".replace("\n", " ").replace("\t", "").split(" ")

varDen

# COMMAND ----------

specialDenVarStr = str()

for num, den in zip(varNum ,varDen):
    specialDenVarStr +=  f" sum({num})/sum(CASE WHEN {num} IS NOT NULL THEN {den} ELSE NULL END ) as {num},"
    
specialDenVarStr = specialDenVarStr[0:-1].replace("\n", " ").replace("\t", "")

specialDenVarStr

# COMMAND ----------

# MAGIC %md 
# MAGIC #### somme pesate (loop3)

# COMMAND ----------

weightedVar = """gvw
		maxVehicleSpeed
		averageSpeed
		commercialSpeed
		engineSpeedAvg
		engineSpeedDrivingAvg
		externalTempMin
		externalTempMax
		externalTempAvg
		engineCoolantTemperatureMax
		engineOilTemperatureMax
		intakeManifoldPressureMax
		engineFuelTemperatureMax
		barometricPressureMin
		barometricPressureMax
		barometricPressureAvg
		engineOilLevelAvg
		engineInManifoldTemperatureMax
		levelBatteryCharge
		flat
		hilly
		light_mountain
		medium_mountain
		severe_mountain""".replace("\n", " ").replace("\t", "").split(" ")

weightedVar

# COMMAND ----------

weightedVarStr = str()

weight = "totalDistance"

for var in weightedVar:
    weightedVarStr += f" sum({var} * {weight})/sum(CASE WHEN {var} IS NOT NULL THEN {weight} ELSE NULL END) as {var},"

weightedVarStr = weightedVarStr[0:-1].replace("\n", " ").replace("\t", "")

weightedVarStr

# COMMAND ----------

# MAGIC %md 
# MAGIC #### motorway, urban, extraurban

# COMMAND ----------

wayVarStr = str()

weight = "totalDistance"

condizione = "(motorway_roads_perc > 0 OR secondary_roads_perc > 0 OR urban_path_perc > 0)"

for var in ["motorway_roads_perc", "secondary_roads_perc" , "urban_path_perc"]:
    wayVarStr += f" (sum((CASE WHEN {condizione} THEN {var} ELSE NULL END) * {weight}) /100)/ sum(CASE WHEN {condizione} THEN {weight} ELSE NULL END) as {var},"

wayVarStr = wayVarStr[0:-1].replace("\n", " ").replace("\t", "")

wayVarStr

# COMMAND ----------

# MAGIC %md
# MAGIC #### flat hilly ecc

# COMMAND ----------

weight = "totalDistance"

condizione = "motorway_roads_perc > 0 OR secondary_roads_perc > 0 OR urban_path_perc > 0"

denom = str()
for collina in ["flat", "hilly", "light_mountain", "medium_mountain" , "severe_mountain"]:
    for strada in ["urban_path_perc", "secondary_roads_perc", "motorway_roads_perc"]:
        
        denom += f" SUM(CASE WHEN {condizione} THEN ({collina} * {weight} * ({strada} / 100)) ELSE NULL END) +"
        
denom = "(" + denom[0:-1] + ")"

# COMMAND ----------

numeratore = []

for collina in ["flat", "hilly", "light_mountain", "medium_mountain" , "severe_mountain"]:
    for strada in ["urban_path_perc", "secondary_roads_perc", "motorway_roads_perc"]:
        
        numeratore.append(f"SUM(CASE WHEN {condizione} THEN ({collina} * {weight} * ({strada} / 100)) ELSE NULL END)")


# COMMAND ----------

finalNames = []
for collina in ["flat", "hilly", "light_mountain", "medium_mountain" , "severe_mountain"]:
    for strada in ["urban", "secondary", "motorway"]:
        finalNames.append(collina + "_" + strada)

# COMMAND ----------

finalStr = str()
for num, name in enumerate(finalNames):
    finalStr += " " + numeratore[num] + " / "+ denom + " AS " + name + " ,"

finalStr = finalStr[0:-1].replace("\t", "")

# COMMAND ----------

# MAGIC %md
# MAGIC #### ultime var 

# COMMAND ----------

lastVars = """sum(totalDistance) as totalDistance, sum(totalTime) as totalTime, min(startOdom) as startOdom, max(endOdom) as endOdom""".replace("\n", " ").replace("\t", " ")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Filtri

# COMMAND ----------

dateFilter = "extract(YEAR from Startofsampling) >= 2021"

#speed e temperature filter
filterSpeedTemp = """
        averageSpeed < 151 and
		externalTempMin > (-81) and 
		externalTempMin < 60 and 
		externalTempMax > (-81) and
		externalTempMax < 60 and
		externalTempAvg > (-81) and
		externalTempAvg < 60 and
		gvw > 0"""

# COMMAND ----------

table = "datacollector.datacollector_tabular_mission_for_wti_super_flat_prod"
vinTableWithStartdate = "reliab._listaswaymy19constartdate"
startWarrantyVar = "startDateTimestamp"
group = "chassis"


query = f""" 
SELECT a.chassis, FIRST(b.{startWarrantyVar}) as startWarranty, {lastVars}, {varTimeStr} , {varDistanceStr} , {specialDenVarStr} , {weightedVarStr} ,{wayVarStr},
 {finalStr}
 
FROM {table} a

    LEFT JOIN {vinTableWithStartdate} b
        ON a.chassis = b.chassis 
        
WHERE a.startofsampling > b.{startWarrantyVar} 
                        AND {filterSpeedTemp} 
                        AND totalTime > 0 
                        AND a.chassis IN (SELECT distinct chassis FROM {vinTableWithStartdate} ) 
                        AND {dateFilter}

GROUP BY a.{group};
""".replace("\n", " ").replace("\t", "")

# COMMAND ----------

df = spark.sql(query)

# COMMAND ----------

import datetime
dateFormat = "%Y%m%d"
date=spark.sql(""" select current_date() as date """).collect()[0]["date"].strftime(dateFormat)

# COMMAND ----------

#df.write.mode("overWrite").saveAsTable(f"reliab.onexvinallswaymy19_{date}")

# COMMAND ----------

query

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(distinct chassis)
# MAGIC FROM reliab.onexvinallswaymy19_20230214

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM reliab.onexvinallswaymy19_20230214
# MAGIC LIMIT 100

# COMMAND ----------

