# Databricks notebook source
# MAGIC %md
# MAGIC # One x Vin

# COMMAND ----------

#creare lista daily my 19 con warrantystardate

#dfDailyConnessi = spark.read.table("reliab._connecteddailymy19list")

#df = spark.read.table("edwh.vehicle").select("pvan_cd_vin_code", "pvan_id_warranty_start_date").na.drop("any")
#df = df.withColumn("startDateTimestamp", to_timestamp("pvan_id_warranty_start_date"))\
#        .selectExpr("pvan_cd_vin_code as chassis" , "startDateTimestamp")

#df.join(dfDailyConnessi, ["chassis"] , "inner").write.saveAsTable("reliab._connecteddailymy19WithStartDate")

# COMMAND ----------

df = 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregations 

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Sums

# COMMAND ----------

var_num = """totalKilograms totalTimeDriving totalTimeIdling totalTimePtoOn totalTimePtoDriving totalTimePtoIdling totalTimeCC totalTimeACC totalTimeAccPedal totalTimeBrakePedal totalTimeBrakeSwitch totalTimeLowIdleSwitch totalTimeKickDownSwitch totalTimeEngineBrake totalTimeRetarderLever totalDistancePtoOn totalDistanceCC totalDistanceACC fuelConsumption overWeightAccumul
		engineAccumul engineSpeedOptimalTime fuelConsumptionPtoOn
		fuelConsumptionPtoIdling fuelConsumptionPtoDriving
		fuelConsumptionDriving fuelConsumptionIdling stops
		engineOverspeedTime harshSteering harshAcceleration
		ccUsageNum absOccurrences asrOccurrences vdcOccurrences
		handBrake harshBraking harshBrakingCondNum ldwsUsageNum
		ldwsWarnNum accUsageNum accDistanceNum aebsUsageNum
		aebsStateNum aebsStateTimeNum aebsCollision aebsTimeCollisionNum
		vehicleSpeedTimeoverNum131 vehicleSpeedOver131 vehicleSpeedTimeoverNum141
		vehicleSpeedOver141 vehicleSpeedTimeoverNum151 vehicleSpeedOver151
		hoursLawLimitNum safetyBeltNum overWeightNum engineOptimalNum
		tyrePressureKo totalTimeEcoRollInt"""

varNumList = var_num.replace("\n", " ").replace("\t", "").split(" ")

# COMMAND ----------

var_den ="""totalDistance totalTime totalTime totalTime totalTime totalTime
		totalTime totalTime totalTime totalTime totalTime totalTime
		totalTime totalTime totalTime totalDistance totalDistance
		totalDistance totalDistance overWeightTimeAll engineTimeAll
		engineSpeedTimeAll fuelConsumption fuelConsumption fuelConsumption
		fuelConsumption fuelConsumption totalDistance totalTime
		totalDistance totalDistance ccUsageDen totalDistance
		totalDistance totalDistance totalDistance totalDistance
		harshBrakingCondDen ldwsUsageDen ldwsWarnDen
		accUsageDen accDistanceDen aebsUsageDen aebsStateDen
		aebsStateTimeDen totalDistance aebsTimeCollisionDen
		vehicleSpeedTimeoverDen totalDistance vehicleSpeedTimeoverDen
		totalDistance vehicleSpeedTimeoverDen totalDistance
		hoursLawLimitDen safetyBeltDen overWeightDen engineOptimalDen
		tyrePressureAll totalTime"""

varDenList = var_den.replace("\n", " ").replace("\t", "").split(" ")

# COMMAND ----------

aggregationsString = str()
for num, den in zip(varNumList ,varDenList):
    aggregationsString +=  f" sum({num})/sum(CASE WHEN {num} IS NOT NULL THEN {den} ELSE NULL END ) as {num},"
    
aggregationsString = aggregationsString[0:-1].replace("\n", " ")
aggregationsString

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Weighted Averages

# COMMAND ----------

var_avg = """gvw maxVehicleSpeed engineSpeedAvg externalTempMin externalTempMax
		externalTempAvg engineCoolantTemperatureMax intakeManifoldPressureMax
		engineFuelTemperatureMax barometricPressureMin barometricPressureMax
		barometricPressureAvg engineOilLevelAvg engineExaustTemperatureMax
		vehicleSpeed engineInManifoldTemperatureMax levelBatteryCharge
		fuelLevel"""

varAvgList = var_avg.replace("\n", " ").replace("\t", "").split(" ")

# COMMAND ----------

varAvgStr = str()
weight = "totalTime"
for var in varAvgList:
    varAvgStr += f" sum({var} * {weight})/sum(CASE WHEN {var} IS NOT NULL THEN {weight} ELSE NULL END) as {var},"

varAvgStr = varAvgStr[0:-1].replace("\n", " ")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Flat Hilly & Co

# COMMAND ----------

varMount = """flat hilly light_mountain medium_mountain severe_mountain"""
varMount = varMount.replace("\n", " ").replace("\t", "").split()
varMount

# COMMAND ----------

varMountStr = str()
weight = "totalDistance"

for var in varMount:
    varMountStr += f" sum({var} * {weight})/sum(CASE WHEN {var} IS NOT NULL THEN {weight} ELSE NULL END) as {var},"

varMountStr = varMountStr[0:-1].replace("\n", " ")
varMountStr

# COMMAND ----------

# MAGIC %md
# MAGIC #### Other Aggregations

# COMMAND ----------

otherAgg = """min(startOfSampling) as startOfSampling,    
max(endOfSampling) as endOfSampling,  
sum(totalDistance) as totalDistance,  
sum(totalTime) as totalTime,  
min(odoAtStart) as odoAtStart,  
max(odoAtStart) as odoAtEnd,  
max(engineWorkHours) as engineWorkHours""".replace("\n", " ")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Entire Query

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Filters

# COMMAND ----------

dateFilter = "extract(YEAR from Startofsampling) >= 2021"

# COMMAND ----------

#speed e temperature filter
filterSpeedTemp = """
vehicleSpeed < 201 and  
externalTempMin > (-81) and   
externalTempMin < 60 and   
externalTempMax > (-81) and  
externalTempMax < 60 and  
externalTempAvg > (-81) and 
externalTempAvg < 60  
""".replace("\n", " ")

# COMMAND ----------

#totaltime
filterDen = "totalTime > 0"

# COMMAND ----------

table = "datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod"
vinTableWithStartdate = "reliab._connecteddailymy19WithStartDate"
startWarrantyVar = "startDateTimestamp"
group = "chassis"


query = f""" 
SELECT a.chassis, FIRST(b.{startWarrantyVar}) as startWarranty, {otherAgg}, {varAvgStr} , {varMountStr} , {aggregationsString} 
FROM {table} a

    LEFT JOIN {vinTableWithStartdate} b
        ON a.chassis = b.chassis 
        
WHERE a.startofsampling > b.{startWarrantyVar} 
                        AND {filterSpeedTemp} 
                        AND {filterDen} 
                        AND a.chassis IN (SELECT distinct chassis FROM {vinTableWithStartdate}) 
                        AND {dateFilter}

GROUP BY a.{group};
""".replace("\n", " ")

# COMMAND ----------

df = spark.sql(query)


# COMMAND ----------

import datetime
dateFormat = "%Y%m%d"
date=spark.sql(""" select current_date() as date """).collect()[0]["date"].strftime(dateFormat)

# COMMAND ----------

#df.write.mode("overWrite").saveAsTable(f"reliab.onexvinalldailymy19_{date}")

# COMMAND ----------

