# Databricks notebook source
# MAGIC %md
# MAGIC ### Vehicle Data

# COMMAND ----------

from pyspark.sql.functions import col

vehiclesDf = spark.read\
    .format("csv")\
    .option("inferSchema", "true")\
    .option("header", "true")\
    .load("dbfs:/FileStore/tables/reliab/datiVeicoliR49Beccaro.csv")\
    .drop("_c0")\
    .select(col("Serial Number").alias("chassis") , 
            col("Base Warranty Start Date").alias("startDate"),
           col("Active contract"))\
    .filter(col("Active contract") == "YES")

# COMMAND ----------

display(vehiclesDf)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Calcolo delle velocità medie per Altitudine Cat

# COMMAND ----------

InputData = spark.read.table("datasc.datacollector_daily_tabular_pivot_delta")

# COMMAND ----------

#Crea tabella dati
#slezionare variabili, join con i vin di interesse, filtra e crea view
from pyspark.sql.functions import col

InputData.select(col("vin").alias("chassis"),  "missionId", "startdatetime", "enddatetime","time", (col("time")/3600).alias("totaltime_h") , "distance", "gpsalt", "slope_perc")\
    .join(vehiclesDf.select("chassis", "startDate").distinct(), "chassis" , "inner")\
    .na.drop(how="any", subset=["gpsalt"])\
    .filter(col("startdatetime") > col("startDate"))\
    .write.mode("OverWrite").saveAsTable("reliab.2023_R49_DatiAltDailyEPBIssue")
    

# COMMAND ----------

#caricare i dati scaricati
df = spark.read.table("reliab.2023_R49_DatiAltDailyEPBIssue").na.drop("any")

# COMMAND ----------

#aggiungere km totali per vin, altitudine bin e speed bin
df = df.selectExpr("*", "distance/totaltime_h as AverageSpeed",
                   
                       """(CASE 
                        WHEN gpsalt<=300 THEN '0 < Altitude <= 300m'
                        WHEN gpsalt<=600 THEN '300m < Altitude <= 600m'
                        WHEN gpsalt<=900 THEN '600m < Altitude <= 900m' 
                        ELSE 'Altitude > 900m'
                       END) as AltitudeBin""", 
                                         
                        """(CASE
                            WHEN distance/totaltime_h <= 5 THEN '0 < Speed <= 5 Km/h'
                            WHEN distance/totaltime_h <= 10 THEN '5< Speed <=10 Km/h'
                            WHEN distance/totaltime_h <= 15 THEN '10< Speed <=15 Km/h'
                            WHEN distance/totaltime_h <= 20 THEN '15< Speed <=20 Km/h'
                            WHEN distance/totaltime_h <= 25 THEN '20< Speed <=25 Km/h'
                            WHEN distance/totaltime_h <= 30 THEN '25< Speed <=30 Km/h'
                            WHEN distance/totaltime_h <= 35 THEN '30< Speed <=35 Km/h'
                            WHEN distance/totaltime_h <= 40 THEN '35< Speed <=40 Km/h'
                            WHEN distance/totaltime_h <= 45 THEN '40< Speed <=45 Km/h'
                            WHEN distance/totaltime_h <= 50 THEN '45< Speed <=50 Km/h'
                            WHEN distance/totaltime_h <= 55 THEN '50< Speed <=55 Km/h'
                            WHEN distance/totaltime_h <= 60 THEN '55< Speed <=60 Km/h'
                            WHEN distance/totaltime_h <= 65 THEN '60< Speed <=65 Km/h'
                            WHEN distance/totaltime_h <= 70 THEN '65< Speed <=70 Km/h'
                            WHEN distance/totaltime_h <= 75 THEN '70< Speed <=75 Km/h'
                            WHEN distance/totaltime_h <= 80 THEN '75< Speed <=80 Km/h'
                            WHEN distance/totaltime_h <= 85 THEN '80< Speed <=85 Km/h'
                            WHEN distance/totaltime_h <= 90 THEN '85< Speed <=90 Km/h'
                            WHEN distance/totaltime_h <= 95 THEN '90< Speed <=95 Km/h'
                            ELSE 'Speed > 95 Km/h'
                        END) as AverageSpeedBin""")

df = df.selectExpr("*",                         
                        """(CASE
                            WHEN distance/totaltime_h <= 5 THEN 'c0'
                            WHEN distance/totaltime_h <= 10 THEN 'c1'
                            WHEN distance/totaltime_h <= 15 THEN 'c2'
                            WHEN distance/totaltime_h <= 20 THEN 'c3'
                            WHEN distance/totaltime_h <= 25 THEN 'c4'
                            WHEN distance/totaltime_h <= 30 THEN 'c5'
                            WHEN distance/totaltime_h <= 35 THEN 'c6'
                            WHEN distance/totaltime_h <= 40 THEN 'c7'
                            WHEN distance/totaltime_h <= 45 THEN 'c8'
                            WHEN distance/totaltime_h <= 50 THEN 'c9'
                            WHEN distance/totaltime_h <= 55 THEN 'c10'
                            WHEN distance/totaltime_h <= 60 THEN 'c11'
                            WHEN distance/totaltime_h <= 65 THEN 'c12'
                            WHEN distance/totaltime_h <= 70 THEN 'c13'
                            WHEN distance/totaltime_h <= 75 THEN 'c14'
                            WHEN distance/totaltime_h <= 80 THEN 'c15'
                            WHEN distance/totaltime_h <= 85 THEN 'c16'
                            WHEN distance/totaltime_h <= 90 THEN 'c17'
                            WHEN distance/totaltime_h <= 95 THEN 'c18'
                            ELSE 'c19'
                        END) as AverageSpeedORDERED""")

# COMMAND ----------

#aggiungere la distanza totale per vin
from pyspark.sql.functions import sum

totalDistancesDf = df.groupBy("chassis").agg(sum("distance").alias("totalDistanceVin"))

df = df.join(totalDistancesDf, "chassis")

# COMMAND ----------

#query completa
df.createOrReplaceTempView("DailyView")

query = """
SELECT chassis, AverageSpeedBin, AltitudeBin, AverageSpeedORDERED,
              SUM(distance/totalDistanceVin) as distancePercent  
FROM DailyView
WHERE totalDistanceVin > 0
                
GROUP BY chassis, AverageSpeedBin, AverageSpeedORDERED, AltitudeBin
ORDER BY chassis,AverageSpeedBin, AltitudeBin
"""

#effettua la query
finalTable = spark.sql(query)

# COMMAND ----------

#pivot della colonna average speed per avere ogni valore per ogni vin
from pyspark.sql.functions import first

speedPivot = finalTable\
                .groupBy("chassis", "AltitudeBin")\
                .pivot("AverageSpeedORDERED")\
                .agg(first("distancePercent"))

# COMMAND ----------

speedPivot = speedPivot.selectExpr("chassis", "AltitudeBin",
"""stack(19,  
'0 < Speed <= 5 Km/h', c0,
'5< Speed <=10 Km/h' , c1,
'10< Speed <=15 Km/h', c2,
'15< Speed <=20 Km/h', c3,
'20< Speed <=25 Km/h', c4,
'25< Speed <=30 Km/h', c5,
'30< Speed <=35 Km/h', c6,
'35< Speed <=40 Km/h', c7,
'40< Speed <=45 Km/h', c8,
'45< Speed <=50 Km/h', c9,
'50< Speed <=55 Km/h', c10,
'55< Speed <=60 Km/h', c11,
'60< Speed <=65 Km/h', c12,
'65< Speed <=70 Km/h', c13,
'70< Speed <=75 Km/h', c14,
'75< Speed <=80 Km/h', c15,
'80< Speed <=85 Km/h', c16,
'85< Speed <=90 Km/h', c17,
'90< Speed <=95 Km/h', c18) as (AverageSpeedBin, distancePercent)""")

# COMMAND ----------

display(speedPivot.orderBy("chassis", "AverageSpeedBin"))

# COMMAND ----------

#pivot della colonna altitude bin
from pyspark.sql.functions import first

finalPivot = speedPivot\
    .groupBy("chassis", "AverageSpeedBin")\
    .pivot("AltitudeBin")\
    .agg(first("distancePercent")).na.fill(0)

# COMMAND ----------

finalPivot.columns

# COMMAND ----------

#ordinare il dataset
finalPivot = finalPivot.selectExpr("*", 
"""(CASE
WHEN AverageSpeedBin =  '0 < Speed <= 5 Km/h' THEN 0
WHEN AverageSpeedBin = '5< Speed <=10 Km/h'  THEN 1
WHEN AverageSpeedBin = '10< Speed <=15 Km/h' THEN 2
WHEN AverageSpeedBin = '15< Speed <=20 Km/h' THEN 3
WHEN AverageSpeedBin = '20< Speed <=25 Km/h' THEN 4
WHEN AverageSpeedBin = '25< Speed <=30 Km/h' THEN 5
WHEN AverageSpeedBin = '30< Speed <=35 Km/h' THEN 6
WHEN AverageSpeedBin = '35< Speed <=40 Km/h' THEN 7
WHEN AverageSpeedBin = '40< Speed <=45 Km/h' THEN 8
WHEN AverageSpeedBin = '45< Speed <=50 Km/h' THEN 9
WHEN AverageSpeedBin = '50< Speed <=55 Km/h' THEN 10
WHEN AverageSpeedBin = '55< Speed <=60 Km/h' THEN 11
WHEN AverageSpeedBin = '60< Speed <=65 Km/h' THEN 12
WHEN AverageSpeedBin = '65< Speed <=70 Km/h' THEN 13
WHEN AverageSpeedBin = '70< Speed <=75 Km/h' THEN 14
WHEN AverageSpeedBin = '75< Speed <=80 Km/h' THEN 15
WHEN AverageSpeedBin = '80< Speed <=85 Km/h' THEN 16
WHEN AverageSpeedBin = '85< Speed <=90 Km/h' THEN 17
WHEN AverageSpeedBin = '90< Speed <=95 Km/h' THEN 18
ELSE 19 END) AS order """)

# COMMAND ----------

from pyspark.sql.functions import sum
from pyspark.sql.window import Window

windowSpec = Window.partitionBy("chassis").orderBy("order").rowsBetween(Window.unboundedPreceding, 0)

finalPivot = finalPivot.withColumn("SumKm", sum(col('0 < Altitude <= 300m') + col('300m < Altitude <= 600m') + col('600m < Altitude <= 900m') + col('Altitude > 900m')).over(windowSpec))

# COMMAND ----------

display(finalPivot.orderBy("chassis", "order").drop("order"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stesso processo ma aggregando su tutti i vin

# COMMAND ----------

#caricare i dati scaricati
df = spark.read.table("reliab.2023_R49_DatiAltDailyEPBIssue").na.drop("any")

# COMMAND ----------

#aggiungere km totali per vin, altitudine bin e speed bin
df = df.selectExpr("*", "distance/totaltime_h as AverageSpeed",
                   
                       """(CASE 
                        WHEN gpsalt<=300 THEN '0 < Altitude <= 300m'
                        WHEN gpsalt<=600 THEN '300m < Altitude <= 600m'
                        WHEN gpsalt<=900 THEN '600m < Altitude <= 900m' 
                        ELSE 'Altitude > 900m'
                       END) as AltitudeBin""", 
                                         
                        """(CASE
                            WHEN distance/totaltime_h <= 5 THEN '0 < Speed <= 5 Km/h'
                            WHEN distance/totaltime_h <= 10 THEN '5< Speed <=10 Km/h'
                            WHEN distance/totaltime_h <= 15 THEN '10< Speed <=15 Km/h'
                            WHEN distance/totaltime_h <= 20 THEN '15< Speed <=20 Km/h'
                            WHEN distance/totaltime_h <= 25 THEN '20< Speed <=25 Km/h'
                            WHEN distance/totaltime_h <= 30 THEN '25< Speed <=30 Km/h'
                            WHEN distance/totaltime_h <= 35 THEN '30< Speed <=35 Km/h'
                            WHEN distance/totaltime_h <= 40 THEN '35< Speed <=40 Km/h'
                            WHEN distance/totaltime_h <= 45 THEN '40< Speed <=45 Km/h'
                            WHEN distance/totaltime_h <= 50 THEN '45< Speed <=50 Km/h'
                            WHEN distance/totaltime_h <= 55 THEN '50< Speed <=55 Km/h'
                            WHEN distance/totaltime_h <= 60 THEN '55< Speed <=60 Km/h'
                            WHEN distance/totaltime_h <= 65 THEN '60< Speed <=65 Km/h'
                            WHEN distance/totaltime_h <= 70 THEN '65< Speed <=70 Km/h'
                            WHEN distance/totaltime_h <= 75 THEN '70< Speed <=75 Km/h'
                            WHEN distance/totaltime_h <= 80 THEN '75< Speed <=80 Km/h'
                            WHEN distance/totaltime_h <= 85 THEN '80< Speed <=85 Km/h'
                            WHEN distance/totaltime_h <= 90 THEN '85< Speed <=90 Km/h'
                            WHEN distance/totaltime_h <= 95 THEN '90< Speed <=95 Km/h'
                            ELSE 'Speed > 95 Km/h'
                        END) as AverageSpeedBin""")

df = df.selectExpr("*",                         
                        """(CASE
                            WHEN distance/totaltime_h <= 5 THEN 'c0'
                            WHEN distance/totaltime_h <= 10 THEN 'c1'
                            WHEN distance/totaltime_h <= 15 THEN 'c2'
                            WHEN distance/totaltime_h <= 20 THEN 'c3'
                            WHEN distance/totaltime_h <= 25 THEN 'c4'
                            WHEN distance/totaltime_h <= 30 THEN 'c5'
                            WHEN distance/totaltime_h <= 35 THEN 'c6'
                            WHEN distance/totaltime_h <= 40 THEN 'c7'
                            WHEN distance/totaltime_h <= 45 THEN 'c8'
                            WHEN distance/totaltime_h <= 50 THEN 'c9'
                            WHEN distance/totaltime_h <= 55 THEN 'c10'
                            WHEN distance/totaltime_h <= 60 THEN 'c11'
                            WHEN distance/totaltime_h <= 65 THEN 'c12'
                            WHEN distance/totaltime_h <= 70 THEN 'c13'
                            WHEN distance/totaltime_h <= 75 THEN 'c14'
                            WHEN distance/totaltime_h <= 80 THEN 'c15'
                            WHEN distance/totaltime_h <= 85 THEN 'c16'
                            WHEN distance/totaltime_h <= 90 THEN 'c17'
                            WHEN distance/totaltime_h <= 95 THEN 'c18'
                            ELSE 'c19'
                        END) as AverageSpeedORDERED""")

# COMMAND ----------

#aggiungere la distanza totale per vin
from pyspark.sql.functions import sum

totalDistancesDf = df.agg(sum("distance").alias("totalDistanceVin"))

df = df.join(totalDistancesDf)

# COMMAND ----------

#query completa
df.createOrReplaceTempView("DailyView")

query = """
SELECT  AverageSpeedBin, AltitudeBin, AverageSpeedORDERED,
              SUM(distance/totalDistanceVin) as distancePercent  
FROM DailyView
WHERE totalDistanceVin > 0
                
GROUP BY AverageSpeedBin, AverageSpeedORDERED, AltitudeBin
ORDER BY AverageSpeedBin, AltitudeBin
"""

#effettua la query
finalTable = spark.sql(query)

# COMMAND ----------

#pivot della colonna average speed per avere ogni valore per ogni vin
from pyspark.sql.functions import first

speedPivot = finalTable\
                .groupBy( "AltitudeBin")\
                .pivot("AverageSpeedORDERED")\
                .agg(first("distancePercent"))

# COMMAND ----------

speedPivot = speedPivot.selectExpr( "AltitudeBin",
"""stack(19,  
'0 < Speed <= 5 Km/h', c0,
'5< Speed <=10 Km/h' , c1,
'10< Speed <=15 Km/h', c2,
'15< Speed <=20 Km/h', c3,
'20< Speed <=25 Km/h', c4,
'25< Speed <=30 Km/h', c5,
'30< Speed <=35 Km/h', c6,
'35< Speed <=40 Km/h', c7,
'40< Speed <=45 Km/h', c8,
'45< Speed <=50 Km/h', c9,
'50< Speed <=55 Km/h', c10,
'55< Speed <=60 Km/h', c11,
'60< Speed <=65 Km/h', c12,
'65< Speed <=70 Km/h', c13,
'70< Speed <=75 Km/h', c14,
'75< Speed <=80 Km/h', c15,
'80< Speed <=85 Km/h', c16,
'85< Speed <=90 Km/h', c17,
'90< Speed <=95 Km/h', c18) as (AverageSpeedBin, distancePercent)""")

# COMMAND ----------

#pivot della colonna altitude bin
from pyspark.sql.functions import first

finalPivot = speedPivot\
    .groupBy("AverageSpeedBin")\
    .pivot("AltitudeBin")\
    .agg(first("distancePercent")).na.fill(0)

# COMMAND ----------

#ordinare il dataset
finalPivot = finalPivot.selectExpr("*", 
"""(CASE
WHEN AverageSpeedBin =  '0 < Speed <= 5 Km/h' THEN 0
WHEN AverageSpeedBin = '5< Speed <=10 Km/h'  THEN 1
WHEN AverageSpeedBin = '10< Speed <=15 Km/h' THEN 2
WHEN AverageSpeedBin = '15< Speed <=20 Km/h' THEN 3
WHEN AverageSpeedBin = '20< Speed <=25 Km/h' THEN 4
WHEN AverageSpeedBin = '25< Speed <=30 Km/h' THEN 5
WHEN AverageSpeedBin = '30< Speed <=35 Km/h' THEN 6
WHEN AverageSpeedBin = '35< Speed <=40 Km/h' THEN 7
WHEN AverageSpeedBin = '40< Speed <=45 Km/h' THEN 8
WHEN AverageSpeedBin = '45< Speed <=50 Km/h' THEN 9
WHEN AverageSpeedBin = '50< Speed <=55 Km/h' THEN 10
WHEN AverageSpeedBin = '55< Speed <=60 Km/h' THEN 11
WHEN AverageSpeedBin = '60< Speed <=65 Km/h' THEN 12
WHEN AverageSpeedBin = '65< Speed <=70 Km/h' THEN 13
WHEN AverageSpeedBin = '70< Speed <=75 Km/h' THEN 14
WHEN AverageSpeedBin = '75< Speed <=80 Km/h' THEN 15
WHEN AverageSpeedBin = '80< Speed <=85 Km/h' THEN 16
WHEN AverageSpeedBin = '85< Speed <=90 Km/h' THEN 17
WHEN AverageSpeedBin = '90< Speed <=95 Km/h' THEN 18
ELSE 19 END) AS order """)

# COMMAND ----------

from pyspark.sql.functions import sum
from pyspark.sql.window import Window

windowSpec = Window.orderBy("order").rowsBetween(Window.unboundedPreceding, 0)

finalPivot = finalPivot.withColumn("SumKm", sum(col('0 < Altitude <= 300m') + col('300m < Altitude <= 600m') + col('600m < Altitude <= 900m') + col('Altitude > 900m')).over(windowSpec))

# COMMAND ----------

display(finalPivot.orderBy( "order").drop("order"))

# COMMAND ----------

