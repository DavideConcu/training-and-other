# Databricks notebook source
# MAGIC %md
# MAGIC ## Df dei Veicoli di interesse

# COMMAND ----------

from pyspark.sql.functions import col

vehiclesDf = spark.read\
    .format("csv")\
    .option("inferSchema", "true")\
    .option("header", "true")\
    .load("dbfs:/FileStore/tables/reliab/datiVeicoliR49Beccaro.csv")\
    .drop("_c0")\
    .select(col("Serial Number").alias("chassis") , 
            col("Base Warranty Start Date").alias("startDate"),
           col("Active contract"))\
    .filter(col("Active contract") == "YES")

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Df delle Mission aggregate da Tabular super flat

# COMMAND ----------

#tabella di partenza
inputData = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod").limit(100)

# COMMAND ----------

display(inputData)

# COMMAND ----------

inputData.columns

# COMMAND ----------

# MAGIC %md 
# MAGIC ## OneXVin Mission

# COMMAND ----------

spark.read.table("reliab.onexvinallswaymy19_20230214")\
                    .join(vehiclesDf.select("chassis"), "chassis").count()

# COMMAND ----------

