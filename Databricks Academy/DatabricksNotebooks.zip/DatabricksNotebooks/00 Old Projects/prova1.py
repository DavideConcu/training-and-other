# Databricks notebook source
path = "s3://aw-eu-s3-dbfs-databricks-696329796947-p-01/datasc.db/datacollector_daily_tabular_pivot_delta"

# COMMAND ----------

df = spark.sql("SELECT * FROM `s3://aw-eu-s3-dbfs-databricks-696329796947-p-01/datasc.db/datacollector_daily_tabular_pivot_delta`")

# COMMAND ----------

spark.read.format('csv').options(header='true', inferSchema='true').load('s3://aw-eu-s3-dbfs-databricks-696329796947-p-01/datasc.db/datacollector_daily_tabular_pivot_delta').display()

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW CREATE TABLE datacollector.datacollector_tabular_mission_for_wti_daily_prod
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW CREATE TABLE datasc.datacollector_daily_tabular_pivot_delta
# MAGIC

# COMMAND ----------

newPath = "s3://aw-eu-s3-eds-datalake217369589949-p-01/DS_CV/datacollector_daily_tabular_pivot_delta/Delta"

# COMMAND ----------

df = spark.sql("SELECT * FROM `s3://aw-eu-s3-eds-datalake217369589949-p-01/DS_CV/datacollector_daily_tabular_pivot_delta/Delta`")

# COMMAND ----------

spark.read.format('csv').options(header='true', inferSchema='true').load(newPath).display()

# COMMAND ----------

table_name = 'datasc.datacollector_daily_tabular_pivot_delta'
table_location = 's3://aw-eu-s3-eds-datalake217369589949-p-01/DS_CV/datacollector_daily_tabular_pivot_delta/Delta'



create_stmt = f"""
CREATE TABLE spark_catalog.{table_name}
USING delta
LOCATION '{table_location}'
"""



spark.sql(create_stmt)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP DATABASE da_davide_concu_6411_asp

# COMMAND ----------

