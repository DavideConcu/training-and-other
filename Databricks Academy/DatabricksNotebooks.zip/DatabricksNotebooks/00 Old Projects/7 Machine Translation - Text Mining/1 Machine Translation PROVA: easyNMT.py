# Databricks notebook source
# MAGIC %md
# MAGIC ## Installare il pacchetto

# COMMAND ----------

pip install -U easynmt

# COMMAND ----------

pip install sacremoses


# COMMAND ----------

pip install openpyxl

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Load File con i Failure Comment

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
failures = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")

#drop vars
colsToKeep = ["VP Code", "Chassis", "Claim Number", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
failures = failures.loc[:, colsToKeep]


#change var names
failures.reset_index(inplace=True)
columns = failures.columns.str.title()

replace = [" ", "(", ")", "."]
for rep in replace:
    columns = [col.replace(rep, "") for col in columns]

failures.columns = columns

#drop if alredy english
failures = failures.loc[(failures.InvoiceMarketCode != "GB")&(failures.MarketRepairCode != "GB"), :]


# COMMAND ----------

# MAGIC %md
# MAGIC ## Load the Models

# COMMAND ----------

from easynmt import EasyNMT

model1 = EasyNMT("opus-mt" , max_new_tokens=2000)
model2 = EasyNMT("mbart50_m2en",  max_new_tokens=2000)
model3 = EasyNMT("mbart50_m2m", max_new_tokens=2000)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Output TABLE

# COMMAND ----------

#output table name
outputTableName = "reliab.20230704_wiringHarness_NeuralMachineTranslation_3Models"

spark.conf.set("NMT.outputTableName", outputTableName)

# COMMAND ----------

#schema (tutto string)
models = ["opusmt", "mbart50_m2en", "mbart50_m2m"]
varsModels = ["FailureCommentTranslated_" + model for model in models]

varSchema = [x + " STRING"  if x != "Index" else x + " INT" for x in columns + varsModels]
schema = ", ".join(varSchema)

spark.conf.set("NTM.outputTableSchema", schema)
spark.conf.get("NTM.outputTableSchema", schema)

# COMMAND ----------

# MAGIC %sql
# MAGIC --- crea la tabella di output
# MAGIC CREATE TABLE IF NOT EXISTS
# MAGIC ${NMT.outputTableName}
# MAGIC (${NTM.outputTableSchema})

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from ${NMT.outputTableName}

# COMMAND ----------

def update():
    spark.sql("""
    MERGE INTO ${NMT.outputTableName} AS t
    USING rowsExtractedView AS i

        ON t.Index = i.Index 
        AND t.Chassis = i.Chassis
        AND t.ClaimNumber = i.ClaimNumber
        AND t.FailureComment = i.FailureComment
  
    WHEN NOT MATCHED THEN INSERT *
    """)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Translate

# COMMAND ----------

rowsDone = list()

# COMMAND ----------

updateEvery = 200
done = 0
for riga in [x for x in failures.index if x not in rowsDone]:

    ################### applicare i modelli
    failures.loc[riga , "FailureCommentTranslated_opusmt"] = model1.translate(failures.loc[riga, "FailureComment"], target_lang='en')

    failures.loc[riga , "FailureCommentTranslated_mbart50_m2en"] = model2.translate(failures.loc[riga, "FailureComment"], target_lang='en')

    failures.loc[riga , "FailureCommentTranslated_mbart50_m2m"] = model3.translate(failures.loc[riga, "FailureComment"], target_lang='en')
    ###########################################################
    
    rowsDone.append(riga)
    done += 1 
    print("done: ", done, " ----")

    if done >= updateEvery:
        spark.createDataFrame(failures.loc[rowsDone,:], schema = schema).createOrReplaceTempView("rowsExtractedView")
        update()
        done = 0
        print("\n\n ++++++ TARGET TABLE UPDATED +++++++\n\n")



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM reliab.20230704_wiringHarness_NeuralMachineTranslation_3Models

# COMMAND ----------

failures

# COMMAND ----------

rowsDone = list()
for riga in failures.index:
    rowsDone.append(riga)

# COMMAND ----------

