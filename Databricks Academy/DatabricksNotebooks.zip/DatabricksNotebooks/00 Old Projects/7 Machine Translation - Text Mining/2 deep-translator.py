# Databricks notebook source
pip install -U deep-translator

# COMMAND ----------

#pip install deep-translator[ai] 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load File

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
failures = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")

#drop vars
#colsToKeep = ["VP Code", "Chassis", "Claim Number", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
#failures = failures.loc[:, colsToKeep]


#change var names
failures.reset_index(inplace=True)
columns = failures.columns.str.title()

replace = [" ", "(", ")", "."]
for rep in replace:
    columns = [col.replace(rep, "") for col in columns]

failures.columns = columns


langToTranslate = ['GB', 'IT',  'FR','DE','BE', 'PL','CH']


#drop if alredy english
failures = failures.loc[failures.MarketRepairCode.isin(langToTranslate) , :]
failures.FailureComment = failures.FailureComment.str.replace("\t", "")

# COMMAND ----------


firstWord =set( [x.split(" ")[0] for x in failures.FailureComment.str.strip()])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Split Complaint - Cause - Correction

# COMMAND ----------

#funzioni per pulire e separare 
import re

def basicCleaning(stringa):
   cleaned = None
   if type(stringa)==str:
      cleaned = re.sub("[\t]", "", stringa)
      cleaned = re.sub("[\-]", "", stringa)
      cleaned = re.sub("[\&]", "and", stringa)
   return cleaned

def extractComplaint(stringa):
    stringa = stringa.upper()
    complaint = None
    match = re.search("((?<=COMPLAINT)|(?<=INCIDENT)).*?(?=CAUSE)", stringa)
    if match:
       complaint = match.group(0)
    return complaint.strip()
       
def extractCause(stringa):
    stringa = stringa.upper()
    cause = None
    match = re.search("(?<=CAUSE).*?(?=CORRECTION|SOLUTION)", stringa)
    if match:
       cause = match.group(0)
    return cause.strip()

def extractCorrection(stringa):
    stringa = stringa.upper()
    correction = None
    match = re.search("((?<=CORRECTION)|(?<=SOLUTION)).*", stringa)
    if match:
       correction = match.group(0)
    return correction.strip()


# COMMAND ----------

#apply funzioni
failures["Complaint"] = failures.apply(lambda x: extractComplaint(x["FailureComment"]), axis=1)
failures["Cause"] = failures.apply(lambda x: extractCause(x["FailureComment"]), axis=1)
failures["Correction"] = failures.apply(lambda x: extractCorrection(x["FailureComment"]), axis=1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Translation

# COMMAND ----------

#translate
failures["ComplaintTranslate"] = failures.apply(lambda x: GoogleTranslator(source='fr', target='en').translate(x["Complaint"]), axis=1)
failures["CorrectionTranslate"] = failures.apply(lambda x: GoogleTranslator(source='fr', target='en').translate(x["Correction"]), axis=1)

# COMMAND ----------

failures["CauseTranslate"] = failures.apply(lambda x: GoogleTranslator(source='fr', target='en').translate(x["Cause"]), axis=1)

# COMMAND ----------

spark.createDataFrame(failures).write.saveAsTable("reliab.20230705_NMT_FrenchFailureCommentsTranslated_GT")

# COMMAND ----------

from deep_translator import GoogleTranslator

# Use any translator you like, in this example GoogleTranslator
translated = GoogleTranslator(source='fr', target='en').translate("""
VOYANT DEFAUT ALLUME  """) 

# COMMAND ----------

translated

# COMMAND ----------

failures["CauseTranslate"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Altre lingue

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
failures = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")

#drop vars
colsToKeep = ["VP Code", "Chassis", "Claim Number", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
failures = failures.loc[:, colsToKeep]


#change var names
failures.reset_index(inplace=True)
columns = failures.columns.str.title()

replace = [" ", "(", ")", "."]
for rep in replace:
    columns = [col.replace(rep, "") for col in columns]

failures.columns = columns

#drop if alredy english
failures = failures.loc[failures.MarketRepairCode == "DE", :]
failures.FailureComment = failures.FailureComment.str.replace("\t", "")

# COMMAND ----------

failures.FailureComment[501]

# COMMAND ----------

#funzioni per pulire e separare 
import re

def basicCleaning(stringa):
   cleaned = None
   if type(stringa)==str:
      cleaned = re.sub("[\t]", "", stringa)
      cleaned = re.sub("[\-]", "", stringa)
      cleaned = re.sub("[\&]", "and", stringa)
   return cleaned

def extractComplaint(stringa):
    stringa = stringa.upper()
    complaint = None
    match = re.search("(?<=REKL).*?(?=GRUND)", stringa)
    if match:
       complaint = match.group(0)
    return complaint.strip()
       
def extractCause(stringa):
    stringa = stringa.upper()
    cause = None
    match = re.search("(?<=GRUND).*?(?=KORRECTUR)", stringa)
    if match:
       cause = match.group(0)
    return cause.strip()

def extractCorrection(stringa):
    stringa = stringa.upper()
    correction = None
    match = re.search("(?<=KORRECTUR).*", stringa)
    if match:
       correction = match.group(0)
    return correction.strip()


# COMMAND ----------

#apply funzioni
failures["Complaint"] = failures.apply(lambda x: extractComplaint(x["FailureComment"]), axis=1)
failures["Cause"] = failures.apply(lambda x: extractCause(x["FailureComment"]), axis=1)
failures["Correction"] = failures.apply(lambda x: extractCorrection(x["FailureComment"]), axis=1)

# COMMAND ----------

#translate
failures["ComplaintTranslate"] = failures.apply(lambda x: GoogleTranslator(source='de', target='en').translate(x["Complaint"]), axis=1)

failures["CauseTranslate"] = failures.apply(lambda x: GoogleTranslator(source='de', target='en').translate(x["Cause"]), axis=1)

failures["CorrectionTranslate"] = failures.apply(lambda x: GoogleTranslator(source='de', target='en').translate(x["Correction"]), axis=1)

# COMMAND ----------

spark.createDataFrame(failures).write.saveAsTable("reliab.20230705_NMT_GermanFailureCommentsTranslated_GT")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Italia
# MAGIC

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
failures = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")

#drop vars
colsToKeep = ["VP Code", "Chassis", "Claim Number", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
failures = failures.loc[:, colsToKeep]


#change var names
failures.reset_index(inplace=True)
columns = failures.columns.str.title()

replace = [" ", "(", ")", "."]
for rep in replace:
    columns = [col.replace(rep, "") for col in columns]

failures.columns = columns

#drop if alredy english
failures = failures.loc[failures.MarketRepairCode == "IT", :]
failures.FailureComment = failures.FailureComment.str.replace("\t", "")

# COMMAND ----------

#funzioni per pulire e separare 
import re

def basicCleaning(stringa):
   cleaned = None
   if type(stringa)==str:
      cleaned = re.sub("[\t]", "", stringa)
      cleaned = re.sub("[\-]", "", stringa)
      cleaned = re.sub("[\&]", "and", stringa)
   return cleaned

def extractComplaint(stringa):
    stringa = stringa.upper()
    complaint = None
    match = re.search("(?<=TIPO_DANNO).*?(?=CAUSA)", stringa)
    if match:
       complaint = match.group(0)
    return complaint.strip()
       
def extractCause(stringa):
    stringa = stringa.upper()
    cause = None
    match = re.search("(?<=CAUSA).*?(?=CORREZIONE)", stringa)
    if match:
       cause = match.group(0)
    return cause.strip()

def extractCorrection(stringa):
    stringa = stringa.upper()
    correction = None
    match = re.search("(?<=CORREZIONE).*", stringa)
    if match:
       correction = match.group(0)
    return correction.strip()


# COMMAND ----------

#apply funzioni
failures["Complaint"] = failures.apply(lambda x: extractComplaint(x["FailureComment"]), axis=1)
failures["Cause"] = failures.apply(lambda x: extractCause(x["FailureComment"]), axis=1)
failures["Correction"] = failures.apply(lambda x: extractCorrection(x["FailureComment"]), axis=1)

# COMMAND ----------

#translate
failures["ComplaintTranslate"] = failures.apply(lambda x: GoogleTranslator(source='it', target='en').translate(x["Complaint"]), axis=1)

failures["CauseTranslate"] = failures.apply(lambda x: GoogleTranslator(source='it', target='en').translate(x["Cause"]), axis=1)

failures["CorrectionTranslate"] = failures.apply(lambda x: GoogleTranslator(source='it', target='en').translate(x["Correction"]), axis=1)

# COMMAND ----------

spark.createDataFrame(failures).write.saveAsTable("reliab.20230705_NMT_ItalianFailureCommentsTranslated_GT")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Belgio

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
failures = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")

#drop vars
colsToKeep = ["VP Code", "Chassis", "Claim Number", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
failures = failures.loc[:, colsToKeep]


#change var names
failures.reset_index(inplace=True)
columns = failures.columns.str.title()

replace = [" ", "(", ")", "."]
for rep in replace:
    columns = [col.replace(rep, "") for col in columns]

failures.columns = columns

#drop if alredy english
failures = failures.loc[failures.MarketRepairCode == "BE", :]
failures.FailureComment = failures.FailureComment.str.replace("\t", "")

# COMMAND ----------

#funzioni per pulire e separare 
import re

def basicCleaning(stringa):
   cleaned = None
   if type(stringa)==str:
      cleaned = re.sub("[\t]", "", stringa)
      cleaned = re.sub("[\-]", "", stringa)
      cleaned = re.sub("[\&]", "and", stringa)
   return cleaned

def extractComplaint(stringa):
    stringa = stringa.upper()
    complaint = None
    match = re.search("((?<=COMPLAINT)|(?<=KLACHT)|(?<=INCIDENT)).*?((?=CAUSE)|(?=OORZAAK))", stringa)
    if match:
       complaint = match.group(0)
    return complaint.strip()
       
def extractCause(stringa):
    stringa = stringa.upper()
    cause = None
    match = re.search("((?<=CAUSE)|(?<=OORZAAK)).*?(?=CORRECTION|SOLUTION|CORRECTIE)", stringa)
    if match:
       cause = match.group(0)
    return cause.strip()

def extractCorrection(stringa):
    stringa = stringa.upper()
    correction = None
    match = re.search("((?<=CORRECTION)|(?<=SOLUTION)|(?<=CORRECTIE)).*", stringa)
    if match:
       correction = match.group(0)
    return correction.strip()


# COMMAND ----------

#apply funzioni
failures["Complaint"] = failures.apply(lambda x: extractComplaint(x["FailureComment"]), axis=1)
failures["Cause"] = failures.apply(lambda x: extractCause(x["FailureComment"]), axis=1)
failures["Correction"] = failures.apply(lambda x: extractCorrection(x["FailureComment"]), axis=1)

# COMMAND ----------

#translate
from deep_translator import GoogleTranslator

failures["ComplaintTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Complaint"]), axis=1)
failures["CauseTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Cause"]), axis=1)
failures["CorrectionTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Correction"]), axis=1)

# COMMAND ----------

spark.createDataFrame(failures).write.saveAsTable(f"reliab.20230705_NMT_BelgioFailureCommentsTranslated_GT")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Polacco

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
failures = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")

#drop vars
colsToKeep = ["VP Code", "Chassis", "Claim Number", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
failures = failures.loc[:, colsToKeep]


#change var names
failures.reset_index(inplace=True)
columns = failures.columns.str.title()

replace = [" ", "(", ")", "."]
for rep in replace:
    columns = [col.replace(rep, "") for col in columns]

failures.columns = columns

#drop if alredy english
failures = failures.loc[failures.MarketRepairCode == "PL", :]
failures.FailureComment = failures.FailureComment.str.replace("\t", "")

# COMMAND ----------

#funzioni per pulire e separare 
import re

def basicCleaning(stringa):
   cleaned = None
   if type(stringa)==str:
      cleaned = re.sub("[\t]", "", stringa)
      cleaned = re.sub("[\-]", "", stringa)
      cleaned = re.sub("[\&]", "and", stringa)
   return cleaned

def extractComplaint(stringa):
    stringa = stringa.upper()
    complaint = None
    match = re.search("((?<=COMPLAINT)|(?<=KLACHT)|(?<=SKARGA)).*?((?=CAUSE)|(?=OORZAAK)|(?=CPRZ))", stringa)
    if match:
       complaint = match.group(0)
    return complaint
       
def extractCause(stringa):
    stringa = stringa.upper()
    cause = None
    match = re.search("((?<=CAUSE)|(?<=OORZAAK)|(?<=CPRZ)).*?(?=CORRECTION|KORECTA|CORRECTIE)", stringa)
    if match:
       cause = match.group(0)
    return cause

def extractCorrection(stringa):
    stringa = stringa.upper()
    correction = None
    match = re.search("((?<=CORRECTION)|(?<=KORECTA)|(?<=CORRECTIE)).*", stringa)
    if match:
       correction = match.group(0)
    return correction


# COMMAND ----------

#apply funzioni
failures["Complaint"] = failures.apply(lambda x: extractComplaint(x["FailureComment"]), axis=1)
failures["Cause"] = failures.apply(lambda x: extractCause(x["FailureComment"]), axis=1)
failures["Correction"] = failures.apply(lambda x: extractCorrection(x["FailureComment"]), axis=1)

# COMMAND ----------

#translate
from deep_translator import GoogleTranslator

failures["ComplaintTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Complaint"]), axis=1)
failures["CauseTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Cause"]), axis=1)
failures["CorrectionTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Correction"]), axis=1)

# COMMAND ----------

spark.createDataFrame(failures).write.saveAsTable(f"reliab.20230705_NMT_PoloniaFailureCommentsTranslated_GT")

# COMMAND ----------

# MAGIC %md
# MAGIC ####  Olanda

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
failures = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")

#drop vars
colsToKeep = ["VP Code", "Chassis", "Claim Number", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
failures = failures.loc[:, colsToKeep]


#change var names
failures.reset_index(inplace=True)
columns = failures.columns.str.title()

replace = [" ", "(", ")", "."]
for rep in replace:
    columns = [col.replace(rep, "") for col in columns]

failures.columns = columns

#drop if alredy english
failures = failures.loc[failures.MarketRepairCode == "NL", :]
failures.FailureComment = failures.FailureComment.str.replace("\t", "")

# COMMAND ----------

#funzioni per pulire e separare 
import re

def basicCleaning(stringa):
   cleaned = None
   if type(stringa)==str:
      cleaned = re.sub("[\t]", "", stringa)
      cleaned = re.sub("[\-]", "", stringa)
      cleaned = re.sub("[\&]", "and", stringa)
   return cleaned

def extractComplaint(stringa):
    stringa = stringa.upper()
    complaint = None
    match = re.search("((?<=COMPLAINT)|(?<=KLACHT)|(?<=INCIDENT)).*?((?=CAUSE)|(?=OORZAAK))", stringa)
    if match:
       complaint = match.group(0)
    return complaint.strip()
       
def extractCause(stringa):
    stringa = stringa.upper()
    cause = None
    match = re.search("((?<=CAUSE)|(?<=OORZAAK)).*?(?=CORRECTION|SOLUTION|CORRECTIE)", stringa)
    if match:
       cause = match.group(0)
    return cause.strip()

def extractCorrection(stringa):
    stringa = stringa.upper()
    correction = None
    match = re.search("((?<=CORRECTION)|(?<=SOLUTION)|(?<=CORRECTIE)).*", stringa)
    if match:
       correction = match.group(0)
    return correction.strip()


# COMMAND ----------

#apply funzioni
failures["Complaint"] = failures.apply(lambda x: extractComplaint(x["FailureComment"]), axis=1)
failures["Cause"] = failures.apply(lambda x: extractCause(x["FailureComment"]), axis=1)
failures["Correction"] = failures.apply(lambda x: extractCorrection(x["FailureComment"]), axis=1)

# COMMAND ----------

#translate
from deep_translator import GoogleTranslator

failures["ComplaintTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Complaint"]), axis=1)
failures["CauseTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Cause"]), axis=1)
failures["CorrectionTranslate"] = failures.apply(lambda x: GoogleTranslator(source='auto', target='en').translate(x["Correction"]), axis=1)

# COMMAND ----------

spark.createDataFrame(failures).write.saveAsTable(f"reliab.20230705_NMT_OlandaFailureCommentsTranslated_GT")

# COMMAND ----------

# MAGIC %md
# MAGIC ### GB

# COMMAND ----------

import pandas as pd
import openpyxl

#load file
failures = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")

#drop vars
colsToKeep = ["VP Code", "Chassis", "Claim Number", "Failure Comment" , "Invoice Market Code", "Market Repair Code"]
failures = failures.loc[:, colsToKeep]


#change var names
failures.reset_index(inplace=True)
columns = failures.columns.str.title()

replace = [" ", "(", ")", "."]
for rep in replace:
    columns = [col.replace(rep, "") for col in columns]

failures.columns = columns

#drop if alredy english
failures = failures.loc[failures.MarketRepairCode == "GB", :]
failures.FailureComment = failures.FailureComment.str.replace("\t", "")

# COMMAND ----------

#funzioni per pulire e separare 
import re

def basicCleaning(stringa):
   cleaned = None
   if type(stringa)==str:
      cleaned = re.sub("[\t]", "", stringa)
      cleaned = re.sub("[\-]", "", stringa)
      cleaned = re.sub("[\&]", "and", stringa)
   return cleaned

def extractComplaint(stringa):
    stringa = stringa.upper()
    complaint = None
    match = re.search("((?<=COMPLAINT)|(?<=INCIDENT)).*?(?=CAUSE)", stringa)
    if match:
       complaint = match.group(0)
    return complaint.strip()
       
def extractCause(stringa):
    stringa = stringa.upper()
    cause = None
    match = re.search("(?<=CAUSE).*?(?=CORRECTION|SOLUTION)", stringa)
    if match:
       cause = match.group(0)
    return cause.strip()

def extractCorrection(stringa):
    stringa = stringa.upper()
    correction = None
    match = re.search("((?<=CORRECTION)|(?<=SOLUTION)).*", stringa)
    if match:
       correction = match.group(0)
    return correction.strip()


# COMMAND ----------

#apply funzioni
failures["Complaint"] = failures.apply(lambda x: extractComplaint(x["FailureComment"]), axis=1)
failures["Cause"] = failures.apply(lambda x: extractCause(x["FailureComment"]), axis=1)
failures["Correction"] = failures.apply(lambda x: extractCorrection(x["FailureComment"]), axis=1)

# COMMAND ----------

#translate
from deep_translator import GoogleTranslator

failures["ComplaintTranslate"] = ""
failures["CauseTranslate"] = ""
failures["CorrectionTranslate"] = ""

# COMMAND ----------

spark.createDataFrame(failures).write.mode("overWrite").option("overwriteschema", "true").saveAsTable(f"reliab.20230705_NMT_GBFailureCommentsTranslated_GT")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Unire i vari commenti tradotti

# COMMAND ----------

gb = spark.read.table("reliab.20230705_nmt_GBFailurecommentstranslated_gt")
fr = spark.read.table("reliab.20230705_nmt_frenchfailurecommentstranslated_gt")
de = spark.read.table("reliab.20230705_nmt_germanfailurecommentstranslated_gt")
it = spark.read.table("reliab.20230705_nmt_italianfailurecommentstranslated_gt")
pl = spark.read.table("reliab.20230705_NMT_PoloniaFailureCommentsTranslated_GT")
be = spark.read.table("reliab.20230705_NMT_BelgioFailureCommentsTranslated_GT")
nl = spark.read.table("reliab.20230705_NMT_OlandaFailureCommentsTranslated_GT")


# COMMAND ----------

display(gb.union(fr).union(de).union(it).union(pl).union(be).union(nl))

# COMMAND ----------

keep = list(['ClaimNumber' ,'Complaint', 'Cause',
       'Correction', 'ComplaintTranslate', 'CauseTranslate',
       'CorrectionTranslate'])

df = df.loc[:,keep]

# COMMAND ----------

allVar = pd.read_excel("/dbfs/FileStore/tables/reliab/5802290191_Claim_Estrazione_Maggio_2023_OP_Survey_Cables.xlsx")
allVar = allVar.rename({"Claim Number":"ClaimNumber"},axis=1)

# COMMAND ----------

final =  pd.merge(allVar, df, on="ClaimNumber", how="inner")

# COMMAND ----------

final.to_csv("/dbfs/FileStore/tables/reliab/20230712_translateAll.csv", index=False)

# COMMAND ----------

final

# COMMAND ----------

