# Databricks notebook source
spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

spark.sparkContext.defaultParallelism

# COMMAND ----------

