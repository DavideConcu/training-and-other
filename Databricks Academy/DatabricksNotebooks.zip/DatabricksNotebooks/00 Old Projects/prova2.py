# Databricks notebook source
df = spark.read.table("reliab.onexvinalldailymy19_20230210").select("chassis", "startOfSampling", "totalDistance" , "gvw").limit(1000)
df

# COMMAND ----------

from pyspark.sql.functions import col, to_date
df = df.withColumn("date", to_date(col("startOfSampling")))

# COMMAND ----------

display(df.limit(10))

# COMMAND ----------

display(df.where(col("chassis") == "ZCFC735B005382711").groupBy("chassis").pivot("gvw").sum())

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

import math
import matplotlib.pyplot as plt

#bisogna creare l'ultimo grafico fuori dal loop (altrimenti viene cancellato ad ogni iterazione)
fig_pt5, ax_pt5 = plt.subplots()

#loop infinito (finchè non incontra un break)
while True:
    try:
        #Punto 1) chiede di inserire nome e la sua emivita (tau)
        nome_isotopo = input("inserire il nome dell'isotopo: ") 
        tau = float(input("inserire l'emivita in secondi: ")) #float serve a trasformare l'input da stringa a float (numero)

        #Punto 2) chiede di inserire la quantità iniziale P_0 e il tempo trascorso t
        P_0 = float(input("inserire la quantità inziale in grammi: "))
        t = float(input("inserire il tempo trascorso in secondi: "))

        #funzione per avere la quantità rimasta, P0 * e^(-ln(2)*t/tau)
        P = P_0 * math.exp(-math.log(2)*(t/tau)) 

        #Punto 3) visualizzare il risultato
        plt.title("Quantità iniziale vs quantità finale, isotopo  {}".format(nome_isotopo))
        plt.bar(["Quantità iniziale", "Quantità dopo {} secondi".format(t)], height=[P_0, P]) #f" {} " serve a inserire parametri in una stringa
        plt.show()

        #punto 4) massa iniziale P_0 dati P e t 
        P_pt4 = 5
        t_pt4 = 30
        P_0_pt4 = P_pt4 / ( math.exp(-math.log(2)*(t_pt4/tau)) )

        plt.title("Quantità necessaria ad avere 5 gr dopo 30 s, isotopo {}".format(nome_isotopo))
        plt.bar(["Quantità iniziale", "Quantità dopo 30 secondi"], height=[P_0_pt4, P_pt4]) #f" {} " serve a inserire parametri in una stringa
        plt.show()


        #punto 5) quantità in funzione del tempo 
        P_0_pt5 = list() #crea una lista vuota da riempire con i P_0 calcolati sul tempo

        for tempo in range(11):
            risultato = P_0 * math.exp(-math.log(2)*(tempo/tau)) #calcola il risultato 
            P_0_pt5.append(risultato) #aggiunge il risultato alla lista
            
        #aggiungere il grafico 
        ax_pt5.set_ylabel('Quantità iniziale')
        ax_pt5.set_xlabel('secondi')
        ax_pt5.set_title('Decadimento in 10 secondi')
        ax_pt5.plot(range(11), P_0_pt5,  label = nome_isotopo)
        
    except:
        ax_pt5.legend()
        fig_pt5.show()
        break
     

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED reliab.`2023_r39_rg_daily_clean`

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from
# MAGIC
# MAGIC reliab.20230711_rgdailycng_allchassisaggforpowerbi

# COMMAND ----------

