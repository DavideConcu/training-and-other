# Databricks notebook source
# MAGIC %md
# MAGIC # Download Data

# COMMAND ----------

#output data spec
from datetime import date 

data = date.today().strftime('%Y%m%d')
progetto = "FlottaRGManu"
notebook = "DownloadData"

nome = data + "_" + progetto + "_" + notebook

# COMMAND ----------

#download
from pyspark.sql.functions import col

listaChassis = ["WJMM62AT40C465722" , "WJMM62AWX0C471860" , "WJMM62AW40C472003"]

dataset = "datacollector.datacollector_tabular_mission_for_wti_super_flat_prod"

varList = ["chassis", "missionId", "totalDistance/(totalTime/3600) as averageSpeed",
            "totaltime", 
            "totalTimeDriving/totalTime as percentTimeDriving", 
            "totalTimeIdling/totalTime as percentTimeIdling",
            "totalTimePtoOn/totalTime as percentTimePTOon",
            "totalTimeACC/totalTime as percentTimeACC", 
            "totalTimeBrakePedal/totalTime as percentTimeBrakePedal",
            "totalDistance", 
            "totalDistancePtoOn/totalDistance as percentDistancePtoOn",
            "totalDistanceACC/totalDistance as percentDistanceACC",
            "fuelConsumption/totalDistance as fuelConsumptionDistance", 
            "maxVehicleSpeed",
            "stops/totalDistance as stopsDistance",
            "harshSteering/totalDistance as harshSteeringDistance", 
            "harshBraking/totalDistance as harshBrakingDistance",
            "engineWorkHours"]

spark.read.table(dataset)\
                .selectExpr(varList)\
                .filter(col("chassis").isin(listaChassis))\
                .write.format("delta").saveAsTable(f"reliab.{nome}")




# COMMAND ----------

