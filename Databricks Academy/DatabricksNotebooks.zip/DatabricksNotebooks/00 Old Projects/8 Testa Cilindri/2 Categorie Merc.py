# Databricks notebook source
#lista vin
from pyspark.sql.functions import col

vehic = spark.read.table("edwh.vehicle")\
            .withColumnRenamed("pvan_cd_vin_code", "chassis")

df = spark.read.table("reliab.20230717_testeCilindroDaily_data")\
            .select("chassis").distinct()\
            .join(vehic, "chassis")
            

# COMMAND ----------

display(df.select("chassis", "cust_ds_cust_nm_customer" ).filter(col("thdb_ds_endcu_type")=="Dealer"))

display(df.select("chassis", "thdb_ds_endcu_last_name" , "thdb_ds_endcu_org_name").filter(col("thdb_ds_endcu_type")=="End Customer"))

# COMMAND ----------

