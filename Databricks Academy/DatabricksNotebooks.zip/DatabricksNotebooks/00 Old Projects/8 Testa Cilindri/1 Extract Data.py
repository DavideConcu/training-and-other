# Databricks notebook source
# MAGIC %md
# MAGIC ## Download Data Testa Cilindri

# COMMAND ----------

import pandas as pd
file = pd.read_csv("/dbfs/FileStore/tables/reliab/cylhead.csv")

chassis = spark.createDataFrame(file)\
                .selectExpr("Serial_Number as chassis")

# COMMAND ----------

#download super flat data
from pyspark.sql.functions import col

nome = "reliab.20230717_testeCilindroDaily_data"

spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
                    .join(chassis, "chassis")\
                    .write\
                    .mode("overwrite")\
                    .option("overwriteschema", "true")\
                    .saveAsTable(f"{nome}")


print(f"saved file: {nome}")

# COMMAND ----------

#download super flat data
from pyspark.sql.functions import col

nome = "reliab.20230717_testeCilindroDaily_dataPATH"

spark.read.table("datacollector.datacollector_gps_tabular_prod")\
                    .join(chassis, "chassis")\
                    .write\
                    .mode("overwrite")\
                    .option("overwriteschema", "true")\
                    .saveAsTable(f"{nome}")


print(f"saved file: {nome}")

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct chassis from reliab.20230717_testeCilindroDaily_data

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC from reliab.20230717_testeCilindroDaily_dataPATH

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from reliab.20230717_testeCilindroDaily_data

# COMMAND ----------

