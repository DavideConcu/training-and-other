# Databricks notebook source
# MAGIC %md
# MAGIC ## AAU km

# COMMAND ----------

from pyspark.sql.functions import col, min, max, first, collect_list, datediff
from pyspark.sql.window import Window

df = spark.read.table("reliab.20230717_testeCilindroDaily_data")\
                .filter(col("odoAtStart").isNotNull())\
                 .select("chassis", "missionId", "odoAtStart", "startofsampling")




dfDates = df\
            .groupBy("chassis")\
            .agg(min(col("startofsampling")).alias("startDate"), max(col("startofsampling")).alias("endDate"))



windowSpec = Window().partitionBy("chassis").orderBy("startofsampling").rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)

df = df.join(dfDates, "chassis")\
        .filter((col("startofsampling") == col("startDate")) | (col("startofsampling") == col("endDate") ))
       
       

aau = df.select(first("chassis").over(windowSpec).alias("chassis"), 
                collect_list(col("startofsampling")).over(windowSpec).alias("dates"),
                collect_list(col("odoatstart")).over(windowSpec).alias("odos")).distinct()\
                .select("*", 
                            datediff(col("dates")[1], col("dates")[0]).alias("daysBetween"),
                            (col("odos")[1]-col("odos")[0]).alias("odoDiff"))\
                .filter(col("daysBetween")>0)\
                .selectExpr("*", "(odoDiff*(365/daysBetween))/1000 as AAU_km")

# COMMAND ----------

# MAGIC %md
# MAGIC ## AAU ore

# COMMAND ----------

from pyspark.sql.functions import col, min, max, first, collect_list, datediff
from pyspark.sql.window import Window

df = spark.read.table("reliab.20230717_testeCilindroDaily_data")\
                .filter(col("engineWorkHours").isNotNull())\
                 .select("chassis", "missionId", "engineWorkHours", "startofsampling")




dfDates = df\
            .groupBy("chassis")\
            .agg(min(col("startofsampling")).alias("startDate"), max(col("startofsampling")).alias("endDate"))



df = df.join(dfDates, "chassis")\
        .filter((col("startofsampling") == col("startDate")) | (col("startofsampling") == col("endDate") ))
       


#dataset con tutte le mission
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, desc,col, collect_list, datediff, abs

dateVariable = "startOfSampling"

windowAscend = Window().partitionBy("chassis").orderBy(dateVariable)
windowDescend = Window().partitionBy("chassis").orderBy(desc(dateVariable))

aauOre = df\
    .filter(col("engineWorkHours").isNotNull())\
                .groupBy("chassis")\
                .agg(collect_list(col(dateVariable)).alias("dates"), 
                        collect_list(col("engineWorkHours")).alias("engine"))\
                .select("*", 
                            datediff(col("dates")[1], col("dates")[0]).alias("daysBetween"),
                            (col("engine")[1]-col("engine")[0]).alias("engineDiff"),
                            )\
                .select("*", (abs((365/col("daysBetween"))*col("engineDiff"))).alias("AAU_Hours"))


# COMMAND ----------

display(aauOre)

# COMMAND ----------

