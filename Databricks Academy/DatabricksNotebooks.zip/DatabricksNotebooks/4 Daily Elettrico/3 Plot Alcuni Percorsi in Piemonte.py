# Databricks notebook source
pip install folium

# COMMAND ----------

from pyspark.sql.functions import col , first

veicoliConStartDate = spark.read.table("reliab.20231019_dailyelettrico_gpsdata_simolist_onlyWarranty")\
                                .select("chassis", "warrantyStartDate").distinct()

#table with piedmont bool
missionPiemonteDf = spark.read.table("reliab.20231023_dailyelettrico_checkifinpiemonte")\
                        .filter(col("isInPiedmont")==True)\
                            .join(veicoliConStartDate, "chassis")\
                            .select("chassis", "missionId", "isInPiedmont")
                               # .groupBy("chassis").agg(first(col("missionId")).alias("missionId"))

df = spark.read.table("reliab.20231019_dailyelettrico_gpsdata_simolist")\
            .join(missionPiemonteDf, ["chassis", "missionId"])
                

# COMMAND ----------

df.groupBy("chassis").count().show()

# COMMAND ----------

customer = spark.read.table("edwh.vehicle")\
                    .selectExpr("pvan_cd_vin_code as chassis", "cust_ds_cust_nm_dealer as dealer", "thdb_ds_endcu_org_name as endcustomer", "pvan_id_warranty_start_date as warrantyStartDate")

chassisPiemonte = missionPiemonteDf.select("chassis").distinct()\
                    .join(customer, "chassis")


# COMMAND ----------

display(chassisPiemonte)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plot Mission

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    
    folium.Circle(
        location=row['path'][0],
        icon=folium.Icon(icon='point', color='green'),
        popup = popup
    ).add_to(listaLayers[num])
    
    folium.Circle(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popup
    ).add_to(listaLayers[num])


# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


df = df\
    .filter(col("latitude").isNotNull())\
    .filter(col("longitude").isNotNull())\
    .sort("missionid", "timestamp")\
    .withColumn("latLon", array("latitude", "longitude"))\
    .groupBy("chassis", "missionId")\
    .agg(collect_list("latlon").alias("path")).toPandas()

# COMMAND ----------

import pandas as pd

missionSelection = pd.DataFrame()

for chassis in set(df["chassis"]):
    sample = df.loc[df.chassis == chassis, :].sample(200)
    missionSelection = pd.concat([missionSelection, sample] , axis = 0)


# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


#df = df\
#    .filter(col("latitude").isNotNull())\
#    .filter(col("longitude").isNotNull())\
#    .sort("missionid", "timestamp")\
#    .withColumn("latLon", array("latitude", "longitude"))\
#    .groupBy("chassis", "missionId")\
#    .agg(collect_list("latlon").alias("path")).toPandas()

df = missionSelection.copy()

#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

