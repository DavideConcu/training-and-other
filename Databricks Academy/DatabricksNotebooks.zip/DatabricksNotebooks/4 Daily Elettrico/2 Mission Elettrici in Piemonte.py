# Databricks notebook source
table = "reliab.20231019_dailyelettrico_gpsdata_simolist"

# COMMAND ----------

from pyspark.sql.functions import col

df = spark.read.table(table).orderBy(col("chassis"), col("sessionId"), col("tripId"), col("missionId"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Contare Tempo nella stessa Session, Trip e Mission

# COMMAND ----------

df = df.withColumn("time", col("endofsampling").cast("long") - col("startofsampling").cast("long"))

# COMMAND ----------

from pyspark.sql.functions import mean,max

display(df.groupBy(["chassis", "missionid", ]).agg(max(col("time")/60)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check if MissionId in Piemonte

# COMMAND ----------

pip install shapely

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "DailyElettrico"
notebook = "checkIfInPiemonte"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

from pyspark.sql.functions import array, col, mean

table = "reliab.20231019_dailyelettrico_gpsdata_simolist"

#to array
longitudeColumn = "Longitude"
latitudeColumn = "Latitude"

#load input data 
df = spark.read.table(table)\
    .selectExpr("chassis", "missionId", longitudeColumn, latitudeColumn)\
        .filter(col(longitudeColumn).isNotNull() & col(latitudeColumn).isNotNull())
            


df = df.groupBy(["chassis", "missionId"]).agg(mean(col(longitudeColumn)).alias(longitudeColumn), mean(col(latitudeColumn)).alias(latitudeColumn))\
        .withColumn("lonLat", array(col(longitudeColumn), col(latitudeColumn)))                

# COMMAND ----------

import json
from pyspark.sql.functions import pandas_udf
from shapely.geometry import shape, GeometryCollection, Point

with open("/dbfs/FileStore/tables/reliab/ConfiniPiemonte.geojson", 'r') as f:
    js = json.load(f)

#funzione da applicare alle righe
def checkIfInsidePolygon(lonLat):
    """ check if coordinate is inside polygon """
    result = False

    point = Point(lonLat)

    for feature in js['features']:
        polygon = shape(feature['geometry'])

        if polygon.contains(point):
            result = True

    return result

checkIfInsidePolygonUdf = udf(checkIfInsidePolygon)

# COMMAND ----------

#apply function
df = df.withColumn("isInPiedmont", checkIfInsidePolygonUdf(col("lonLat")).cast("boolean"))

# COMMAND ----------


toSave = False

if toSave: 
    df.write\
    .mode("overwrite")\
    .option("overwriteSchema", "true")\
    .saveAsTable(f"{nome}")

print(nome)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from reliab.20231023_DailyElettrico_checkIfInPiemonte
# MAGIC where isInPiedmont is true

# COMMAND ----------

