# Databricks notebook source
dailyElettriciDf = spark.read.table("edaily.edaily_map").select("chassis").distinct()

# COMMAND ----------

display(dailyElettriciDf)

# COMMAND ----------

#join con il gps
gpsData = spark.read.table("datacollector.datacollector_gps_tabular_prod")\
           .join(listaDailyElettrici, "chassis")

# COMMAND ----------

#save dataset
from datetime import date
today = str(date.today()).replace("-", "")

nome = f"reliab.{today}_DailyElettrico_GPSdata"

toDownload = False
if toDownload:
    gpsData.write.saveAsTable(nome)

# COMMAND ----------

#aggiunta del warranty start date
from pyspark.sql.functions import col

warranty = spark.read.table("edwh.vehicle").selectExpr("pvan_cd_vin_code as chassis" ,"pvan_id_warranty_start_date as warrantyStartDate", "makt_cd_country as market")
dailyElettriciAllDf = dailyElettriciDf.join(warranty, "chassis", "left")
dailyElettriciWithStartDateDf = dailyElettriciDf.join(warranty.filter(col("warrantyStartDate").isNotNull()), "chassis")

# COMMAND ----------

display(dailyElettriciWithStartDateDf)

# COMMAND ----------

chassisListFromSimo = ['ZCFCX35E205539939',
'ZCFCX38E405542465',
'ZCFCX35E505542835',
'ZCFCX38E005563538',
'ZCFCX38E705538393',
'ZCFCX35E705540293',
'ZCFCX38E105551236',
'ZCFCX35E805535653',
'ZCFCX38E305540870',
'ZCFCX35E205563030',
'ZCFCX38E705540869',
'ZCFCX38E205553691',
'ZCFCX38EX05547606',
'ZCFCX38E405560321',
'ZCFCX38E405537332',
'ZCFCX35E705549057',
'ZCFCX38EX05548349',
'ZCFCX35E905547228',
'ZCFCX38E405538027',
'ZCFCX35EX05563289',
'ZCFCX38EX05532815',
'ZCFCX38E305551237',
'ZCFCX38E905535995',
'ZCFCX35E705534932',
'ZCFCX38E305530985',
'ZCFCX35E605533173',
'ZCFCX38EX05554278',
'ZCFCX38E905549329',
'ZCFCX38E505553698',
'ZCFCX38E205537684',
'ZCFCX38E105535652',
'ZCFCX38E805548981',
'ZCFCX38E105550071',
'ZCFCX35E705539936',
'ZCFCX38E805551959',
'ZCFCX38E605551586',
'ZCFCX38E605550860',
'ZCFCY72E205545720',
'ZCFCX35E505545721',
'ZCFCX35E705545722',
'ZCFCX35E105535316',
'ZCFCX38EX05525881',
'ZCFCX38E605519429',
'ZCFCX38E405524788',
'ZCFCX38E205524790',
'ZCFCX38E005514520',
'ZCFCX38EX05526576',
'ZCFCX38E605526249',
'ZCFCX38E205526250',
'ZCFCX38E105525512',
'ZCFCX38E805525880',
'ZCFCX38E605524789',
'ZCFCX38E205523669',
'ZCFCX38E005524030',
'ZCFCX38EX05519787',
'ZCFCX38EX05518011',
'ZCFCX38E005525159',
'ZCFCX38E205524384',
'ZCFCX38E005522276',
'ZCFCX38EX05518719',
'ZCFCX38E505518367',
'ZCFCX38E405524029',
'ZCFCX38E305525513',
'ZCFCX38E105523307',
'ZCFCX38E005523668',
'ZCFCX38E005513805',
'ZCFCX38E405522636',
'ZCFCX38E905522969',
'ZCFCX38E905521269',
'ZCFCX38E705521626',
'ZCFCX38E705521268',
'ZCFCX38E705514157',
'ZCFCX38E605520161',
'ZCFCX38E505521625',
'ZCFCX38E405520532',
'ZCFCX38E205522277',
'ZCFCX38E205520531',
'ZCFCX38E705516927',
'ZCFCX38E405512737',
'ZCFCX38E005513450',
'ZCFCX38EX05517277']

# COMMAND ----------

#save dataset
from datetime import date
today = str(date.today()).replace("-", "")

nome = f"reliab.{today}_DailyElettrico_GPSdata_SimoList"

toDownload = False

if toDownload:
    #join con il gps
    gpsData = spark.read.table("datacollector.datacollector_gps_tabular_prod")\
           .filter(col("chassis").isin(chassisListFromSimo))
    gpsData.write.saveAsTable(nome)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tenere solo i vin con warranty start date (venduti)

# COMMAND ----------

from pyspark.sql.functions import col

table = "reliab.20231019_dailyelettrico_gpsdata_simolist"

vehicle = spark.read.table("edwh.vehicle")\
                    .selectExpr("pvan_cd_vin_code as chassis", "pvan_id_warranty_start_date as warrantyStartDate")\
                        .filter(col("warrantyStartDate").isNotNull())

df = spark.read.table(table)\
            .join(vehicle, ["chassis"])


# COMMAND ----------

toSave = True

if toSave:
    df.write.saveAsTable(table + "_onlyWarranty")

# COMMAND ----------

