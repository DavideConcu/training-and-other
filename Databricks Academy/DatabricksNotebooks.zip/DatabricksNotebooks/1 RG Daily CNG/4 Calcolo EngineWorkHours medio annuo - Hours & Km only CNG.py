# Databricks notebook source
# MAGIC %md
# MAGIC ## Daily CNG

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Lista Chassis di Cinzia

# COMMAND ----------

file = "/dbfs/FileStore/tables/reliab/chassisList_DailyCNG_perCinzia_20231130.csv"

# COMMAND ----------

import pandas as pd
listaChassisDf = pd.read_csv(file)
listaChassis = listaChassisDf["chassis"].to_list()

# COMMAND ----------

len(listaChassis)

# COMMAND ----------

from pyspark.sql.functions import min, max, col

tabl = "reliab.20230526_RGDailyCNG_dataSuperFlatStarting2022_daEDWH"

#load table
df = spark.read.table(tabl)

df.filter(col("chassis").isin(listaChassis)).count()

# COMMAND ----------

from pyspark.sql.functions import min, max, col


#input table
tabl = "reliab.20230526_RGDailyCNG_dataSuperFlatStarting2022_daEDWH"

#load table
df = spark.read.table(tabl)


#trovare la lista di f1C soltanto
from pyspark.sql.functions import col

listaChassisDaEDWH_F1C = (spark.read.table("edwh.vehicle")\
                .filter((col("pvcb_ds_sub_product_cl").like("%DAILY%F1C%POWER%"))|(col("pvcb_ds_sub_product_cl").like("%DAILY%F1C%CNG%")))\
                .filter((col("pvan_ds_preliminary_model_year")=="MY2019")|(col("pvan_ds_preliminary_model_year")=="MY2021")))\
                .select(col("pvan_cd_vin_code").alias("chassis"), col("pvan_id_warranty_start_date").alias("warrStartDate"), col("pvcb_ds_sub_product_cl").alias("modello") )



df = df.join(listaChassisDaEDWH_F1C, "chassis")\
            .filter(col("startOfSampling")>col("warrStartDate"))\
            .filter(col("engineWorkhours").isNotNull())


dfDates = df\
            .groupBy(col("chassis"))\
            .agg(min(col("startOfsampling")).alias("minDate"), max(col("startofSampling")).alias("maxDate"))


df = df.join(dfDates, "chassis")\
        .filter((col("startofsampling")==col("minDate")) | (col("startofsampling")==col("maxDate")))\
        .selectExpr("chassis", "modello", "startofsampling", "engineWorkHours", "odoAtEnd/1000 as odoAtEnd")

# COMMAND ----------

#dataset con tutte le mission
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, desc,col, collect_list, datediff, pow, abs


dateVariable = "startofsampling"

windowAscend = Window().partitionBy("chassis").orderBy(dateVariable)
windowDescend = Window().partitionBy("chassis").orderBy(desc(dateVariable))

df = df\
        .filter(col("engineWorkHours").isNotNull())\
                    .groupBy("chassis")\
                    .agg(collect_list(col(dateVariable)).alias("dates"), 
                            collect_list(col("engineWorkHours")).alias("engine"),
                            collect_list(col("odoAtEnd")).alias("odoAtEnd")
                            )\
                    .select("*", 
                                abs(datediff(col("dates")[1], col("dates")[0])).alias("daysBetween"),
                                abs((col("engine")[1]-col("engine")[0])).alias("engineDiff"),
                                abs((col("odoAtEnd")[1]-col("odoAtEnd")[0])).alias("odoDiff")
                                )\
                    .select("*", ((365/col("daysBetween"))*col("engineDiff")).alias("AAU_Hours"),
                                 ((365/col("daysBetween"))*col("odoDiff")).alias("AAU_Km")
                            )\
                    .filter(col("daysBetween")>180)\
                    .filter(col("AAU_Hours")>0)

# COMMAND ----------

#tenere solo gli chassis di Cinzia
df_onlyCinziaChassis = df.filter(col("chassis").isin(listaChassis))

# COMMAND ----------

df.count()

# COMMAND ----------

display(df.filter(col("chassis").isin(listaChassis)))

# COMMAND ----------

#save table
df_onlyCinziaChassis.write.mode("overwrite").saveAsTable("reliab.20231127_dailyCngf1c_calcoloAAU_kmEOre_50veicolidalistaCinzia")

# COMMAND ----------

spark.read.table("reliab.20231127_dailyCngf1c_calcoloAAU_kmEOre_50veicolidalistaCinzia").count()

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Aggiunta dell AAU km anche per i diesel

# COMMAND ----------

#trovare la lista di f1C soltanto
from pyspark.sql.functions import col

tableName = "reliab.20230721_DailyD_AAUHours_ListChassisWithEngine"

df = spark.read.table(tableName)

#aggiungere l'odo at end da datacollector
odo_sdf = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
                    .select("chassis", "startofsampling", "odoAtEnd")

df= df.join(odo_sdf, ["chassis", "startofsampling"], "left")

# COMMAND ----------



listaChassisDaEDWH_F1C = (spark.read.table("edwh.vehicle")\
                .filter(col("pvcb_ds_sub_product_cl").like("%DAILY%F1C%DIESEL%"))\
                .filter((col("pvan_ds_preliminary_model_year")=="MY2019")|(col("pvan_ds_preliminary_model_year")=="MY2021")))\
                .select(col("pvan_cd_vin_code").alias("chassis"), col("pvan_id_warranty_start_date").alias("warrStartDate"), col("pvcb_ds_sub_product_cl").alias("modello") )



df = df.join(listaChassisDaEDWH_F1C, "chassis")\
            .filter(col("startOfSampling")>col("warrStartDate"))\
            .filter(col("engineWorkhours").isNotNull())


dfDates = df\
            .groupBy(col("chassis"))\
            .agg(min(col("startOfsampling")).alias("minDate"), max(col("startofSampling")).alias("maxDate"))


df = df.join(dfDates, "chassis")\
        .filter((col("startofsampling")==col("minDate")) | (col("startofsampling")==col("maxDate")))\
        .selectExpr("chassis", "modello", "startofsampling", "engineWorkHours",  "odoAtEnd/1000 as odoAtEnd")

# COMMAND ----------

#dataset con tutte le mission
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, desc,col, collect_list, datediff, pow, abs

dateVariable = "startofsampling"

windowAscend = Window().partitionBy("chassis").orderBy(dateVariable)
windowDescend = Window().partitionBy("chassis").orderBy(desc(dateVariable))

df = df\
                .filter(col("engineWorkHours").isNotNull())\
                            .groupBy("chassis")\
                            .agg(collect_list(col(dateVariable)).alias("dates"), 
                                 collect_list(col("engineWorkHours")).alias("engine"),
                                 collect_list(col("odoAtEnd")).alias("odoAtEnd"))\
                            .select("*", 
                                        abs(datediff(col("dates")[1], col("dates")[0])).alias("daysBetween"),
                                        abs((col("engine")[1]-col("engine")[0])).alias("engineDiff"),
                                        abs((col("odoAtEnd")[1]-col("odoAtEnd")[0])).alias("odoDiff")
                                        )\
                            .select("*", ((365/col("daysBetween"))*col("engineDiff")).alias("AAU_Hours"),
                                          ((365/col("daysBetween"))*col("odoDiff")).alias("AAU_Km"))\
                            .filter(col("daysBetween")>180)\
                            .filter(col("AAU_Hours")>0)
                            

# COMMAND ----------

df.count()

# COMMAND ----------

#tenere solo i bad
bad_df = pd.read_csv("/dbfs/FileStore/tables/reliab/vinBad_RG_DAILY.csv")

bad_list = bad_df["chassis"].to_list()

df = df.filter(col("chassis").isin(bad_list))

# COMMAND ----------

df.count()

# COMMAND ----------

#save table
df.write.mode("overwrite").option("overwriteschema", "true").saveAsTable("reliab.20231127_dailydieselF1c_calcoloAAU_perCinzia")

# COMMAND ----------

