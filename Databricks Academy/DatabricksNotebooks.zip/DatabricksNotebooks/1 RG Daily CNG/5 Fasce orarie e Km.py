# Databricks notebook source
df = spark.read.table("reliab.20230525_rgdailycng_datasuperflatstarting2022")

# COMMAND ----------

from pyspark.sql.functions import date_format
df = df\
        .withColumn('time_start', date_format('startofsampling', 'HH:mm:ss'))\
        .withColumn('time_end', date_format('endofsampling', 'HH:mm:ss'))



# COMMAND ----------

#aggiungere la colonna della fascia oraria
from pyspark.sql.functions import col, when
df = df.withColumn(
    "fascia_oraria" , when((col("time_start")>="06:00:00" )&( col("time_end")<"14:00:00"), "MATTINA")
                      .when((col("time_start")>="14:00:00" )&( col("time_end")<"22:00:00"), "SERA")
                      .when((col("time_start")>="22:00:00" )&( col("time_end")<"6:00:00"), "NOTTE")
                      .otherwise(None)
                    )
                    #.filter(col("fascia_oraria").isNotNull())

# COMMAND ----------

from pyspark.sql.functions import sum
totalDistance = df.select(sum("totalDistance")).collect()[0][0]

# COMMAND ----------

from pyspark.sql.functions import sum

agg_df = df.groupBy("fascia_oraria").agg(sum(col("totalDistance")).alias("distance"))\
                .withColumn("percent", col("distance")/totalDistance)



# COMMAND ----------

display(agg_df)

# COMMAND ----------

