# Databricks notebook source
# MAGIC %md
# MAGIC ## Ricerca Daily con PTO per Raccolta Rifiuti

# COMMAND ----------

import pandas as pd

listaChassis = pd.read_excel("/dbfs/FileStore/tables/reliab/estrazione_opt_72816.xlsx")
                    
listaChassisSpark = spark.createDataFrame(listaChassis)\
                         .withColumnRenamed("Vin Code", "chassis")


spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
                    .join(listaChassisSpark, "chassis")\
                    .select("chassis", "missionid", "startofsampling", "endofsampling")\
                    .createOrReplaceTempView("listaMission")

# COMMAND ----------

#download 
#estrarre percorsi completi
nome = "reliab.20230718_RGDailyCNG_downloadPathRaccoltaRifiuti"

spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
              FROM  listaMission a 
                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
                      ON a.chassis = b.chassis 
                      AND b.startofsampling >= a.startofsampling 
                      AND b.endOfSampling   <= a.endOfSampling """).write.saveAsTable(f"{nome}")


print(f"Table created: {nome}") 

# COMMAND ----------

cluster = spark.read.table("reliab.20230713_rgdailycng_allchassisclusteredwithbothmethods")\
            .join(listaChassisSpark, "chassis")

# COMMAND ----------

display(cluster)

# COMMAND ----------

