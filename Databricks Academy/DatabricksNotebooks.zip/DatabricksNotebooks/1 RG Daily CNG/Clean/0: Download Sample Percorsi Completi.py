# Databricks notebook source
# MAGIC %md
# MAGIC # Download Percorsi Completi

# COMMAND ----------

# MAGIC %md
# MAGIC #### Parametri

# COMMAND ----------

#coordinates columns
latitudeCol = "Latitude"
longitudeCol = "Longitude"

#unique key
uniqueKey = ["chassis", "missionId"]


#!!!!!!!!!!!!!!!!!!!!!!!!!!!!! IMPORTANTE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#input dataset !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
tableWithMissionsToSample = "reliab.20230622_dailycng_missionaggitaly"

#outputDataset
outputTable = "reliab.20230622_dailyCNG_PercorsiItalia"
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


#Quanti percorsi estrarre (sample size)?
NumeroMissionDaEstrarre = 5000



# COMMAND ----------

#settare la variabile per sql
spark.conf.set("downloadCompletePaths.outputTable", outputTable)

print(outputTable)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Initialize Output Dataset

# COMMAND ----------

# MAGIC %sql
# MAGIC -- create output table
# MAGIC CREATE TABLE IF NOT EXISTS ${downloadCompletePaths.outputTable}
# MAGIC (chassis STRING,
# MAGIC  missionId STRING,
# MAGIC  startOfSampling TIMESTAMP,
# MAGIC  endOfSampling TIMESTAMP,
# MAGIC  Timestamp TIMESTAMP,
# MAGIC  Altitude DECIMAL(10,2),
# MAGIC  Latitude DECIMAL(10,5),
# MAGIC  Longitude DECIMAL(10,5))

# COMMAND ----------

#df with list of missions already extracted
dfMissionsAlreadyExtracted = spark.read.table(outputTable)\
                                    .select("chassis", "missionId")\
                                    .distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Antijoin con le mission già estratte

# COMMAND ----------

#dataset dal quale estrarre le mission
dfMissionsToSample = spark.read.table(tableWithMissionsToSample)\
                        .select("chassis", "missionId", 
                                "startofsampling", "endofsampling")\
                        .dropna()

#antijoin con il df delle mission già estratte
dfMissionsToSample = dfMissionsToSample\
                        .join(dfMissionsAlreadyExtracted, 
                                ["chassis", "missionId"], 
                                "leftAnti")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Stratified Sampling (by chassis) 
# MAGIC Same sampling fraction for each chassis

# COMMAND ----------

#creare il df contenente le mission da estrarre per ciascuno chassis (stessa frazione di campionamento per ciascun chassis)
from pyspark.sql.functions import count, col, round, lit, sum

#totale di mission
numMissionTotali = dfMissionsToSample.count()

#frazione per il campionamento
fraction = NumeroMissionDaEstrarre/numMissionTotali

#lista univoca di chassis
listaChassis = [x[0] for x in dfMissionsToSample.select("chassis").distinct().collect()]

#dizionario con chassis e frazione (la stessa per tutti)
dizioFractions = dict(zip(listaChassis, [fraction for x in listaChassis]))

#df con mission selezionate
dfSampled = dfMissionsToSample.sampleBy("chassis", dizioFractions).distinct()\
                .createOrReplaceTempView("listaMission")


print(f"Frazione di campionamento per chassis: {fraction}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Download Complete Paths

# COMMAND ----------

    ##estrarre percorsi completi
    spark.sql("""
              
    MERGE INTO ${downloadCompletePaths.outputTable} AS t

    USING (SELECT 
                a.chassis, 
                a.missionId, 
                b.startOfSampling, 
                b.endOfSampling, b.
                Timestamp, b.Altitude, b.Latitude, b.Longitude
                
                FROM  listaMission a 
                
                LEFT JOIN datacollector.datacollector_gps_tabular_prod b
                      ON a.chassis = b.chassis 
                      AND b.startofsampling >= a.startofsampling 
                      AND b.endOfSampling   <= a.endOfSampling
            ) as i

    ON t.chassis = i.chassis 
        AND t.missionId = i.missionId 
        AND t.timestamp = i.timestamp
                    
    WHEN MATCHED THEN UPDATE SET *    
    WHEN NOT MATCHED THEN INSERT *

    """)

# COMMAND ----------

#percentuale di mission scaricate sul totale delle missiond
scaricate = spark.read.table(outputTable)\
                    .select("chassis", "missionId")\
                    .distinct()\
                    .count()

totali = spark.read.table(tableWithMissionsToSample)\
                    .select("chassis", "missionId")\
                    .distinct()\
                    .count()

print(f"Mission Scaricate: {(scaricate/totali)*100:.2f}%")