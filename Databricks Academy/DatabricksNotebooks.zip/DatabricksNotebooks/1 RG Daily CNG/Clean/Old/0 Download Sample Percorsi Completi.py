# Databricks notebook source
# MAGIC %md
# MAGIC # Download Percorsi Completi - Francia

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "dailyCNG"
notebook = "downloadPercorsiFRANCIA_sample2"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

#dataset con tutte le mission disponibili
from pyspark.sql.functions import col, mean, avg, count

#con mtbf da Cinzia
dfCinzia = spark.read.csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCngTotal.csv", header = "true")\
                .withColumnRenamed("Serial_Number", "chassis")\
                .withColumnRenamed("MTBF_veicolo", "mtbf")\
                .select("chassis", "mtbf")


vehicleFrancia = spark.read.table("edwh.vehicle")\
    .selectExpr("pvan_cd_vin_code as chassis", "makt_ds_country_sdes as market")\
        .join(dfCinzia, "chassis")\
            .withColumn("mtbf", col("mtbf").cast("float"))\
            .filter(col("market")=="France")


#escludere i vin per i quali abbiamo già mission
vinToExclude = spark.read.table("reliab.20230616_dailycng_downloadpercorsifrancia_withstreetinfo_withmissiontype_pivoted1rowpermission").select("chassis", "missionId").distinct()


dataset = "reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh"

spark.read.table(dataset)\
        .filter(col("totalTime")>0)\
        .filter(col("totaldistance")>0)\
        .join(vehicleFrancia, "chassis")\
        .join(vinToExclude, "chassis", "leftanti")\
        .select("chassis", "missionId", "startOfSampling", "endOfSampling")\
        .distinct()\
        .createOrReplaceTempView("listaMission")

# COMMAND ----------

##estrarre percorsi completi
#spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaMission a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startofsampling 
#                      AND b.endOfSampling   <= a.endOfSampling """).write.saveAsTable(f"{nome}")
#

print(f"Table created: {nome}") 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Download Complete Paths

# COMMAND ----------

##estrarre percorsi completi
spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
              FROM  listaMission a 
                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
                      ON a.chassis = b.chassis 
                      AND b.startofsampling >= a.startofsampling 
                      AND b.endOfSampling   <= a.endOfSampling """)\
                        .write\
                        .mode("overWrite")\
                        .saveAsTable(f"{nome}")


print(f"Table created: {nome}") 