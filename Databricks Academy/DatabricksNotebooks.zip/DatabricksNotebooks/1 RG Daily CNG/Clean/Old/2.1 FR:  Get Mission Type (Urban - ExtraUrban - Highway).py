# Databricks notebook source
# MAGIC %md
# MAGIC # Get Mission Type (Urban - Extra - Highway) - French Paths

# COMMAND ----------

# MAGIC %md
# MAGIC #### Parametri

# COMMAND ----------

dataset = "reliab.20230620_dailyCNG_downloadPercorsiFRANCIA_sample2_withStreetInfo"
outputName = f"{dataset}_AggMissionType"

roadCol = "streetInfo.road"

uniqueKey = ["chassis", "missionid", "timestamp"]

latitudeCol = "Latitude"
longitudeCol = "Longitude"

# COMMAND ----------

# MAGIC %md 
# MAGIC ## 1) Extract Road Type for each point 

# COMMAND ----------

#load data
df = spark.read.table(dataset).dropDuplicates(subset=uniqueKey)

df.count()

# COMMAND ----------

from pyspark.sql.functions import col

display(df.sort(col("chassis" ), col("missionId"), col("timestamp")))

# COMMAND ----------

URBAN = ["Domaine",
        "Dépose", "Machilly", "Péristyle", "3e", "Rives", "Parc", "Accès", "Souterrain",
        "Place",
        "Allée",
        "Quai",
        "Sentier",
        "Pont",
        "Carrefour",
        "Esplanade",
        "Résidence",
        "Ruelle",
        "Clos",
        "Rue",
        "Avenue",
        "Boulevard",
        "Promenade",
        "Chemin",
        "Impasse",
        "Galerie",
        "Cours",
        "Mail",
        "Square",
        "Placette",
        "Passage",
        "Rond-Point",
        "Parvis",
        "Porte",
        "Petite",
        "Grande",
        "Voie",
        "Port",
        "Plaine",
        "Vieux",
        "Cité",
        "Hameau",
        "Chaussée",
        "Parinor",
        "Loock",
        "Clairière",
        "Villa",
        "Aire",
        "Aqueduc",
        "Juliane",
        "Montée",
        "Passerelle",
        "Piste",
        "Butte",
        "Portiques",
        "Pont-Aqueduc",
        "Trémie",
        "Liaison",
        "Espace"]

EXTRAURBAN = ["^C\s{1,1}|^C\s{0,1}\d{1,4}",
            "Tunnel",
            "Terrasse",
            "Faubourg",
            "Rocade",              
            "Côte",
            "Route",
            "Sente",
            "Montée",          
            "Chemin",
            "Déviation",
            "Raccordement",
            "Nouvelle",             
            "Petite",           
            "Agriculteurs",          
            "Golfe",
            "Jardin",
            "Lac",
            "Vallon",
            "Champ",
            "Bois",
            "Verger",
            "Forêt",
            "Pavé",
            "Sortie", "Barreau", "Petit", "Giratoire", "Toulouse", "Duplex", "Ancien", "PI24", "Rampe",
            "^D\s{0,1}(?!.*)|^D\s{0,1}\d{1,4}",
            "^M\s{0,1}(?!.*)|^M\s{0,1}\d{1,4}"]

HIGHWAY = [ 
           "77A900415CD_5D", "La", "Viaduc",
           "77A900415CD_5D",
           "Ancienne",
           "Pénétrante",
           "Vallée",
           "Bretelle",
            "Autoroute",
            "A86",
            "R12",
            "Périphérique",
            "E 42",  
            "VI",
            "Boucle",
            "Zone",
            "Interconnexion",
            "Échangeur",
            "L'Européenne",
            "L'Aquitaine",
            "^N\s{0,1}(?!.*)|^N\s{0,1}\d{1,4}",
            "^E\s{0,1}(?!.*)|^E\s{0,1}\d{1,4}",
            "^A\s{0,1}(?!.*)|^A\s{0,1}\d{1,4}"]

#pattern urbano
patternUrb =  ""
for road in URBAN:
    patternUrb += road + "|"
patternUrb = patternUrb[0:-1]

#pattern extraurbano
patternExtraurb =  ""
for road in EXTRAURBAN:
    patternExtraurb += road + "|"
patternExtraurb = patternExtraurb[0:-1]

#pattern highway
patternHighway =  ""
for road in HIGHWAY:
    patternHighway += road + "|"
patternHighway = patternHighway[0:-1]



# COMMAND ----------

print("urban: ", patternUrb + "\n")
print("extraurban: ", patternExtraurb + "\n")
print("highway: ", patternHighway + "\n")

# COMMAND ----------

#Mappare le strade
from pyspark.sql.functions import col, split
import re
import pandas as pd

#### Mappa Strade
def map_streets(road, altitude):
    """mappare le strade"""
    print(type(road))

    if type(road)==str:
        
        road = road.title()

        if re.match(patternHighway, road):
            streetType = "HIGHWAY"
        elif re.match(patternUrb, road):
            streetType = "URBAN"
        elif re.match(patternExtraurb, road):
            streetType = "EXTRAURBAN"
        else:
            streetType = "OTHER"
    else:
        streetType = "NULL"

    #altitudine
    if pd.isnull(altitude) == False:
        try: 
            altitudeFloat = float(altitude)
            if altitudeFloat>=600:
                streetType = "MONTAGNA"
            elif altitudeFloat>=300:
                streetType = "COLLINARE"
        except:
            pass

    return streetType

map_streets_udf = udf(map_streets)


#apply the function 
df = df.withColumn("streetType", map_streets_udf(col(roadCol), col("altitude")))

# COMMAND ----------

display(df\
    .filter(col("StreetType")=="MONTAGNA")\
    .sort(col("chassis" ), col("missionId"), col("timestamp")).limit(1000))

# COMMAND ----------

# MAGIC %md 
# MAGIC ## 2) Add Distance from each point

# COMMAND ----------

#agiungere i lag della posiziome
from pyspark.sql.functions import  lag, coalesce, array
from pyspark.sql.window import  Window

df =  df.withColumn("latLon", array(col(latitudeCol), col(longitudeCol)))\
        .withColumn("lag_latLon", lag('latLon', 1).over(Window.partitionBy("chassis", "missionid").orderBy('timestamp')))\
        .withColumn("lag_latLon", coalesce(col("lag_latlon"), col("latlon")))


#funzione per calcolare la distanze tra due punti
import geopy.distance

def get_distance(lag_latlon, latlon):
    """ Get distance from point to another """
    distance = geopy.distance.geodesic(lag_latlon,latlon).km
    return distance

distance_udf = udf(get_distance)


#applica la funzione
df = df.withColumn("distanceKm", distance_udf(col("lag_latlon"), col("latlon")))


# COMMAND ----------

#aggiungere la velocità media punto per punto
from pyspark.sql.functions import  lag, coalesce, array, sum
from pyspark.sql.window import  Window

df =  df\
        .withColumn("lag_timestamp", lag('timestamp', 1).over(Window.partitionBy('chassis', "missionId").orderBy('timestamp')))\
        .withColumn("lag_timestamp", coalesce(col("lag_timestamp"), col("timestamp")))\
        .withColumn("timeSeconds", col("timestamp").cast("long")-col("lag_timestamp").cast("long"))\
        .withColumn("averageSpeed", col("distanceKm")/(col("timeSeconds")/60**2))


# COMMAND ----------

# MAGIC %md 
# MAGIC ## 3) Add Slope

# COMMAND ----------

#aggiungere la pendenza media punto per punto
from pyspark.sql.functions import  lag, coalesce, array, sum, abs
from pyspark.sql.window import  Window

df =  df\
        .withColumn("lag_altitude", lag('altitude', 1).over(Window.partitionBy('chassis', "missionId").orderBy('timestamp')))\
        .withColumn("lag_altitude", coalesce(col("lag_altitude"), col("altitude")))\
        .withColumn("deltaAltitude", (col("altitude").cast("long")-col("lag_altitude").cast("long"))*1E-3)\
        .withColumn("slope", col("deltaAltitude")/col("distanceKm"))


# COMMAND ----------

#save output
df.write\
   .mode("overwrite")\
   .option("overwriteSchema", "true")\
   .saveAsTable(f"{dataset}_withMissionType")

print(f"{dataset}_withMissionType")

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE reliab.20230620_dailyCNG_downloadPercorsiFRANCIA_sample2_withStreetInfo_withMissionType

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verificare che la classificazione sia corretta

# COMMAND ----------

from pyspark.sql.functions import col, mean

provaClass = df.withColumn("firstWord", split(col("streetInfo.road"), " ")[0])\
                .withColumn("avgSpeed", col("distanceKm")/(col("timeSeconds")/(60**2)))\
                    .groupBy("firstWord", "streetType")\
                    .agg(mean(col("avgSpeed")).alias("avgSpeed"))\
                    .select("firstWord", "streetType", "avgSpeed")

# COMMAND ----------

display(provaClass.sort("streetType", "avgSpeed")\
                .filter(col("streetType")=="OTHER"))