# Databricks notebook source
# MAGIC %md
# MAGIC # Get Mission Type (Urban - Extra - Highway)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Parametri

# COMMAND ----------

dataset = "reliab.20230622_dailyCNG_PercorsiItalia_withStreetInfo"
outputName = f"{dataset}_AggMissionType"

roadCol = "streetInfo.road"

uniqueKey = ["chassis", "missionid", "timestamp"]

latitudeCol = "Latitude"
longitudeCol = "Longitude"

# COMMAND ----------

# MAGIC %md 
# MAGIC ## 1) Extract Road Type for each point 

# COMMAND ----------

#load data
df = spark.read.table(dataset).dropDuplicates(subset=uniqueKey)

df.count()

# COMMAND ----------

#Mappare le strade
from pyspark.sql.functions import col, split
import re

#### Mappa Strade
def map_streets(road):
    """mappare le strade"""
    print(type(road))

    #patternHigh
    patternHigh = r"(^A\d{1,3}\s{0,1}$|^Autostrad|^Svincolo Autostradale|^Tangenziale|^Diramazione|^Raccordo|^Asse)"
                
    #extraurban
    patternExtra = r"^Strada Provinciale|^Strada Regionale|^Strada Statale|^Sp\s{0,1}\d{1,45}|^Sr\s{0,1}\d{1,5}|^Ss\s{0,1}\d{1,45}|^Variante|^Sentiero"
        
    #patternUrban 
    patternUrban = r"(Ex\s){0,1}Via|^Piazz|^Corso|^Strada (?!Provinciale|Regionale|Statale)|^Rotatoria|^Largo|^Vicolo|Svincolo|^Rotonda|^Foro|^Ponte|^Lungomare|^Vico|^Cavalcavia|^Lungo"

    if type(road)==str:
        
        road = road.title()

        if re.match(patternHigh, road):
            streetType = "HIGHWAY"
        elif re.match(patternUrban, road):
            streetType = "URBAN"
        elif re.match(patternExtra, road):
            streetType = "EXTRAURBAN"
        else:
            streetType = "OTHER"
    else:
        streetType = "NULL"

    return streetType

map_streets_udf = udf(map_streets)



#apply the function 
df = df.withColumn("streetType", map_streets_udf(col(roadCol)))

# COMMAND ----------

# MAGIC %md 
# MAGIC ## 2) Add Distance from each point

# COMMAND ----------

#agiungere i lag della posiziome
from pyspark.sql.functions import  lag, coalesce, array
from pyspark.sql.window import  Window

df =  df.withColumn("latLon", array(col(latitudeCol), col(longitudeCol)))\
        .withColumn("lag_latLon", lag('latLon', 1).over(Window.partitionBy("chassis", "missionid").orderBy('timestamp')))\
        .withColumn("lag_latLon", coalesce(col("lag_latlon"), col("latlon")))


#funzione per calcolare la distanze tra due punti
import geopy.distance

def get_distance(lag_latlon, latlon):
    """ Get distance from point to another """
    distance = geopy.distance.geodesic(lag_latlon,latlon).km
    return distance

distance_udf = udf(get_distance)


#applica la funzione
df = df.withColumn("distanceKm", distance_udf(col("lag_latlon"), col("latlon")))


# COMMAND ----------

#aggiungere la velocità media punto per punto
from pyspark.sql.functions import  lag, coalesce, array, sum
from pyspark.sql.window import  Window

df =  df\
        .withColumn("lag_timestamp", lag('timestamp', 1).over(Window.partitionBy('chassis', "missionId").orderBy('timestamp')))\
        .withColumn("lag_timestamp", coalesce(col("lag_timestamp"), col("timestamp")))\
        .withColumn("timeSeconds", col("timestamp").cast("long")-col("lag_timestamp").cast("long"))\
        .withColumn("averageSpeed", col("distanceKm")/(col("timeSeconds")/60**2))


# COMMAND ----------

#save output
df.write.saveAsTable(f"{dataset}_withMissionType")

print(f"{dataset}_withMissionType")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3) Mission Aggregate (1 riga per mission) 

# COMMAND ----------

from pyspark.sql.functions import first, when, col, sum

missionDf = df\
        .groupBy("chassis", "missionId", "streetType")\
        .agg(sum(col("distanceKm")).alias("distanceKm"))\
        .groupBy("chassis", "missionId")\
        .pivot("streetType")\
        .agg(first("distanceKm"))\
        .na.fill(0)\
        .withColumn("missionType" , when(
                                    (col("HIGHWAY")>col("EXTRAURBAN"))
                                   &(col("HIGHWAY")>col("URBAN")     ), "HIGHWAY"
                                        )
                    
                                    .when(
                                     (col("EXTRAURBAN")>col("HIGHWAY"))
                                    &(col("EXTRAURBAN")>col("URBAN")  ), "EXTRAURBAN"
                                        )
                                    
                                    .when(
                                     (col("URBAN")>col("HIGHWAY"))
                                    &(col("URBAN")>col("EXTRAURBAN")), "URBAN"
                                        )
                                    
                                    .when(col("OTHER")>col("NULL"), "OTHER")
                                    .otherwise("NULL")
                                    )\
        .drop("HIGHWAY", "URBAN", "EXTRAURBAN", "OTHER", "NULL")
    


# COMMAND ----------

#salvare il file
missionDf.write\
    .saveAsTable(f"{outputName}")

print(outputName)

# COMMAND ----------

outputName

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from reliab.20230622_dailyCNG_PercorsiItalia_withStreetInfo_withmissiontype

# COMMAND ----------

