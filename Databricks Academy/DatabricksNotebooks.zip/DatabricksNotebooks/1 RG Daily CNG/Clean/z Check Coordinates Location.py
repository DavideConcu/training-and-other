# Databricks notebook source
# MAGIC %md
# MAGIC ## Check if Point inside Piedmont

# COMMAND ----------

pip install shapely

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "RGDailyCNG"
notebook = "checkIfInPiemonte"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

from pyspark.sql.functions import array, col

#load input data 
df = spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
    .select("chassis", "missionId", "lat_start", "lon_start")

#to array
longitudeColumn = "lon_start"
latitudeColumn = "lat_start"

df = df.withColumn("lonLat", array(col(longitudeColumn), col(latitudeColumn)))

# COMMAND ----------

import json
from pyspark.sql.functions import pandas_udf
from shapely.geometry import shape, GeometryCollection, Point

with open("/dbfs/FileStore/tables/reliab/ConfiniPiemonte.geojson", 'r') as f:
    js = json.load(f)

#funzione da applicare alle righe
def checkIfInsidePolygon(lonLat):
    """ check if coordinate is inside polygon """
    result = False

    point = Point(lonLat)

    for feature in js['features']:
        polygon = shape(feature['geometry'])

        if polygon.contains(point):
            result = True

    return result

checkIfInsidePolygonUdf = udf(checkIfInsidePolygon)

# COMMAND ----------

#apply function
df = df.withColumn("isInPiedmont", checkIfInsidePolygonUdf(col("lonLat")).cast("boolean"))

# COMMAND ----------

##save dataset OK!
# #df.write\
#    .mode("overwrite")\
#    .option("overwriteSchema", "true")\
#    .saveAsTable(f"{nome}")
#    
#
#print(nome)

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC from reliab.20230531_RGDailyCNG_checkIfInPiemonte
# MAGIC where isInPiedmont = true

# COMMAND ----------

