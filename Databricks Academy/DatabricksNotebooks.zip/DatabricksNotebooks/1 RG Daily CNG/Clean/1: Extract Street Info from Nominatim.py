# Databricks notebook source
# MAGIC %md 
# MAGIC # Extract Street Info for complete Paths

# COMMAND ----------

# MAGIC %md
# MAGIC #### Parametri

# COMMAND ----------

#coordinates columns
latitudeCol = "Latitude"
longitudeCol = "Longitude"

#unique key
uniqueKey = ["chassis", "missionId", "Timestamp"]

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!! IMPORTANTE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#input dataset !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
inputDataset = "reliab.20230622_dailyCNG_PercorsiItalia"

#outputDataset
outputDataset = "reliab.20230622_dailyCNG_PercorsiItalia_withStreetInfo"
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


spark.conf.set("streetInfo.outputDataset", outputDataset)

print(outputDataset)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Initialize Output Dataset

# COMMAND ----------

# MAGIC %sql
# MAGIC -- create output table
# MAGIC CREATE TABLE IF NOT EXISTS ${streetInfo.outputDataset}
# MAGIC (chassis STRING,
# MAGIC  missionId STRING,
# MAGIC  startOfSampling TIMESTAMP,
# MAGIC  endOfSampling TIMESTAMP,
# MAGIC  Timestamp TIMESTAMP,
# MAGIC  Altitude DECIMAL(10,2),
# MAGIC  Latitude DECIMAL(10,5),
# MAGIC  Longitude DECIMAL(10,5),
# MAGIC  streetInfo MAP<STRING, STRING>)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Extract Info

# COMMAND ----------

import pandas as pd
import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#funzioni per estrarre le info
import random, string

def randomword():
    """ Crea parola random """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(5))

def initialize_service():
    """ Inizializza il servizio di Nominatim """
    locator = Nominatim(user_agent=f"iveCoder{randomword}", timeout=60)
    reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)
    return locator, reverseGeocode
    

def extractInfo(row):
    request = locator.reverse([row[latitudeCol], row[longitudeCol]])
    try:
        info = request.raw["address"]
    except:
        info = None
    return info


# COMMAND ----------

# MAGIC %md
# MAGIC #### Loop

# COMMAND ----------

def loadDatasets():
    #load target table to pandas
    dfTarget = spark.read.table(outputDataset)\
                .dropDuplicates(subset=uniqueKey).toPandas()

    rowsInTargetDf = len(dfTarget)
    print("Righe in target df: ", rowsInTargetDf)

    #load input dataset 
    dfInput = spark.read.table(inputDataset)\
                .select("chassis", "missionId", "startOfSampling", "endOfSampling", "Timestamp", "Altitude", "Latitude", "Longitude")\
                .dropna(subset=uniqueKey)\
                .dropDuplicates(subset=uniqueKey)\
                .toPandas()


    rowsInInputDf = len(dfInput)
    print("Righe in input df: ", rowsInInputDf)

    #righe da scaricare
    righeMancanti = rowsInInputDf - rowsInTargetDf
    print("Righe mancanti: " , righeMancanti)

    #merge con il target df
    sourceDf = pd.merge(dfTarget.loc[:, uniqueKey], 
                        dfInput, on = uniqueKey, how="right", indicator=True)
    #keep solo se non presente in target
    sourceDf = sourceDf.loc[sourceDf._merge=="right_only", :].drop("_merge", axis=1).reset_index(drop=True)

    print("Len sourceDf: ", len(sourceDf))

    return dfTarget, sourceDf


#insert target dataframe
def updateTargetOld():
    spark.sql("""
    INSERT INTO ${streetInfo.outputDataset}
    (SELECT * FROM target)  
    WHERE NOT EXISTS (SELECT s.chassis, s.missionId, s.timestamp  
                      FROM ${streetInfo.outputDataset} as s
                      WHERE s.chassis = t.chassis AND s.missionId = t.missionId AND s.timestamp = t.timestamp)
    """)
    print("TARGET TABLE UPDATED\n")


#merge into dataframe
def updateTarget():
    spark.sql("""
    MERGE INTO ${streetInfo.outputDataset} AS t
    USING target as i
    ON t.chassis = i.chassis AND t.missionId = i.missionId AND t.timestamp = i.timestamp
    WHEN MATCHED THEN UPDATE SET *    
    WHEN NOT MATCHED THEN INSERT *

    """)
    print("TARGET TABLE UPDATED\n")

# COMMAND ----------

import time

batchToDownload = 5000

#schema finale
schema = spark.read.table(inputDataset).schema.simpleString()[:-1] + ",streetInfo:map<string,string>>"

#load datasets
dfTarget, sourceDf = loadDatasets()

#inizializzare il servizio
locator, reverseGeocode = initialize_service()

errors = 0
rowsDownloaded = 0

#starting time
timeStart = time.time()
maxTime = 5*(60**2)

#loop lunghezza df 
running = True
while running:

    #loop per righe
    for i in range(len(sourceDf)):

        try: 
            print(i)
            riga = sourceDf.loc[i:i, :].copy()
            #extract info
            riga["streetInfo"] = riga.apply(lambda row: extractInfo(row), axis = 1)

            #append to targetDf
            dfTarget = pd.concat([dfTarget, riga]).reset_index(drop=True)

            #re-initialize
            errors = 0
            rowsDownloaded +=1

            if rowsDownloaded >= batchToDownload and len(dfTarget)>0:
                print(f"DOWNLOADED {batchToDownload} ROWS - updating target table.")
                #esce dal for loop
                break

        except:
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            print("!!!!!!!!!!!!ERROR!!!!!!!!!!!!!!")
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n")

            if len(dfTarget)>0:
                #crea il df come spark df
                targetDfSpark = spark.createDataFrame(dfTarget , schema).createOrReplaceTempView("target")
                #insert into table
                updateTarget()

            #ricarico i df target e source
            dfTarget, sourceDf = loadDatasets()

            #re-inizializzare il servizio
            locator, reverseGeocode = initialize_service()

            errors +=1 
            if errors >= 5:
                raise


    ################ QUANDO ESCE DAL FOR LOOP (perchè ha scaricato le tot righe OPPURE i fuori dal range): 
    #crea df spark
    targetDfSpark = spark.createDataFrame(dfTarget , schema).createOrReplaceTempView("target")
    
    #insert into table
    updateTarget()

    #ricaricare i dataset 
    dfTarget, sourceDf = loadDatasets()

    print(f"Target updated with {batchToDownload} rows.\nRows in target: {len(dfTarget)}.\nRows in source: {len(sourceDf)}.\n")
    rowsDownloaded = 0
    ########################################################################################


    #fa uscire dal while loop se ha finito le righe da scaricare
    if len(sourceDf)==0:
        running = False
        print("+++++++++++++ ALL ROWS DOWNLOADED ++++++++++++++")

    #fa uscire dal while loop se supera il tempo limite
    timeNow = time.time()
    if (timeNow-timeStart)>maxTime:
        running= False
        print("-------------- TIME EXCEEDED ---------------")



# COMMAND ----------

# MAGIC %sql
# MAGIC -- optimize the table
# MAGIC OPTIMIZE ${streetInfo.outputDataset}

# COMMAND ----------

