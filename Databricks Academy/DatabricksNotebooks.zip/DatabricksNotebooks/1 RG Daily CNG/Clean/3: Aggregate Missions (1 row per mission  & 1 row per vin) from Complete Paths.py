# Databricks notebook source
# MAGIC %md
# MAGIC # Aggregare le mission a partire dai percorsi completi 
# MAGIC 1 riga per mission, con percentuali di street type e variabili di altitudine 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Parametri

# COMMAND ----------

#input dataset 
#dataset = "reliab.20230622_dailyCNG_PercorsiItalia_withStreetInfo_withMissionType"
dataset = "reliab.20230620_dailycng_downloadpercorsifrancia_sample2_withstreetinfo_withmissiontype"

#output dataset
#outputDataset = dataset + "_PIVOTED1rowPermIssion"
#print(outputDataset)


# COMMAND ----------

#settare la variabile per sql
#spark.conf.set("aggMissions.outputDatasetName", outputDataset)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregare le mission (1 row per mission)

# COMMAND ----------

#df con le variabili aggregate per mission
from pyspark.sql.functions import col, sum, min, max, mean, abs

df = spark.read.table(dataset)

dfAggMission = df.select("chassis", "Missionid", "distanceKm", "timeSeconds", "altitude", "slope")\
                        .groupBy("chassis", "missionid")\
                        .agg(
                            sum(col("distanceKm")).alias("totalDistanceKm"), 
                            sum(col("timeSeconds")).alias("totalTimeSeconds"),

                            min(col("altitude")).alias("minAltitude"),
                            mean(col("altitude")).alias("meanAltitude"), 
                            max(col("altitude")).alias("maxAltitude"),

                            min(abs(col("slope"))).alias("minSlope"),
                            mean(abs(col("slope"))).alias("meanSlope"),
                            max(abs(col("slope"))).alias("maxSlope")
                            )\
                        .withColumn("totalTimeHours", col("totalTimeSeconds")/(60**2))\
                        .withColumn("avgSpeedMission", col("totalDistanceKm") / col("totalTimeHours"))\
                        .select("chassis", "missionId", "totalDistanceKm","meanAltitude", "meanSlope" ,"totalTimeHours", "avgSpeedMission")\
                        .filter(col("totaltimeHours")<=9)\
                        .filter(col("totalDistanceKm")>0)

                        
display(dfAggMission)

# COMMAND ----------

from pyspark.sql.functions import first, when, col, sum, max, min, mean, count

pivotedDf = df\
        .groupBy("chassis", "missionId", "streetType")\
        .agg(sum(col("distanceKm")).alias("distanceKm"), 
             min(col("altitude").alias("minAlitude")))\
        .groupBy("chassis", "missionId")\
        .pivot("streetType")\
        .agg(first("distanceKm"))\
        .na.fill(0)\
        .join(dfAggMission, ["chassis", "missionId"])\
        .withColumn("Extraurban", col("extraurban")/col("totaldistanceKm"))\
        .withColumn("Urban", col("Urban")/col("totaldistanceKm"))\
        .withColumn("Highway", col("Highway")/col("totaldistanceKm"))\
        .withColumn("Montagna", col("Montagna")/col("totaldistanceKm"))\
        .withColumn("Collinare", col("Collinare")/col("totaldistanceKm"))\
        .select("chassis", "missionid", "totalDistanceKm", "totalTimeHours","avgSpeedMission","meanAltitude", "meanSlope", "Extraurban", "Urban", "Highway", "Montagna", "Collinare")\
        .filter((col("extraurban") + col("urban")+ col("highway") + col("montagna")+col("collinare"))>0)


display(pivotedDf.limit(5))
    


# COMMAND ----------

#salvare 
#pivotedDf.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(outputDataset)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregare PER VIN (1 riga per vin)

# COMMAND ----------

dfAggVin = pivotedDf\
                .withColumn("extra", col("extraurban")*col("totalDistanceKm"))\
                .withColumn("high", col("highway")*col("totalDistanceKm"))\
                .withColumn("urban", col("urban")*col("totalDistanceKm"))\
                .withColumn("montagna", col("montagna")*col("totalDistanceKm"))\
                .withColumn("collinare", col("collinare")*col("totalDistanceKm"))\
                .groupBy("chassis").agg(
                    sum("totalDistanceKm").alias("sumtotalDistanceKm"),
                    sum("extra").alias("extra"),
                    sum("high").alias("high"),
                    sum("urban").alias("urban"),
                    sum("montagna").alias("montagna"),
                    sum("collinare").alias("collinare"),
                    count("*").alias("nMissions")
                    )\
                .withColumn("Urban", col("urban")/col("sumtotalDistanceKm"))\
                .withColumn("Extraurban", col("extra")/col("sumtotalDistanceKm"))\
                .withColumn("Highway", col("high")/col("sumtotalDistanceKm"))\
                .withColumn("Montagna", col("montagna")/col("sumtotalDistanceKm"))\
                .withColumn("Collinare", col("collinare")/col("sumtotalDistanceKm"))\
                .select("chassis","nMissions", "Urban", "Extraurban", "Highway", "Collinare", "Montagna")
  

# COMMAND ----------

display(dfAggVin)

# COMMAND ----------

#aggiungere l'mtbf 
dfCinzia = spark.read.csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCngTotal.csv", header = "true")\
                .withColumnRenamed("Serial_Number", "chassis")\
                .withColumn("mtbf" , col("MTBF_veicolo").cast("float"))\
                .select("chassis", "mtbf")

dfAggVin = dfAggVin.join(dfCinzia, "chassis", "left")   


display(dfAggVin.limit(3))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Clustering (6 cluster - 1 per rg)

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

df =  dfAggVin.toPandas()
df = df.loc[df.nMissions>=round(df.nMissions.quantile(0.2)),:]


numCols = ["Urban", "Extraurban" , "Highway"]

#elbow rule overall PRE
X = df.loc[:, numCols].to_numpy()
scalers = StandardScaler()
X_std = scalers.fit_transform(X)
X_std.shape

kmeans_kwargs = {
"init": "random",
"n_init": 100,
    "max_iter": 10000,
    "random_state": 1
}

NUMEROCLUSTERS = 6

#fit e risultato del clustering
kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
kmeans.fit(X_std)
predicted_kmeans = kmeans.predict(X_std)

#calcolo distanza dal centroide
distance = []
for point in range(len(X_std)):
    clus = predicted_kmeans[point]
    distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

#attaccare label
df.loc[:, "cluster"] = predicted_kmeans.astype(int)
df.loc[:, "distance"] = distance

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregare per CLUSTER

# COMMAND ----------

import pandas as pd
import numpy as np

#inizializzare il df
nVins = df.groupby("cluster").distance.count()
dfClus = df.groupby("cluster").agg({"nMissions":np.sum, "mtbf":np.average})
dfClus["nVehicles"] = nVins

#media pesata per ogni vin
for mission in ["Urban", "Extraurban" , "Highway", "Collinare", "Montagna"]:
    dfMission = df.groupby("cluster")\
                    .apply(lambda x: np.average(x[mission], weights = x["mtbf"]))
    dfMission.name = mission

    dfClus = dfClus.merge(dfMission, left_index=True, right_index=True)

# COMMAND ----------

dfClus

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check del cluster 2

# COMMAND ----------

df.loc[df.cluster==2]

# COMMAND ----------

display(pivotedDf.filter(col("chassis")=="ZCFCN35A605305452"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## PLOTTARE MISSION MONTAGNA

# COMMAND ----------

