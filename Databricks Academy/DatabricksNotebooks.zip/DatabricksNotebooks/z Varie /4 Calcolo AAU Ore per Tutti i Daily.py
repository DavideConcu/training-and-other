# Databricks notebook source
# MAGIC %md
# MAGIC ### Lista dei Veicoli Leggeri

# COMMAND ----------

from pyspark.sql.functions import col

#veicoli
lista_daily = spark.read.table("edwh.vehicle")\
                        .selectExpr("pvan_cd_vin_code as chassis",
                                    "pvcb_ds_sub_product_cl as product_descr",
                                    "pvan_ds_preliminary_model_year as model_year",
                                    "pvan_id_warranty_start_date as warr_startdate")\
                        .filter(col("product_descr").like("%DAILY%"))

# COMMAND ----------

#dati da datacollector
dati_collector = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")

#join con i veicoli
df = lista_daily.join(dati_collector, "chassis")\
                        .filter(col("startofsampling")>col("warr_startdate"))


# COMMAND ----------

from pyspark.sql.functions import min, max

first_and_last_acquisition =   df\
                                   .groupBy(col("chassis"))\
                                   .agg(min(col("endofsampling")).alias("minDate"), max(col("endofsampling")).alias("maxDate"))

df_filtered = df.join(first_and_last_acquisition, "chassis")\
        .filter((col("endofsampling")==col("minDate")) | (col("endofsampling")==col("maxDate")))\
        .selectExpr("chassis",  "startofsampling", "engineWorkHours",  "odoAtEnd/1000 as odoAtEnd")\
        .orderBy("chassis", "startofsampling")

# COMMAND ----------

#dataset con tutte le mission

from pyspark.sql.functions import row_number, desc,col, collect_list, datediff, pow, abs

dateVariable = "startofsampling"

df_1rowPerVin = df_filtered\
                    .groupBy("chassis")\
                    .agg(collect_list(col(dateVariable)).alias("dates"), 
                            collect_list(col("engineWorkHours")).alias("engine"),
                            collect_list(col("odoAtEnd")).alias("odoAtEnd"))\
                    .select("*", 
                                abs(datediff(col("dates")[1], col("dates")[0])).alias("daysBetween"),
                                abs((col("engine")[1]-col("engine")[0])).alias("engineDiff"),
                                abs((col("odoAtEnd")[1]-col("odoAtEnd")[0])).alias("odoDiff")
                                )\
                    .select("*", ((365/col("daysBetween"))*col("engineDiff")).alias("AAU_Hours"),
                                    ((365/col("daysBetween"))*col("odoDiff")).alias("AAU_Km"))\
                    .filter(col("daysBetween")>0)\
                    .filter(col("AAU_Hours").isNotNull())\
                    .filter(col("AAU_Km").isNotNull())
                    
                    #.filter(col("AAU_Hours")>0)
                            

# COMMAND ----------

#join di nuovo con i dati di edwh
df_1rowPerVin_final = lista_daily.join(df_1rowPerVin, "chassis")

# COMMAND ----------

#save to catalog
save = False

if save == True:
    df_1rowPerVin_final.write.mode("overwrite")\
        .option("overwriteschema", "true")\
        .saveAsTable("reliab.20240306_Vari_AAUore_allLight")

# COMMAND ----------

results = spark.read.table("reliab.20240306_Vari_AAUore_allLight")

# COMMAND ----------

from pyspark.sql.functions import mean

display(results.filter(col("daysBetween")>360).select(mean("AAU_km")))

# COMMAND ----------

display(results)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Medie separate per modello
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT product_descr as product, 
# MAGIC                         mean(daysbetween) as mean_days_from_start_warranty, 
# MAGIC                         mean(AAU_Km) as mean_AAU_km, 
# MAGIC                         mean(AAU_hours) as mean_AAU_hours
# MAGIC FROM reliab.20240306_Vari_AAUore_allLight
# MAGIC GROUP BY product_descr

# COMMAND ----------

