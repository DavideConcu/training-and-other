# Databricks notebook source
import pandas as pd

df_chassis = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/lista_chassis_sway_Enrica.xlsx")

sdf_chassis = spark.createDataFrame(df_chassis).distinct()

# COMMAND ----------

sdf_chassis.count()

# COMMAND ----------

#join with vehicles in datacollector

sdf_vehicles_datacollector = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_super_flat_prod")\
                                        .select("chassis").distinct()\
                                        .join(sdf_chassis, "chassis")

# COMMAND ----------

display(sdf_vehicles_datacollector)

# COMMAND ----------

