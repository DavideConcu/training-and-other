# Databricks notebook source
# Provide the correct file path
file_path = "/FileStore/tables/reliab/Progetti Vari/nox.csv"

# Read the CSV file using Spark and create a Spark DataFrame
chassis_list_sdf = spark.read.format("csv").option("header", "true").load(file_path).select("chassis").distinct()

vehicles = spark.read.table("edwh.vehicle")\
                        .selectExpr("pvan_cd_vin_code as chassis",
                                    "makt_ds_country_sdes as market",
                                    "pvcb_ds_sub_product_cl as product",
                                    "pvan_id_warranty_start_date as warranty_startdate")
                        
chassis_nox_sdf = chassis_list_sdf.join(vehicles, "chassis")         

# COMMAND ----------

#numero di chassis
chassis_nox_sdf.select("chassis").distinct().count()

# COMMAND ----------

from pyspark.sql.functions import col

#datacollector data
dati_collector = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")

#join con la lista dei nox
chassis_nox_alldata_sdf = chassis_nox_sdf.join(dati_collector, "chassis")\
                                    .filter(col("startofsampling")>col("warranty_startdate"))

# COMMAND ----------

#save table to catalog
save = False
if save:
    chassis_nox_alldata_sdf.write.saveAsTable("reliab.20240308_Vari_NOXissueLight")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Read Results
# MAGIC SELECT * 
# MAGIC FROM reliab.20240308_Vari_NOXissueLight
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Read Results
# MAGIC SELECT count(DISTINCT chassis)
# MAGIC FROM reliab.20240308_Vari_NOXissueLight
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Read Results
# MAGIC SELECT market, chassis, count(DISTINCT missionId)
# MAGIC FROM reliab.20240308_Vari_NOXissueLight
# MAGIC GROUP BY market, chassis
# MAGIC ORDER BY market

# COMMAND ----------

