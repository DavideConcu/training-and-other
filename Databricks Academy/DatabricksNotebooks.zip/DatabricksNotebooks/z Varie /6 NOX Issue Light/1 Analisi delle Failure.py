# Databricks notebook source
import pandas as pd 

#load file
file = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/nox_light.xlsx")


# COMMAND ----------

file

# COMMAND ----------

#dizionario con chassis e relative failures
failures_dictionary = file.groupby("chassis")["Failure_Date"].apply(lambda x: [date.date() for date in x]).to_dict()

#broadcast the dictionary
broadcast_variable = spark.sparkContext.broadcast(failures_dictionary)

# COMMAND ----------

failures_dictionary

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extracted Data from datacollector

# COMMAND ----------

from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import BooleanType

@pandas_udf(BooleanType())
def flag_failure_date(chassis: pd.Series, date: pd.Series) -> pd.Series:
    '''Function for flagging the date if a failure occurred that day'''
    # Access the broadcasted dictionary
    broadcasted_dict = broadcast_variable.value

    # Create a DataFrame from chassis and date
    df = pd.DataFrame({'chassis': chassis, 'date': date})

    # Define a function to check if the date is in the list for each chassis
    def check_date(row):
        chassis_id = row['chassis']
        date_value = row['date']
        return date_value in broadcasted_dict.get(chassis_id, [])

    # Apply the function to each row and return a Series of flags
    return df.apply(check_date, axis=1)


# COMMAND ----------

from pyspark.sql.functions import col, to_date

#load data from datacollector
sdf = spark.read.table("reliab.20240308_Vari_NOXissueLight")

#aggiungere la colonna date
sdf = sdf.withColumn("date", to_date(col("startofsampling")))

# COMMAND ----------

#sdf = sdf.withColumn("failure_date_flag", flag_failure_date(col("chassis"), col("date")))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Altro Modo

# COMMAND ----------

from pyspark.sql.functions import col, explode,lit, when

#dizionario con chassis e relative failures
failures_dictionary = file.groupby("chassis")["Failure_Date"].apply(lambda x: [date.date() for date in x]).to_dict()

#broadcast the dictionary
failures_dictionary_sdf = spark.createDataFrame([(chassis, date) for chassis, dates in failures_dictionary.items() for date in dates],
                                         ["chassis", "date"])\
                                             .withColumn("_failure_date_bool", lit(True))

#join con le failures
sdf = sdf.join(failures_dictionary_sdf, ["chassis", "date"], "outer")


#flaggare le date di non failure mancanti 
sdf = sdf.withColumn("failure_date_flag" , when(col("_failure_date_bool")==True, True).otherwise(False))\
                                .drop(col("_failure_date_bool"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolare i giorni dalla failure e i giorni alla failure
# MAGIC days_since_last_failure e days_to_next_failure

# COMMAND ----------

#dataframe con le date non ripetute
sdf_dates = sdf.select("chassis", "date", "failure_date_flag").distinct().sort(["chassis", "date"])

# COMMAND ----------

from pyspark.sql.functions import row_number
from pyspark.sql.window import Window

#calcolare i giorni alla failure
window_days_to_failure = Window.partitionBy(["chassis", "failure_date_flag"]).orderBy(col("chassis"), col("date").desc())
window_days_since_failure = Window.partitionBy(["chassis", "failure_date_flag"]).orderBy(col("chassis"), col("date"))


sdf_dates = sdf_dates.withColumn("days_to_failure", row_number().over(window_days_to_failure))\
                     .withColumn("days_since_failure", row_number().over(window_days_since_failure))



# COMMAND ----------

display(sdf_dates.sort("chassis", "date"))

# COMMAND ----------

## numerare i giorni precedenti alla failure
from pyspark.sql import Window
from pyspark.sql.functions import col, lag, when, sum

# Assuming sdf is your DataFrame

# Define a window specification to order rows by date
window_spec = Window.partitionBy(["chassis", "failure_date_flag"]).orderBy("startofsampling")

# Use lag function to mark the rows preceding the "true" values in the date column
sdf = sdf.withColumn("precedes_true", lag(when(col("failure_date_flag") == False, 1).otherwise(0)).over(window_spec))

# COMMAND ----------

display(sdf.sort(["chassis", "startofsampling"]))

# COMMAND ----------

## numerare i giorni precedenti alla failure
from pyspark.sql import Window
from pyspark.sql.functions import col, lag, when, sum

# Define a window specification to partition by the "precedes_true" column and order by date
window_spec_partitioned = Window.partitionBy("precedes_true").orderBy("date")

# Use the sum function to assign row numbers to the marked rows
sdf = sdf.withColumn("row_number", sum(when(col("precedes_true") == 1, 1).otherwise(0)).over(window_spec_partitioned))

# Filter the rows where row_number <= 100
sdf = sdf.filter(col("row_number") <= 100)

# COMMAND ----------

