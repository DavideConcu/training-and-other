# Databricks notebook source
# MAGIC %md
# MAGIC # Overview of Llama 2 models in Databricks Marketplace Listing
# MAGIC
# MAGIC The Llama 2 models offered in Databricks Marketplace are text generation models released by Meta AI. They are [MLflow](https://mlflow.org/docs/latest/index.html) models that packages
# MAGIC [Hugging Face’s implementation for the Llama 2 - Chat models](https://huggingface.co/meta-llama)
# MAGIC using the [transformers](https://mlflow.org/docs/latest/models.html#transformers-transformers-experimental)
# MAGIC flavor in MLflow.
# MAGIC
# MAGIC **Input:** string containing the text of instructions
# MAGIC
# MAGIC **Output:** string containing the generated response text
# MAGIC
# MAGIC For example notebooks of using the Llama 2 model in various use cases on Databricks, please refer to [the Databricks ML example repository](https://github.com/databricks/databricks-ml-examples/tree/master/llm-models/llamav2).

# COMMAND ----------

# MAGIC %md ## llama_2_7b_chat_hf
# MAGIC
# MAGIC It packages [Hugging Face’s implementation for the Llama-2-7b-chat-hf model](https://huggingface.co/meta-llama/Llama-2-7b-chat-hf). It has 7 billion parameters, making it the smallest model within the Llama 2 model family. While it offers the fastest processing speed, it may have lower quality compared to other Llama 2 - Chat models.

# COMMAND ----------

# MAGIC %md ## llama_2_13b_chat_hf
# MAGIC It packages [Hugging Face’s implementation for the Llama-2-13b-chat-hf model](https://huggingface.co/meta-llama/Llama-2-13b-chat-hf). It has 13 billion parameters, offering a middle ground on speed and quality compared to other Llama 2 - Chat models.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## llama_2_70b_chat_hf
# MAGIC
# MAGIC It packages
# MAGIC [Hugging Face’s implementation for the Llama-2-70b-chat-hf model](https://huggingface.co/meta-llama/Llama-2-70b-chat-hf).
# MAGIC With a massive 70 billion parameters, this model excels in quality among Llama 2 - Chat models, but it comes at the cost of being the slowest.

# COMMAND ----------

# MAGIC %md
# MAGIC # Usage

# COMMAND ----------

# MAGIC %md
# MAGIC We recommend you primarily work with this model via `ai_query`
# MAGIC ([AWS](https://docs.databricks.com/sql/language-manual/functions/ai_query.html)|[Azure](https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/functions/ai_query)).
# MAGIC To use the model with `ai_query`, you must first deploy the model to Model Serving.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Deploying the model to Model Serving
# MAGIC
# MAGIC You can deploy this model directly to a Databricks Model Serving Endpoint
# MAGIC ([AWS](https://docs.databricks.com/machine-learning/model-serving/create-manage-serving-endpoints.html)|[Azure](https://learn.microsoft.com/en-us/azure/databricks/machine-learning/model-serving/create-manage-serving-endpoints)).
# MAGIC
# MAGIC Note: Model serving is not supported on GCP. On GCP, Databricks recommends running `Batch inference using Spark`, 
# MAGIC as shown below.
# MAGIC
# MAGIC We recommend the below workload types for each model size:
# MAGIC - `llama_2_7b_chat_hf` - GPU_MEDIUM (AWS), GPU_LARGE (Azure)
# MAGIC - `llama_2_13b_chat_hf` - MULTIGPU_MEDIUM (AWS), GPU_LARGE (Azure)
# MAGIC - `llama_2_70b_chat_hf` - please reach out to your Databricks representative or [submit the preview enrollment form](https://docs.google.com/forms/d/1-GWIlfjlIaclqDz6BPODI2j1Xg4f4WbFvBXyebBpN-Y/edit?ts=65124ee0) to access the necessary GPUs and get information on the required `workload_type` to pass when creating a serving endpoint
# MAGIC
# MAGIC You can create the endpoint by clicking the “Serve this model” button above or by using REST API as follows:
# MAGIC
# MAGIC ```
# MAGIC POST /api/2.0/serving-endpoints
# MAGIC
# MAGIC {
# MAGIC   "name": <endpoint name>,
# MAGIC   "config":{
# MAGIC     "served_models": [{
# MAGIC       "model_name": "<UC LOCATION FOR MODEL>",
# MAGIC       "model_version": "1",
# MAGIC       "workload_size": "Small",
# MAGIC       "workload_type": <workload type>,
# MAGIC       "scale_to_zero_enabled": false
# MAGIC     }]
# MAGIC   }
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC Please refer to Databricks documentation regarding REST API authentication
# MAGIC ([AWS](https://docs.databricks.com/dev-tools/auth.html)|[Azure](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/auth))
# MAGIC and access control for Model Serving
# MAGIC ([AWS](https://docs.databricks.com/security/auth-authz/access-control/serving-endpoint-acl.html)|[Azure](https://learn.microsoft.com/en-us/azure/databricks/security/auth-authz/access-control/serving-endpoint-acl)).
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## SQL transcription using ai_query
# MAGIC
# MAGIC To generate the text using the endpoint, use `ai_query`
# MAGIC to query the Model Serving endpoint. The first parameter should be the
# MAGIC name of the endpoint you previously created for Model Serving. The second
# MAGIC parameter should be a `named_struct` with name `prompt` and value is the 
# MAGIC column name that containing the instruction text. Extra parameters can be added
# MAGIC to the named_struct too. For supported parameters, please refer to [MLFlow AI gateway completion routes](https://mlflow.org/docs/latest/gateway/index.html#completions)
# MAGIC The third and fourth parameters set the return type, so that
# MAGIC `ai_query` can properly parse and structure the output text.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC ai_query(
# MAGIC   <endpoint name>,
# MAGIC   named_struct("prompt", text,  "max_tokens", 256),
# MAGIC   'returnType',
# MAGIC   'STRUCT<candidates:ARRAY<STRUCT<text:STRING, metadata:STRUCT<finish_reason:STRING>>>, metadata:STRUCT<input_tokens:float, output_tokens:float, total_tokens:float> >'
# MAGIC ) as generated_text
# MAGIC from <TABLE>

# COMMAND ----------

# MAGIC %md
# MAGIC You can use `ai_query` in this manner to generate text in
# MAGIC SQL queries or notebooks connected to Databricks SQL Pro or Serverless
# MAGIC SQL Endpoints.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Generate the text by querying the serving endpoint

# COMMAND ----------

# MAGIC %md
# MAGIC To query the model serving endpoint, first install the newest Databricks SDK for Python.

# COMMAND ----------

# Upgrade to use the newest Databricks SDK
%pip install --upgrade databricks-sdk
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC With the newest Databricks SDK installed, query the serving endpoint as follows:

# COMMAND ----------

# Run below in a separate notebook cell
from databricks.sdk import WorkspaceClient

# Change it to your own input
dataframe_records = [
    {"prompt": "<INSTRUCTION TEXT>", "max_tokens": 512}
]

w = WorkspaceClient()
w.serving_endpoints.query(
    name="<ENDPOINT NAME>",
    dataframe_records=dataframe_records,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Batch inference using Spark
# MAGIC
# MAGIC You can also directly load the model as a Spark UDF and run batch
# MAGIC inference on Databricks compute using Spark. We recommend using a
# MAGIC GPU cluster with Databricks Runtime for Machine Learning version 14.1
# MAGIC or greater.

# COMMAND ----------

import mlflow
mlflow.set_registry_uri("databricks-uc")
# Replace CATALOG_NAME with the name of the catalog containing this model
# You can also specify a different model version to load for inference
version = 1
generate = mlflow.pyfunc.spark_udf(spark, f"models:/<CATALOG_NAME>.models.<MODEL_NAME>/{version}", "string")

# COMMAND ----------

import pandas as pd

df = spark.createDataFrame(pd.DataFrame({"text": pd.Series("Python is")}))

# You can use the UDF directly on a text column
generated_df = df.select(generate(df.text).alias('generated_text'))