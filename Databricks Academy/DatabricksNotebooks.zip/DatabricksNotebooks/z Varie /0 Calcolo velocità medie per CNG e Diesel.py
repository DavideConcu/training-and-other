# Databricks notebook source
#table
input_table = "reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh"

df = spark.read.table(input_table)

# COMMAND ----------

from pyspark.sql.functions import col, sum

avg_speed = df.groupby("chassis").agg( (sum(col("totaldistance")) / sum((col("totaltime")/60**2))).alias("average_speed"))

# COMMAND ----------

from pyspark.sql.functions import percentile_approx

display(avg_speed.select(percentile_approx(col("average_speed"), 0.5)))

# COMMAND ----------

# MAGIC %md 
# MAGIC # Download all data for Daily Diesel my 21-22

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "DailyDieselmy21and22"
notebook = "allMissions"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

from pyspark.sql.functions import col

listaChassisDaEDWH = (spark.read.table("edwh.vehicle")\
                .filter((col("pvcb_ds_sub_product_cl").like("%DAILY%DIESEL%"))))\
                .filter((col("pvan_ds_preliminary_model_year")=="MY2019")|(col("pvan_ds_preliminary_model_year")=="MY2021"))\
                .select(col("pvan_cd_vin_code").alias("chassis"))

listaChassisDaEDWH.count()

# COMMAND ----------

#download super flat data
#from pyspark.sql.functions import col
#
#spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
#                    .join(listaChassisDaEDWH, "chassis")\
#                    .write\
#                    .mode("overwrite")\
#                    .option("overwriteschema", "true")\
#                    .saveAsTable(f"{nome}")
#
#print(f"saved file: {nome}")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(DISTINCT chassis)
# MAGIC FROM reliab.20231214_DailyDieselmy21and22_allMissions

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolo average Speed per Diesel
# MAGIC

# COMMAND ----------

df_speed = spark.read.table("reliab.20231214_DailyDieselmy21and22_allMissions")\
            .selectExpr("chassis", "totaltime/(60*60) as totaltime_hour", "totaldistance")

# COMMAND ----------

from pyspark.sql.functions import col,sum, mean
df_agg = df_speed.groupby("chassis").agg((sum(col("totaldistance"))/ sum(col("totaltime_hour"))).alias("avg_speed"))

# COMMAND ----------

display(df_agg.select(mean(col("avg_speed"))))

# COMMAND ----------

