# Databricks notebook source
from pyspark.sql.functions import col

filtro_veicoli = spark.read.table("edwh.vehicle")\
                    .selectExpr("pvan_cd_vin_code as chassis", 
                                "plan_ds_plant_nm as plant",
                                "pvcb_ds_sub_product_cl as product")\
                    .filter(col("plant").isin(["SUZZARA", "VALLADOLID"]))\
                    .filter(col("product").like("%DAILY%MY21%F1C%DIESEL%")) 


# COMMAND ----------

filtro_veicoli.count()

# COMMAND ----------

df = spark.read.table("reliab.20231214_dailydieselmy21and22_allmissions")\
        .select("chassis").distinct()\
        .join(filtro_veicoli, "chassis")\
        
            

# COMMAND ----------

df_pandas = df.toPandas()

# COMMAND ----------

display(df_pandas[30000:])

# COMMAND ----------

