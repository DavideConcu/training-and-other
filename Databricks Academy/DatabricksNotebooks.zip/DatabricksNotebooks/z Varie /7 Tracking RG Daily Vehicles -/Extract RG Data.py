# Databricks notebook source
import pandas as pd

#read chassis xlsx
chassis = pd.read_excel("/dbfs/FileStore/tables/reliab/Progetti Vari/chassis_rg_daily.xlsx")
chassis.drop(columns=["model", "engine"], inplace = True)

chassis_sdf = spark.createDataFrame(chassis)

# COMMAND ----------

chassis

# COMMAND ----------

display(chassis_sdf)

# COMMAND ----------

#dati del datacollector
dati_collector = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")

#join con il file excel
rg_daily_sdf = chassis_sdf.join(dati_collector, "chassis")

# COMMAND ----------

#write to catalog
save = True

if save:
    rg_daily_sdf.write\
        .mode("overwrite")\
            .option("overwriteschema", "true")\
                .saveAsTable("reliab.20240312_Vari_TrackingRGDaily_datafromdatacollector")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Explore Results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT rg_type, chassis, name, rg_phase, count(DISTINCT missionid) as missioni, max(startofsampling) as last_update
# MAGIC FROM reliab.20240312_Vari_TrackingRGDaily_datafromdatacollector
# MAGIC GROUP BY rg_type, chassis, name, rg_phase
# MAGIC ORDER BY rg_type, rg_phase, missioni DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT chassis, rg_phase, max(startOfSampling)
# MAGIC FROM reliab.20240312_Vari_TrackingRGDaily_datafromdatacollector
# MAGIC GROUP BY chassis, rg_phase

# COMMAND ----------

# MAGIC %md
# MAGIC ## Download GPS Paths 

# COMMAND ----------

dati_gps = spark.read.table("datacollector.datacollector_gps_tabular_prod")



# COMMAND ----------

##estrarre percorsi completi
save = True
if save:
    spark.sql("""SELECT a.chassis, a.missionId, a.name, a.rg_phase, a.rg_type, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
                    FROM  reliab.20240312_Vari_TrackingRGDaily_datafromdatacollector a 
                    LEFT JOIN datacollector.datacollector_gps_tabular_prod b
                        ON a.chassis = b.chassis 
                        AND b.startofsampling >= a.startofsampling 
                        AND b.endOfSampling   <= a.endOfSampling """)\
                            .write\
                            .mode("overWrite")\
                            .option("overwriteschema","true")\
                            .saveAsTable("reliab.20240312_vari_trackingRgDaily_gpsdata")

# COMMAND ----------

# MAGIC %sql
# MAGIC select chassis, rg_phase, rg_type, count(distinct missionid)
# MAGIC from reliab.20240312_vari_trackingRgDaily_gpsdata
# MAGIC group by chassis, rg_phase, rg_type

# COMMAND ----------

# MAGIC %sql
# MAGIC select rg_type, count(*)
# MAGIC from reliab.20240312_vari_trackingRgDaily_gpsdata
# MAGIC group by rg_type

# COMMAND ----------

