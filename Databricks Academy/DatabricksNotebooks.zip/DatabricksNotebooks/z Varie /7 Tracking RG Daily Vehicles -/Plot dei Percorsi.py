# Databricks notebook source
# MAGIC %pip install geopy folium polyline

# COMMAND ----------

#plot delle mission
from pyspark.sql.functions import col 

import folium

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 

datasetPercorsi  = "reliab.20240312_vari_trackingRgDaily_gpsdata"

df = spark.read.table(datasetPercorsi)\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC ### Per Chassis

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    #folium.Marker(
    #    location=row['path'][0],
    #    icon=folium.Icon(icon='play', color='green'),
    #    popup = popupLatLonStart
    #).add_to(listaLayers[num])
#
    #folium.Marker(
    #    location=row['path'][-1],
    #    icon=folium.Icon(icon='stop', color='red'),
    #    popup = popupLatLonEnd
    #).add_to(listaLayers[num])

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 

datasetPercorsi  = "reliab.20240312_vari_trackingRgDaily_gpsdata"

df = spark.read.table(datasetPercorsi)\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude")!=0)\
        .filter(col("latitude")!=0)\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.chassis)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.chassis)):
    df[df.chassis==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

