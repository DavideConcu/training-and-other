# Databricks notebook source
#filtrare dopo inizio start date
df_warr_start_date = spark.read.table("edwh.vehicle")\
                            .selectExpr("pvan_cd_vin_code as chassis", "pvan_id_warranty_start_date as warranty_start_date")

# COMMAND ----------

from pyspark.sql.functions import col

table = "datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod"

df = spark.read.table(table)\
            .filter(col("retarder")=="ELECTRONIC RETARDER")\
            .filter(col("chassis").isNotNull())\
            .filter(col("engineWorkHours").isNotNull())\
            .filter(col("odoAtEnd").isNotNull())\
            .filter(col("startofsampling").isNotNull())\
                .join(df_warr_start_date, "chassis", "left")\
                .filter(col("startofsampling")>=col("warranty_start_date"))


# COMMAND ----------

from pyspark.sql.functions import min, max

first_and_last_acquisition =   df\
                                   .groupBy(col("chassis"))\
                                   .agg(min(col("endofsampling")).alias("minDate"), max(col("endofsampling")).alias("maxDate"))

df_filtered = df.join(first_and_last_acquisition, "chassis")\
        .filter((col("endofsampling")==col("minDate")) | (col("endofsampling")==col("maxDate")))\
        .selectExpr("chassis",  "startofsampling", "engineWorkHours",  "odoAtEnd/1000 as odoAtEnd")\
        .orderBy("chassis", "startofsampling")

# COMMAND ----------

#dataset con tutte le mission

from pyspark.sql.functions import row_number, desc,col, collect_list, datediff, pow, abs

dateVariable = "startofsampling"

df_1rowPerVin = df_filtered\
                    .groupBy("chassis")\
                    .agg(collect_list(col(dateVariable)).alias("dates"), 
                            collect_list(col("engineWorkHours")).alias("engine"),
                            collect_list(col("odoAtEnd")).alias("odoAtEnd"))\
                    .select("*", 
                                abs(datediff(col("dates")[1], col("dates")[0])).alias("daysBetween"),
                                abs((col("engine")[1]-col("engine")[0])).alias("engineDiff"),
                                abs((col("odoAtEnd")[1]-col("odoAtEnd")[0])).alias("odoDiff")
                                )\
                    .select("*", ((365/col("daysBetween"))*col("engineDiff")).alias("AAU_Hours"),
                                    ((365/col("daysBetween"))*col("odoDiff")).alias("AAU_Km"))\
                    .filter(col("daysBetween")>0)\
                    .filter(col("AAU_Hours").isNotNull())\
                    .filter(col("AAU_Km").isNotNull())
                    
                    #.filter(col("AAU_Hours")>0)
                            

# COMMAND ----------

display(df_1rowPerVin)

# COMMAND ----------

from pyspark.sql.functions import mean

overall_mean = df_1rowPerVin.select(mean(col("AAU_Hours")).alias("Mean AAU Hours"), mean(col("AAU_Km")).alias("Mean AAU Km"))

# COMMAND ----------

display(overall_mean)

# COMMAND ----------

display(df_1rowPerVin)

# COMMAND ----------

#save to catalog
save = True

if save == True:
    df_1rowPerVin.write.saveAsTable("reliab.20231221_DailyWithRetarder_AAU_hoursAndKm")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Output Data

# COMMAND ----------

division = spark.read.table("edwh.vehicle")\
                .selectExpr("pvan_cd_vin_code as chassis", "pvcb_ds_business_unit as business_unit")

df = spark.read.table("reliab.20231221_DailyWithRetarder_AAU_hoursAndKm")\
                .join(division, "chassis", "left")



# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verifica Lista Veicoli Cinzia

# COMMAND ----------

import pandas as pd

vehicles = pd.read_excel("/dbfs/FileStore/tables/reliab/AAU Hours & Km Daily/Vehicles.xlsx")


# COMMAND ----------

#filtro sulla warranty start date 
mask = pd.isnull(vehicles.loc[:, "Base Warranty Start Date"])==False 
vehicles = vehicles[mask]

vehicles.reset_index(drop=True, inplace = True)

# COMMAND ----------

vehicles.

# COMMAND ----------

