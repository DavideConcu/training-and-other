# Databricks notebook source
from pyspark.sql.functions import col,year, min,max

conf = spark.read.table("edwh.vehicle_configuration")

listaVin = spark.read.table("edwh.vehicle")\
                .selectExpr("pvan_cd_vin_code", "pvcb_ds_sub_product_cl")\
                .filter(col("pvcb_ds_sub_product_cl").like("%DAILY%"))\
                .join(conf, "pvan_cd_vin_code")\
                .filter(col("pvcb_cd_fcp_axle_config_code")=="4X4")\
                .selectExpr("pvan_cd_vin_code as chassis").distinct()

# COMMAND ----------

#download data
#df = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
            .join(listaVin, "chassis")

#df.write.saveAsTable("reliab.20230725_Daily4x4_dataFlat")

# COMMAND ----------

#download percorsi 
df = spark.read.table("reliab.20230725_Daily4x4_dataFlat")

df.select("chassis", "missionid", "startofsampling", "endofsampling").distinct()\
                    .createOrReplaceTempView("listaMission")

# COMMAND ----------

#estrarre percorsi completi
nome = "reliab.20230725_Daily4x4_dataPercorsi"

spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
              FROM  listaMission a 
                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
                      ON a.chassis = b.chassis 
                      AND b.startofsampling >= a.startofsampling 
                      AND b.endOfSampling   <= a.endOfSampling """).write.saveAsTable(f"{nome}")


print(f"Table created: {nome}") 

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct missionid)
# MAGIC from reliab.20230725_Daily4x4_dataPercorsi
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC plottare alcune mission

# COMMAND ----------

