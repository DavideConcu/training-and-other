# Databricks notebook source
# MAGIC %md
# MAGIC ## Daily Diesel

# COMMAND ----------

from pyspark.sql.functions import col,year, min,max

listaVin = spark.read.table("edwh.vehicle")\
                .selectExpr("pvan_cd_vin_code as chassis", "pvcb_ds_sub_product_cl")\
                .filter(col("pvcb_ds_sub_product_cl").like("%DAILY%MY19%DIESEL%"))


df = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
            .join(listaVin, "chassis")\
            .filter(year(col("startofsampling"))>=2021)\
            .filter(col("engineWorkhours").isNotNull())\


dfDates = df\
            .groupBy("chassis")\
            .agg(min("startOfsampling").alias("minDate"), max(col("startofSampling")).alias("maxDate"))


df = df.join(dfDates, "chassis")\
        .filter((col("startofsampling")==col("minDate")) | (col("startofsampling")==col("maxDate")))\
        .select("chassis", "startofsampling", "engineWorkHours")
        



# COMMAND ----------

df.write.mode("overwrite").saveAsTable("reliab.20230721_DailyD_AAUHours_ListChassisWithEngine")

# COMMAND ----------

#dataset con tutte le mission
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, desc,col, collect_list, datediff, pow



tableName = "reliab.20230721_DailyD_AAUHours_ListChassisWithEngine"

dateVariable = "startofsampling"

windowAscend = Window().partitionBy("chassis").orderBy(dateVariable)
windowDescend = Window().partitionBy("chassis").orderBy(desc(dateVariable))

df = spark.read.table(tableName)\
                .filter(col("engineWorkHours").isNotNull())\
                            .groupBy("chassis")\
                            .agg(collect_list(col(dateVariable)).alias("dates"), 
                                 collect_list(col("engineWorkHours")).alias("engine"))\
                            .select("*", 
                                        datediff(col("dates")[1], col("dates")[0]).alias("daysBetween"),
                                        (col("engine")[1]-col("engine")[0]).alias("engineDiff"),
                                        )\
                            .select("*", ((((365/col("daysBetween"))*col("engineDiff"))**2)**0.5).alias("AAU_Hours"))
                            

                            


# COMMAND ----------

display(df)

# COMMAND ----------

df.write.mode("overwrite").saveAsTable("reliab.20230720_DailyD_AAUHours")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Daily CNG

# COMMAND ----------

#dataset con tutte le mission
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, desc,col, collect_list, datediff,abs


tableName = "reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh"

dateVariable = "startofsampling"

windowAscend = Window().partitionBy("chassis").orderBy(dateVariable)
windowDescend = Window().partitionBy("chassis").orderBy(desc(dateVariable))

df = spark.read.table(tableName)\
                .filter(col("engineWorkHours").isNotNull())\
                            .select("chassis", dateVariable, "engineWorkHours",
                            row_number().over(windowAscend).alias("ascend"),
                            row_number().over(windowDescend).alias("descend"))\
                            .filter((col("ascend")==1) | (col("descend") == 1))\
                            .groupBy("chassis")\
                            .agg(collect_list(col(dateVariable)).alias("dates"), 
                                 collect_list(col("engineWorkHours")).alias("engine"))\
                            .select("*", 
                                        datediff(col("dates")[1], col("dates")[0]).alias("daysBetween"),
                                        (col("engine")[1]-col("engine")[0]).alias("engineDiff"),
                                        )\
                            .select("*", (abs((365/col("daysBetween"))*col("engineDiff"))).alias("AAU_Hours"))
                            


# COMMAND ----------

display(df.filter(col("AAU_Hours")<0))

# COMMAND ----------

df.write.mode("overwrite").saveAsTable("reliab.20230720_DailyCNG_AAUHours")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sway

# COMMAND ----------

from pyspark.sql.functions import col,year, min,max

listaVin = spark.read.table("edwh.vehicle")\
                .selectExpr("pvan_cd_vin_code as chassis", "pvcb_ds_sub_product_cl", "pvan_ds_preliminary_model_year")\
                .filter(col("pvcb_ds_sub_product_cl").like("%S-WAY%"))\
                .filter(col("pvan_ds_preliminary_model_year").like("%MY2019%"))\
                .filter(~col("pvcb_ds_sub_vcl_cl").like("%NP%"))


df = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_super_flat_prod")\
            .join(listaVin, "chassis")\
            .filter(year(col("startofsampling"))>=2021)\
            .filter(col("engineWorkhours").isNotNull())\


dfDates = df\
            .groupBy("chassis")\
            .agg(min("startOfsampling").alias("minDate"), max(col("startofSampling")).alias("maxDate"))


df = df.join(dfDates, "chassis")\
        .filter((col("startofsampling")==col("minDate")) | (col("startofsampling")==col("maxDate")))\
        .select("chassis", "startofsampling", "engineWorkHours")
        


# COMMAND ----------

#df.write.mode("overwrite").saveAsTable("reliab.20230721_SWAYD_AAUHours_ListChassisWithEngine")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from reliab.20230721_SWAYD_AAUHours_ListChassisWithEngine

# COMMAND ----------

#dataset con tutte le mission
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, desc,col, collect_list, datediff,abs


tableName = "reliab.20230721_SWAYD_AAUHours_ListChassisWithEngine"

dateVariable = "startofsampling"

windowAscend = Window().partitionBy("chassis").orderBy(dateVariable)
windowDescend = Window().partitionBy("chassis").orderBy(desc(dateVariable))

df = spark.read.table(tableName)\
                .filter(col("engineWorkHours").isNotNull())\
                            .select("chassis", dateVariable, "engineWorkHours",
                            row_number().over(windowAscend).alias("ascend"),
                            row_number().over(windowDescend).alias("descend"))\
                            .filter((col("ascend")==1) | (col("descend") == 1))\
                            .groupBy("chassis")\
                            .agg(collect_list(col(dateVariable)).alias("dates"), 
                                 collect_list(col("engineWorkHours")).alias("engine"))\
                            .select("*", 
                                        datediff(col("dates")[1], col("dates")[0]).alias("daysBetween"),
                                        (col("engine")[1]-col("engine")[0]).alias("engineDiff"),
                                        )\
                            .select("*", (abs((365/col("daysBetween"))*col("engineDiff"))).alias("AAU_Hours"))
                            


# COMMAND ----------

display(df)

# COMMAND ----------

df.write.mode("overwrite").saveAsTable("reliab.20230720_SWAYD_AAUHours")

# COMMAND ----------

