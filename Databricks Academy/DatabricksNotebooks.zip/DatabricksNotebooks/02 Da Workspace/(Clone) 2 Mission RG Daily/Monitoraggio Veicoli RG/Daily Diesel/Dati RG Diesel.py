# Databricks notebook source
# MAGIC %md 
# MAGIC # Extract Data of RG 11 Diesel

# COMMAND ----------

chassis = ["ZCFCC35B105569869", "ZCFC665C105570246", "ZCFCC52B905570638", "ZCFCL35A405569470", "ZCFC635C705569469", "ZCFC535C505571014"]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract Super Flat Signals

# COMMAND ----------

from pyspark.sql.functions import col

inputTable = "datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod"

#extract data
spark.read.table(inputTable)\
        .filter(col("chassis").isin(chassis))\
        .write.saveAsTable("reliab.20231030_RGDailyDieselMonitoring_superFlatData")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM reliab.20231030_RGDailyDieselMonitoring_superFlatData

# COMMAND ----------

