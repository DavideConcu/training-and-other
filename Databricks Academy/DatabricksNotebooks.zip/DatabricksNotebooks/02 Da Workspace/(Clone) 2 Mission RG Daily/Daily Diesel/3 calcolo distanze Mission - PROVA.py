# Databricks notebook source
# MAGIC %md 
# MAGIC # Calcolo Distanza tra ogni punto Mission

# COMMAND ----------

# MAGIC %md
# MAGIC #### Test Accuratezza

# COMMAND ----------

# MAGIC %md
# MAGIC #### Applicazione ai dati

# COMMAND ----------

pip install geopy

# COMMAND ----------

pip install polyline

# COMMAND ----------

pip install folium

# COMMAND ----------

import geopy.distance

# COMMAND ----------

coords_1 = (45.071690, 7.654005)
coords_2 = (45.066078, 7.669629)

print (geopy.distance.geodesic(coords_1, coords_2).km)

#OK

# COMMAND ----------

#missionDf = spark.read.table("reliab.dailybagpspath")

# COMMAND ----------

#display(missionDf)

# COMMAND ----------

#from pyspark.sql.functions import col, concat_ws

#display(missionDf.select("chassis", "startofsampl_mission").withColumn("prova", concat_ws("_", col("chassis"), col("startofsampl_mission"))).distinct())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Visualizzare le Mission - Prova

# COMMAND ----------

import requests
import folium
import polyline

# COMMAND ----------

# MAGIC %md
# MAGIC route = {'route': [(44.88480, 8.85900),
# MAGIC (44.88620, 8.85830),
# MAGIC (44.88550, 8.85689),
# MAGIC (44.88340, 8.85871),
# MAGIC (44.88010, 8.85828),
# MAGIC (44.87650, 8.85769),
# MAGIC (44.87280, 8.85716),
# MAGIC (44.87130, 8.85693),
# MAGIC (44.86540, 8.85605),
# MAGIC (44.85690, 8.85478),
# MAGIC (44.85060, 8.85379),
# MAGIC (44.84690, 8.85325),
# MAGIC (44.84260, 8.85324),
# MAGIC (44.83800, 8.85353),
# MAGIC (44.83350, 8.85383),
# MAGIC (44.82920, 8.85409),
# MAGIC (44.82480, 8.85436),
# MAGIC (44.82070, 8.85465),
# MAGIC (44.81890, 8.85483)],
# MAGIC  'start_point': [44.88480, 8.85900],
# MAGIC  'end_point': [44.81890, 8.85483],
# MAGIC  'distance': 4995.3,
# MAGIC   'name': "ZCFCG35A005345147_2021-06-03 09:59:08"}

# COMMAND ----------

# MAGIC %md
# MAGIC def get_map(route):
# MAGIC     
# MAGIC     m = folium.Map(location=[(route['start_point'][0] + route['end_point'][0])/2, 
# MAGIC                              (route['start_point'][1] + route['end_point'][1])/2], 
# MAGIC                    zoom_start=13)
# MAGIC
# MAGIC     folium.PolyLine(
# MAGIC         route['route'],
# MAGIC         weight=8,
# MAGIC         color='blue',
# MAGIC         opacity=0.6,
# MAGIC         popup = route["name"]
# MAGIC     ).add_to(m)
# MAGIC
# MAGIC     folium.Marker(
# MAGIC         location=route['start_point'],
# MAGIC         icon=folium.Icon(icon='play', color='green')
# MAGIC     ).add_to(m)
# MAGIC
# MAGIC     folium.Marker(
# MAGIC         location=route['end_point'],
# MAGIC         icon=folium.Icon(icon='stop', color='red')
# MAGIC     ).add_to(m)
# MAGIC
# MAGIC     return m

# COMMAND ----------

#get_map(route)

# COMMAND ----------

# MAGIC %md
# MAGIC #### visualizzare tutte le mission

# COMMAND ----------

import requests
import folium
import polyline

# COMMAND ----------

missionDf = spark.read.table("reliab.dailybagpspath").na.drop("any").toPandas()

# COMMAND ----------

missionDf = spark.read.table("reliab.dailybagpspath").na.drop("any")

# COMMAND ----------

for chassis, startMission in  missionDf.select("chassis","startofsampl_mission").distinct().orderBy("chassis","startofsampl_mission").collect():
    #print(chassis, startMission)
    mission = {"chassis": chassis, "mission": startMission}

# COMMAND ----------

mission

# COMMAND ----------

from pyspark.sql.functions import col, desc

singleMissionDf = missionDf\
        .where(col("chassis") == mission["chassis"])\
        .where(col("startofsampl_mission") == mission["mission"])\
        .orderBy(col("timestamp"))

# COMMAND ----------

route = list()
for long, lat in singleMissionDf.select("latitude", "longitude").collect():
    route.append(tuple([long, lat]))

# COMMAND ----------

rut = dict()
rut["route"] = route

# COMMAND ----------

#inizio e fine mission
rut["start_point"] = (singleMissionDf.collect()[0]["Latitude"], singleMissionDf.collect()[0]["Longitude"])
rut["end_point"] = (singleMissionDf.collect()[-1]["Latitude"], singleMissionDf.collect()[-1]["Longitude"])

rut["name"] = singleMissionDf.selectExpr("CONCAT(chassis, ' ', startofsampl_mission) as name").limit(1).collect()[0]["name"]

# COMMAND ----------

#get_map(rut)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process for all Missions

# COMMAND ----------

missionDf = spark.read.table("reliab.dailybagpspath").na.drop("any")

# COMMAND ----------

# MAGIC %md
# MAGIC m = folium.Map(location=(44.88480, 8.85900), 
# MAGIC                zoom_start=13)

# COMMAND ----------

# MAGIC %md
# MAGIC def get_map(route):
# MAGIC
# MAGIC     folium.PolyLine(
# MAGIC         route['route'],
# MAGIC         weight=8,
# MAGIC         color='blue',
# MAGIC         opacity=0.6,
# MAGIC         popup = route["name"]
# MAGIC     ).add_to(m)
# MAGIC
# MAGIC     folium.Marker(
# MAGIC         location=route['start_point'],
# MAGIC         icon=folium.Icon(icon='play', color='green')
# MAGIC     ).add_to(m)
# MAGIC
# MAGIC     folium.Marker(
# MAGIC         location=route['end_point'],
# MAGIC         icon=folium.Icon(icon='stop', color='red')
# MAGIC     ).add_to(m)
# MAGIC
# MAGIC     

# COMMAND ----------

# MAGIC %md
# MAGIC from pyspark.sql.functions import col
# MAGIC
# MAGIC for chassis, startMission in  missionDf.select("chassis","startofsampl_mission").distinct().orderBy("chassis","startofsampl_mission").collect():
# MAGIC     #print(chassis, startMission)
# MAGIC     print(mission)
# MAGIC     mission = {"chassis": chassis, "mission": startMission}
# MAGIC     
# MAGIC     #filtrare il dataset di partenza per tenere la singola mission
# MAGIC     singleMissionDf = missionDf\
# MAGIC         .where(col("chassis") == mission["chassis"])\
# MAGIC         .where(col("startofsampl_mission") == mission["mission"])\
# MAGIC         .orderBy(col("timestamp"))
# MAGIC     
# MAGIC     #aggiungere il percorso completo
# MAGIC     path = list()
# MAGIC     for long, lat in singleMissionDf.select("latitude", "longitude").collect():
# MAGIC         path.append(tuple([long, lat]))
# MAGIC     
# MAGIC     #definire il dizionario contenente le specifiche del percorso
# MAGIC     route = dict()
# MAGIC     route["route"] = path
# MAGIC     route["start_point"] = (singleMissionDf.collect()[0]["Latitude"], singleMissionDf.collect()[0]["Longitude"])
# MAGIC     route["end_point"] = (singleMissionDf.collect()[-1]["Latitude"], singleMissionDf.collect()[-1]["Longitude"])
# MAGIC     route["name"] = singleMissionDf.selectExpr("CONCAT(chassis, ' ', startofsampl_mission) as name").limit(1).collect()[0]["name"]
# MAGIC     
# MAGIC     print(route)
# MAGIC     get_map(route)
# MAGIC     

# COMMAND ----------

#m

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Calcolare le distanze delle mission che ci interessano

# COMMAND ----------

miss1 = ("ZCFCH35A005399657", "2021-10-21 03:56:17")

# COMMAND ----------

missionDf.columns

# COMMAND ----------

from pyspark.sql.functions import col

m1 = missionDf.where(col("chassis") == "ZCFCH35A005399657").filter(col("startofsampl_mission") == "2021-10-21 03:56:17" ).orderBy("timestamp")

# COMMAND ----------

from pyspark.sql.functions import  lag
from pyspark.sql.window import  Window

m1 = m1.withColumn("lag_latitude", lag('latitude', 1).over(Window.partitionBy('chassis', "startofsampl_mission").orderBy('timestamp')))
m1 = m1.withColumn("lag_longitude", lag('longitude', 1).over(Window.partitionBy('chassis', "startofsampl_mission").orderBy('timestamp')))

# COMMAND ----------

display(m1)

# COMMAND ----------

#applicare la funzione di geopy per calcolare le distanze da punto a punto
import geopy.distance

geodistance = udf(geopy.distance.geodesic)

# COMMAND ----------

geopy.distance.geodesic([ 44.97640, 7.2] , [None, None]).km

# COMMAND ----------

from pyspark.sql.functions import  array
from pyspark.sql.types import FloatType

m1 = m1.withColumn("point1", array(col("latitude") , col("longitude")))
m1 = m1.withColumn("point2", array(col("lag_latitude") , col("lag_longitude")))

# COMMAND ----------

display(m1)

# COMMAND ----------

# MAGIC %md
# MAGIC #### prova veloce con pandas

# COMMAND ----------

from pyspark.sql.functions import  lag
from pyspark.sql.window import  Window

missionDf = missionDf.withColumn("lag_latitude", lag('latitude', 1).over(Window.partitionBy('chassis', "startofsampl_mission").orderBy('timestamp')))
missionDf = missionDf.withColumn("lag_longitude", lag('longitude', 1).over(Window.partitionBy('chassis', "startofsampl_mission").orderBy('timestamp')))

# COMMAND ----------

missionPd = missionDf.toPandas()

# COMMAND ----------

missionPd.lag_latitude = missionPd.lag_latitude.fillna(missionPd.Latitude)
missionPd.lag_longitude = missionPd.lag_longitude.fillna(missionPd.Longitude)

# COMMAND ----------

missionPd["distance"] = missionPd.apply(lambda x: geopy.distance.geodesic((x["lag_latitude"], x["lag_longitude"]), (x["Latitude"], x["Longitude"])).km , axis = 1)

# COMMAND ----------

missionPd

# COMMAND ----------

somma = missionPd.groupby(["chassis", "startofsampl_mission"]).distance.sum().reset_index().rename({"distance": "total_distance"}, axis = 1)

# COMMAND ----------

somma.loc[(somma.chassis == "ZCFCL35A205452289") &(somma.startofsampl_mission >= "2022-06-06 11:22:20"),:]

# COMMAND ----------

## funziona 


# COMMAND ----------

#creare la variabile di altitudine per bin
def alt_bin(x):
    if x <= 300:
        alt = "0m - 300m"
    elif x <= 600:
        alt = "300m - 600m"
    elif x <= 900:
        alt = "600m - 900m"
    else:
        alt = "> 900m"
    return alt

# COMMAND ----------

missionPd["altitude_bin"] = missionPd.apply(lambda x: alt_bin(x["Altitude"]) , axis = 1)

# COMMAND ----------

sommaBin = missionPd.groupby(["chassis", "startofsampl_mission", "altitude_bin"]).distance.sum().reset_index()

# COMMAND ----------

sommaBin = sommaBin.merge(somma, how="left", on = ["chassis", "startofsampl_mission"])
sommaBin = sommaBin.loc[sommaBin.total_distance>0,:]
sommaBin["percent_alt"] = sommaBin.distance / sommaBin.total_distance

# COMMAND ----------

sommaBin.loc[(sommaBin.chassis ==  "ZCFCL35A205452289" )&( sommaBin.startofsampl_mission >= "2022-06-06 11:22:20"),:].sort_values(by=["startofsampl_mission", "altitude_bin"])

# COMMAND ----------

#prova = spark.read.table("reliab.dailyrg_missiondff").select("chassis", "startofsampl_mission","timestamp", "road").toPandas()

# COMMAND ----------

#missionPd = missionPd.rename({"Timestamp":"timestamp"}, axis = 1).merge(prova, how="left", on=["chassis", "startofsampl_mission", "timestamp"])

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggiungere La via da Nominatim

# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#inizializzare il servizio
locator = Nominatim(user_agent="iveCoder", timeout=10)
reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)

# COMMAND ----------

coordinates = "53.480837, -2.244914"
location = locator.reverse(coordinates).raw

# COMMAND ----------

location["address"]["road"]

# COMMAND ----------

# MAGIC %md
# MAGIC def get_street(coordinates):
# MAGIC     location = locator.reverse(coordinates).raw
# MAGIC     if "road" in location["address"]:
# MAGIC         road = location["address"]["road"]
# MAGIC         print("Road: ", road)
# MAGIC     else:
# MAGIC         road = None
# MAGIC         print("Road Not Found!!!")
# MAGIC     
# MAGIC     return road

# COMMAND ----------

# MAGIC %md
# MAGIC missionPd["road"] = missionPd.apply(lambda x: get_street(f"{x['Latitude']}, {x['Longitude']}"), axis = 1)

# COMMAND ----------

missionPd.distance

# COMMAND ----------

#salvare il df
#missionDf_spark = spark.createDataFrame(missionPd)
#missionDf_spark.write.format("delta").mode("overWrite").saveAsTable("reliab.dailyRG_MissionDf")

# COMMAND ----------

#tappare i missing con ffill e poi con bfill
missionPd["road"] = missionPd.groupby(["chassis", "startofsampl_mission"]).road.ffill()
missionPd["road"] = missionPd.groupby(["chassis", "startofsampl_mission"]).road.bfill()

# COMMAND ----------

missionPd = missionPd.loc[missionPd.road.isna()==False].reset_index(drop = True)

# COMMAND ----------

#estrarre la prima parola dalla strada
missionPd["roadType"] =  missionPd.apply(lambda x: x["road"].split()[0] , axis = 1)

# COMMAND ----------

missionPd

# COMMAND ----------

missionPd

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prova Nominatim 2  

# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#inizializzare il servizio
locator = Nominatim(user_agent="iveCoder", timeout=10)
reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.0001)

# COMMAND ----------

coordinates = "53.480837, -2.244914"
location = locator.reverse(coordinates).raw
location

# COMMAND ----------

address = location["address"]

# COMMAND ----------

for riga in range(len(missionPd)):
    lat = missionPd.loc[riga, "Latitude"]
    lon = missionPd.loc[riga, "Longitude"]
    coord = f"{lat},{lon}"
    location = locator.reverse(coord).raw
    address = location["address"]
    if "road" in address:
        road = address["road"]
        missionPd.loc[riga, "road"] = road 
        print("Road: ", road)
    if "country" in address:
        country = address["country"]
        missionPd.loc[riga, "country"] = country 
        print("country: ", country)    
        
    

# COMMAND ----------

#salvare il df
missionDf_spark = spark.createDataFrame(missionPd)
missionDf_spark.write.format("delta").mode("overWrite").saveAsTable("reliab.dailyRG_MissionDf2")

# COMMAND ----------

missionPd

# COMMAND ----------

# MAGIC %md
# MAGIC #### Continuo - 22/02

# COMMAND ----------

from pyspark.sql.functions import col, upper

streetsDf = spark.read.table("reliab.dailyRG_MissionDf2").filter(upper(col("country")) =="ITALIA")

# COMMAND ----------

display(streetsDf.limit(5))

# COMMAND ----------

mission = streetsDf.filter(col("chassis") == "ZCFCH35A905399656").filter(col("startofsampl_mission")=="2022-10-07 09:43:44").toPandas()

# COMMAND ----------

#calcolo della distanza per categoria di altitudine
distanzaTotaleMission = mission.groupby(["chassis", "startofsampl_mission"]).distance.sum().reset_index().rename({"distance": "total_distance"}, axis = 1)

distanzaAltitudineBin = mission.groupby(["chassis", "startofsampl_mission", "altitude_bin"]).distance.sum().reset_index()
distanzaAltitudineBin = distanzaAltitudineBin.merge(distanzaTotaleMission, how="left", on = ["chassis", "startofsampl_mission"])
distanzaAltitudineBin = distanzaAltitudineBin.loc[distanzaAltitudineBin.total_distance>0,:]
distanzaAltitudineBin["percent_alt"] = distanzaAltitudineBin.distance / distanzaAltitudineBin.total_distance
distanzaAltitudineBin

# COMMAND ----------

# MAGIC %md
# MAGIC ### Mappare le Strade in Urban / Extra-Urban / Highway 

# COMMAND ----------

from pyspark.sql.functions import col, upper

streetsDf = spark.read.table("reliab.dailyRG_MissionDf2").filter(upper(col("country")) =="ITALIA")

# COMMAND ----------

#riempire i missing con N.A."
streetsDf = streetsDf.na.fill({"road":"N.A."})

# COMMAND ----------

display(streetsDf.select(col("road")).distinct().orderBy("road").limit(5))

# COMMAND ----------

from pyspark.sql.functions import split

streetsDf = streetsDf\
        .withColumn("road1", split(col("road"), " ")[0])\
        .withColumn("road2", split(col("road"), " ")[1])


# COMMAND ----------

display(streetsDf.select("road1").distinct().orderBy("road1"))

# COMMAND ----------

display(streetsDf.select("road2").distinct().orderBy("road2"))

# COMMAND ----------

#display(streetsDf.select("road").filter(col("road1") == "Asse"))

# COMMAND ----------

#### Mappa Strade
import re 

def map_streets(road1, road2 ):
    """mappare le strade"""
    
    if type(road1) == str:
        
        #highway
        patternHigh = r"(^A\d{0,3}\s{0,1}$|^Autostrad|^Svincolo|^Tangenziale|^Diramazione)"
                
        #extraurban
        patternExtr1 = r"(^(SP|SR|SS)\d{0,3}[a-z]*\d*$|Asse|Galleria)"
        patternExtr2 = [r"Strada" , r"^(Provinciale|Regionale|Statale)"]
        
        if re.match(patternHigh, road1):
            streetType = "Highway"

        elif re.match(patternExtr1 , road1) or (type(road2) == str and re.match(patternExtr2[0] , road1) and re.match(patternExtr2[1] , road2)) :
            streetType = "Extra-Urban"
            
        elif road1 == "N.A.":
            streetType = "N.A."
                
        else:
            streetType = "Urban"
                
    else:
        streetType= "N.A."
    
    return streetType

# COMMAND ----------

streetType_UDF = udf(lambda x,y: map_streets(x, y))

# COMMAND ----------

streetsDf = streetsDf.withColumn("streetType", streetType_UDF(col("road1"), col("road2"))).drop("road1", "road2")

# COMMAND ----------

display(streetsDf.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sommare Km su Altitudine e Tipo Strada

# COMMAND ----------

from pyspark.sql.functions import sum

totalDistanceMission = streetsDf.groupBy("chassis", "startofsampl_mission").agg(sum("distance").alias("TotalDistance"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Altitudine

# COMMAND ----------

#altitude Df 
altitudeDistanceDf = streetsDf.groupBy("chassis", "startofsampl_mission", "altitude_bin").agg(sum("distance").alias("distanceAltitude"))

# COMMAND ----------

#somma su categorie di altitudine e merge con total distance 
altitudeDistanceDf = altitudeDistanceDf.join(totalDistanceMission , ["chassis", "startofsampl_mission"], "leftouter").withColumn("distanceAltitudePercent", col("distanceAltitude")/col("TotalDistance"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tipo Strada

# COMMAND ----------

#street distance Df 
streetDistanceDf = streetsDf.groupBy("chassis", "startofsampl_mission", "streetType").agg(sum("distance").alias("distanceStreet"))

# COMMAND ----------

##somma su categorie di altitudine e merge con total distance 
streetDistanceDf = streetDistanceDf.join(totalDistanceMission , ["chassis", "startofsampl_mission"], "leftouter").withColumn("distanceStreetPercent", col("distanceStreet")/col("TotalDistance"))

# COMMAND ----------

#prova sulla mission TORINO - AOSTA
display(streetsDf.filter(col("chassis") == "ZCFCH35A005399657").filter(col("startofsampl_mission")=="2021-10-21 03:56:17").orderBy("timestamp"))

# COMMAND ----------

### sembra corretto

# COMMAND ----------

# MAGIC %md
# MAGIC #### estrarre tabella di interesse per singola mission

# COMMAND ----------

chassis = "ZCFCH35A905399656"
startofsamp = "2022-10-07 09:43:44"

# COMMAND ----------

display(streetsDf.filter(col("chassis") == chassis).filter(col("startofsampl_mission")==startofsamp).orderBy("timestamp"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### tabella altitudine

# COMMAND ----------

altitudeTabella = altitudeDistanceDf.filter(col("chassis")==chassis).filter(col("startofsampl_mission")==startofsamp).orderBy("chassis", "startofsampl_mission").toPandas()
altitudeTabella

# COMMAND ----------

# MAGIC %md
# MAGIC #### tabella street

# COMMAND ----------

from pyspark.sql.functions import desc

streetTabella = streetDistanceDf.filter(col("chassis")==chassis).filter(col("startofsampl_mission")==startofsamp).orderBy("chassis", "startofsampl_mission", desc("distanceStreetPercent")).toPandas()
streetTabella

# COMMAND ----------

# MAGIC %md
# MAGIC #### mission mixed vin

# COMMAND ----------

chassis = set(["ZCFCL35A205452289", "ZCFCL35A205452289", "ZCFCG35A005345147"])
date = set ( ["2022-11-04 09:55:02" , "2022-04-21 07:21:09", "2022-11-09 06:44:16", "2021-01-04 10:20:16"])

# COMMAND ----------

from pyspark.sql.functions import desc

streetTabella = streetDistanceDf.filter(col("chassis").isin(chassis)).filter(col("startofsampl_mission").isin(date)).orderBy("chassis", desc("distanceStreetPercent")).toPandas()
streetTabella.TotalDistance.sum()

# COMMAND ----------

