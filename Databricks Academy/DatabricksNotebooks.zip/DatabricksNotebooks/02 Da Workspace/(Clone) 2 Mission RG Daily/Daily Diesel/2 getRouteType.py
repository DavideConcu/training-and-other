# Databricks notebook source
# MAGIC %md
# MAGIC ## Download Dati Nominatim

# COMMAND ----------

spark.read.table("reliab.dailybagpspath").schema

# COMMAND ----------

spark.read.table("reliab.dailybagpspath").show(5)

# COMMAND ----------

dfPath = spark.read.table("reliab.dailybagpspath").na.drop("any").toPandas()

# COMMAND ----------

dfPath

# COMMAND ----------

# MAGIC %md
# MAGIC #### richiesta dati a nominatim

# COMMAND ----------

pip install geopy

# COMMAND ----------

pip install geopy[aiohttp]

# COMMAND ----------

import pandas, os, geopy
from geopy.geocoders import Nominatim
from geopy.adapters import AioHTTPAdapter

# COMMAND ----------

geoLocator = Nominatim(user_agent="vv")

# COMMAND ----------

location = geoLocator.reverse("45.553621, 8.056746")
location

# COMMAND ----------

dfPath

# COMMAND ----------

lat  = dfPath.loc[0, "Latitude"]
lon  = dfPath.loc[0, "Longitude"]    

async with Nominatim(
    user_agent="missionPath",
    adapter_factory=AioHTTPAdapter,
    
) as geolocator:
    location = await geolocator.reverse(f"{lat},{lon}")
    print(location.address)


# COMMAND ----------

 location.raw

# COMMAND ----------

from geopy.adapters import AioHTTPAdapter
from geopy.geocoders import Nominatim


for riga in range(len(dfPath)):
    
    lat  = dfPath.loc[riga, "Latitude"]
    lon  = dfPath.loc[riga, "Longitude"]    
    
    async with Nominatim(
        user_agent="missionPath",
        adapter_factory=AioHTTPAdapter,
    ) as geolocator:
        location = await geolocator.reverse(f"{lat},{lon}")
        print( location.raw, "\n")
        
        dfPath.loc[riga, "osm_type"] = location.raw["osm_type"]
        dfPath.loc[riga, "display_name"] = location.raw["display_name"]        
        dfPath.loc[riga, "road"] = location.raw["address"]["road"]

# COMMAND ----------

from geopy.geocoders import get_geocoder_for_service
get_geocoder_for_service("nominatim")

# COMMAND ----------

from geopy.geocoders import get_geocoder_for_service

def geocode(geocoder, config, query):
    cls = get_geocoder_for_service(geocoder)
    geolocator = cls(**config)
    location = geolocator.geocode(query)
    return location.address

geocode("nominatim", dict(user_agent="http"), "london")

# COMMAND ----------

### Dataset contententi i percorsi 
chassis = spark.read.table("reliab.dailybagpspath").select("chassis").distinct().limit(4).show()

# COMMAND ----------

from pyspark.sql.functions import col
dfPath = spark.read.table("reliab.dailybagpspath").filter(col("chassis") == "ZCFCH35A305304878")

# COMMAND ----------

dfPath = dfPath.filter(col("startofsampl_mission") == '2022-11-07T13:16:50')

# COMMAND ----------

dfPath.show()

# COMMAND ----------

latitude = dfPath.select("Latitude").collect()
longitude =  dfPath.select("Longitude").collect()

for lat, long in zip(latitude, longitude):
    latit = lat["Latitude"]
    longit = long["Longitude"]
    
    #location = geoLocator.reverse(f"{latit}, {longit}")
    #strada = location.raw["address"]["road"]
    
    print("("+str(latit)+",", str(longit)+"),")
    
    

# COMMAND ----------

#sembra funzionare, aggiungere la strada in tutto il dataset

# COMMAND ----------

dfPath.map()

# COMMAND ----------

# MAGIC %md
# MAGIC #### create map of path

# COMMAND ----------

pip install folium

# COMMAND ----------

pip install polyline

# COMMAND ----------

import requests
import folium
import polyline

# COMMAND ----------

url = "http://10.22.168.65:9080/route/v1/driving/-117.851364,33.698206;-117.838925,33.672260"
r = requests.get(url)
res = r.json()
res

# COMMAND ----------

route = {'route': [(44.88480, 8.85900),
(44.88620, 8.85830),
(44.88550, 8.85689),
(44.88340, 8.85871),
(44.88010, 8.85828),
(44.87650, 8.85769),
(44.87280, 8.85716),
(44.87130, 8.85693),
(44.86540, 8.85605),
(44.85690, 8.85478),
(44.85060, 8.85379),
(44.84690, 8.85325),
(44.84260, 8.85324),
(44.83800, 8.85353),
(44.83350, 8.85383),
(44.82920, 8.85409),
(44.82480, 8.85436),
(44.82070, 8.85465),
(44.81890, 8.85483)],
 'start_point': [44.88480, 8.85900],
 'end_point': [44.81890, 8.85483],
 'distance': 4995.3}

# COMMAND ----------

mappa = folium.Map(location=[(route['start_point'][0] + route['end_point'][0])/2, 
                         (route['start_point'][1] + route['end_point'][1])/2], 
               zoom_start=10)

# COMMAND ----------

#mappa

# COMMAND ----------

folium.PolyLine(
    route['route'],
    weight=8,
    color='blue',
    opacity=0.6
).add_to(mappa)

# COMMAND ----------

folium.Marker(
    location=route['start_point'],
    icon=folium.Icon(icon='play', color='green')
).add_to(mappa)

folium.Marker(
    location=route['end_point'],
    icon=folium.Icon(icon='stop', color='red')
).add_to(mappa)

# COMMAND ----------

#mappa

# COMMAND ----------

def get_map(route):
    
    m = folium.Map(location=[(route['start_point'][0] + route['end_point'][0])/2, 
                             (route['start_point'][1] + route['end_point'][1])/2], 
                   zoom_start=13)

    folium.PolyLine(
        route['route'],
        weight=8,
        color='blue',
        opacity=0.6
    ).add_to(m)

    folium.Marker(
        location=route['start_point'],
        icon=folium.Icon(icon='play', color='green')
    ).add_to(m)

    folium.Marker(
        location=route['end_point'],
        icon=folium.Icon(icon='stop', color='red')
    ).add_to(m)

    return m

# COMMAND ----------

#get_map(route)

# COMMAND ----------

