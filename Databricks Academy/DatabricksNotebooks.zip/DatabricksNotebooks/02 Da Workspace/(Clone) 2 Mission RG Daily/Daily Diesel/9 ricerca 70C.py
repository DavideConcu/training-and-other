# Databricks notebook source
vehic = spark.read.table("edwh.vehicle").withColumnRenamed("pvan_cd_vin_code", "chassis")

df = spark.read.table("reliab.20230420_R39_RGDaily_TabelleRiassuntiveMissionAree_perProcMeans")\
            .select("chassis", "path").distinct()\
            .join(vehic.select("chassis", "prvp_ds_vp_sdes"), "chassis")

# COMMAND ----------

from pyspark.sql.functions import col


display(df.filter(col("prvp_ds_vp_sdes").isin(["70C18HA8/P", "70C18H", "70C16H3.0"])))

# COMMAND ----------

display
(spark.read.table("reliab.20230420_R39_RGDaily_TabelleRiassuntiveMissionAree_perProcMeans"))

# COMMAND ----------

