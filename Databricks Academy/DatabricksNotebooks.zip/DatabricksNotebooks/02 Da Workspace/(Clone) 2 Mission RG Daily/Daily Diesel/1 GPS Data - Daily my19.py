# Databricks notebook source
# MAGIC %md
# MAGIC # Scaricare dati GPS mission bad - Daily my19

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, TimestampType, StringType

mySchema = StructType([
    StructField("chassis",StringType(),True ),
    StructField("startofsampling",TimestampType(),True ),
    StructField("endofsampling",TimestampType(),True ),
    StructField("config",StringType(),True )
])

# COMMAND ----------

# File location and type
file_location = "dbfs:/FileStore/tables/reliab/Tabella_a_elenco___chassis_1_CONV.csv"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
dfViya = spark.read.format(file_type) \
.option("header", first_row_is_header) \
.schema(mySchema)\
.option("timestampFormat", "ddMMMyy:HH:mm:ss")\
.option("sep", delimiter) \
.load(file_location)

dfViya

# COMMAND ----------

display(dfViya, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Estrarre gps data

# COMMAND ----------

dfViya = dfViya\
    .withColumnRenamed("startofsampling", "startofsampl_mission")\
    .withColumnRenamed("endofsampling", "endofsampl_mission")
    
display(dfViya.limit(5))

# COMMAND ----------

dfViya.createOrReplaceTempView("viyaView")

# COMMAND ----------

#spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
 #             FROM  viyaView a 
  #                LEFT JOIN datacollector.datacollector_gps_tabular_prod b
   #                   ON a.chassis = b.chassis 
    #                  AND b.startofsampling >= a.startofsampl_mission 
     #                 AND b.endOfSampling   <= a.endofsampl_mission """).write.saveAsTable("reliab.dailyBaGPSPath")


# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) 
# MAGIC from reliab.dailyBaGPSPath
# MAGIC group by chassis , startofsampl_mission 
# MAGIC order by count(*)  desc
# MAGIC

# COMMAND ----------

