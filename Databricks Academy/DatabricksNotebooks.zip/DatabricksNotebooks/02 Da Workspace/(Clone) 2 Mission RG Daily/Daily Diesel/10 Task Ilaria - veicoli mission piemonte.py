# Databricks notebook source
from pyspark.sql.functions import col

listaVin = ['ZCFC535D805368224',
 'ZCFC635DX05393901',
 'ZCFCH35A305389320',
 'ZCFCH35A205399658',
 'ZCFC735B505395471',
 'ZCFCB35B805463616',
 'ZCFCH35A905399656',
 'ZCFCH35A805381164',
 'ZCFC735B005372857',
 'ZCFCG35A105409230',
 'ZCFCG35A505409585',
 'ZCFCH35A205402901',
 'ZCFC670D905314698',
 'ZCFCG35AX05360366',
 'ZCFCA70B205321912',
 'ZCFCG35A605422927',
 'ZCFCH35AX05403519',
 'ZCFCG35A005374227',
 'ZCFC670D505321910',
 'ZCFCG35A205334781',
 'ZCFCG35A705368232',
 'ZCFCG35A505372313',
 'ZCFCG35A205391448',
 'ZCFCG35A805386271',
 'ZCFC735B605362110',
 'ZCFC735B905380570',
 'ZCFCH35A005371485',
 'ZCFC735B905321745',
 'ZCFC735B905402468',
 'ZCFCG35A705362107',
 'ZCFCG35A205372057',
 'ZCFCA35B005302681',
 'ZCFC735B505395471',
 'ZCFCE35B805458746',
 'ZCFCH35A005399657']

vehicle = spark.read.table("edwh.vehicle")\
                .filter(col("pvan_cd_vin_code").isin(listaVin))\
                .selectExpr("pvan_cd_vin_code as chassis", "cust_ds_cust_nm_dealer as dealer", "thdb_ds_endcu_org_name endCust")

# COMMAND ----------

display(vehicle.filter(col("endCust")=='  '))

# COMMAND ----------

display(vehicle.selectExpr("*", "case when endCust = '  ' then dealer else endCust end as customer"))

# COMMAND ----------

