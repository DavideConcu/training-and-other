# Databricks notebook source
# MAGIC %md
# MAGIC # Crea Tabelle Riassuntive Mission Specifiche

# COMMAND ----------

pip install geopy

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "TabelleRiassuntiveMissionAree"

nome = database + "." + data + "_" + progetto + "_" + notebook

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tabelle Segnali per Area

# COMMAND ----------

#dataset con le aree
from pyspark.sql.functions import lit

pinerolo = spark.read.table("reliab.20230417_r39_rgdaily_missionareespecifichepiemonte_giaveno").withColumn("path", lit("PINEROLO"))
biella = spark.read.table("reliab.20230418_r39_rgdaily_missionareespecifichepiemonte_biella").withColumn("path", lit("BIELLA"))
sesia = spark.read.table("reliab.20230418_r39_rgdaily_missionareespecifichepiemonte_valdisesia").withColumn("path", lit("SESIA"))
view = spark.read.table("reliab.20230418_r39_rgdaily_missionareespecifichepiemonte_valdiview").withColumn("path", lit("VIU"))
langhe = spark.read.table("reliab.20230419_r39_rgdaily_missionareespecifichepiemonte_langhe").withColumn("path", lit("LANGHE"))
chieri = spark.read.table("reliab.20230420_r39_rgdaily_missionareespecifichepiemonte_chieri").withColumn("path", lit("CHIERI"))


# COMMAND ----------

#df aggregato
from pyspark.sql.functions import col, array

df = pinerolo\
    .unionAll(biella)\
        .unionAll(sesia)\
            .unionAll(view)\
                .unionAll(langhe)\
                    .unionAll(chieri)\
                        .withColumn("latLon", array(col("Latitude"), col("Longitude")))


                                    

# COMMAND ----------

#Load Data
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed').join(listaMission, ["chassis", "missionId"]).distinct()

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")

df.write.saveAsTable(f"{nome}_perProcMeans")

# COMMAND ----------

f"{nome}_perProcMeans"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Lanzo

# COMMAND ----------

#load table
from pyspark.sql.functions import col, upper

lanzo = spark.read.table("reliab.2023_r39_rg_daily_DataMergedWithTabularAndSteering")\
    .filter(col("chassis")== "ZCFCH35A005399657")\
    .filter(col("startDateTime") == "2021-10-20 08:40:54")

# COMMAND ----------



# COMMAND ----------

display(lanzo)

# COMMAND ----------

# MAGIC %md
# MAGIC # Street Info

# COMMAND ----------

pip install geopy

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "streetInfo"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creare la tabella vuota 
# MAGIC

# COMMAND ----------

#schema finale
#schema = 'struct<chassis:string,missionId:string,timestamp:timestamp,latLon:array<decimal(10,5)>,streetInfo:map<string,string>>'
#
##crea tabella vuota
#spark.createDataFrame([], schema).write\
#        #.mode("overWrite")\
#        .saveAsTable(f"{nome}_prova1")
#
#print(f"{nome}_prova1")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scarica StreetInfo e Append 

# COMMAND ----------

schema = 'struct<chassis:string,missionId:string,timestamp:timestamp,latLon:array<decimal(10,5)>,streetInfo:map<string,string>>'

# COMMAND ----------

#tabella da appendere 
tabellaDaAppendere = spark.read.table("reliab.20230421_R39_RGDaily_streetInfo_prova1")

# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#inizializzare il servizio
import random, string

def randomword():
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(5))

locator = Nominatim(user_agent=f"iveCoder{randomword}", timeout=60)
reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)

# COMMAND ----------

#dataset di input contenente tutte le mission (bad) aggregate (circa 950 mila)
from pyspark.sql.functions import col,  array

df = spark.read.table("reliab.20230418_r39_rgdaily_missionareespecifichepiemonte_valdisesia")\
            .selectExpr("chassis", "missionId", "timestamp" ,"array(Latitude, Longitude) as latLon")\
            .join(tabellaDaAppendere, ["chassis", "missionId", "timestamp"], "leftanti")
 

df = df.toPandas()

# COMMAND ----------

for i in range(len(df)):

    #riga singola
    riga = df.loc[i:i+100].copy()
    print("riga: ", i)

    #download street info
    riga["streetInfo"] = riga.apply(lambda row: locator.reverse(row["latLon"]).raw["address"], axis=1)
    print("Street Downloaded")

    #crea la riga come spark df
    rigaSpark = spark.createDataFrame(riga , schema).createOrReplaceTempView("riga")

    #insert into table
    spark.sql("""
    INSERT INTO reliab.20230421_R39_RGDaily_streetInfo_prova1
    (SELECT * FROM riga)
    """)

    print("All done \n")

# COMMAND ----------

#percentuale record univoci
(spark.read.table("reliab.20230421_R39_RGDaily_streetInfo_prova1").select("chassis", "missionId", "timestamp").count() / 
spark.read.table("reliab.20230418_r39_rgdaily_missionareespecifichepiemonte_valdisesia").select("chassis", "missionId", "timestamp").distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolo delle percentuali di Urban, ExtraUrban e Highway

# COMMAND ----------

pip install geopy

# COMMAND ----------

#load table
from pyspark.sql.functions import col, split

df = spark.read.table("reliab.20230421_R39_RGDaily_streetInfo_prova1")

# COMMAND ----------

#### Mappa Strade
def map_streets(road):
    """mappare le strade"""
    import re

    if type(road) == str:

        road1 = re.split(" ", road)[0]
        if len(re.split(" ", road))>1:
            road2 = re.split(" ", road)[1]

        #highway
        patternHigh = r"(^A\d{0,3}\s{0,1}$|^Autostrad|^Svincolo|^Tangenziale|^Diramazione)"
                
        #extraurban
        patternExtr1 = r"(^(SP|SR|SS)\d{0,3}[a-z]*\d*$|Asse|Galleria)"
        patternExtr2 = [r"Strada" , r"^(Provinciale|Regionale|Statale)"]
        
        if re.match(patternHigh, road1):
            streetType = "Highway"

        elif re.match(patternExtr1 , road1) or (type(road2) == str and re.match(patternExtr2[0] , road1) and re.match(patternExtr2[1] , road2)) :
            streetType = "Extra-Urban"
            
        elif road1 == "N.A.":
            streetType = "N.A."
                
        else:
            streetType = "Urban"
                
    else:
        streetType= "N.A."

    return streetType

map_streets_udf = udf(map_streets)

# COMMAND ----------

#apply the function 
df = df.withColumn("streetType", map_streets_udf(col("streetInfo.road")))

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Calcolo distanza tra ogni punto

# COMMAND ----------

from pyspark.sql.functions import  lag, coalesce
from pyspark.sql.window import  Window

df = df.withColumn("lag_latLon", lag('latLon', 1).over(Window.partitionBy('chassis', "missionId").orderBy('timestamp')))\
        .withColumn("lag_latLon", coalesce(col("lag_latlon"), col("latlon")))


# COMMAND ----------

#funzione per calcolare la distanze tra due punti
import geopy.distance

def get_distance(lag_latlon, latlon):
    """ Get distance from point to another """
    distance = geopy.distance.geodesic(lag_latlon,latlon).km
    return distance

distance_udf = udf(get_distance)

# COMMAND ----------

#applica la funzione
df = df.withColumn("distanceKm", distance_udf(col("lag_latlon"), col("latlon")))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sommare i km per tipo di strada

# COMMAND ----------

from pyspark.sql.functions import sum, desc

display(df.groupBy("chassis", "missionId", "streetType").agg(sum(col("distanceKm")).alias("distanceKm")).orderBy("chassis", "missionId", desc("distanceKm")))

# COMMAND ----------

df

# COMMAND ----------

