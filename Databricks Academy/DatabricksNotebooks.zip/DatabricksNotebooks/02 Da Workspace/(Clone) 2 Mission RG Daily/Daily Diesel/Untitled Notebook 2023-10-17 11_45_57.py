# Databricks notebook source
display(spark.read.table("reliab.20230426_r39_rgdaily_tabelleriassuntivemissionaree_allareaspaths"))

# COMMAND ----------

