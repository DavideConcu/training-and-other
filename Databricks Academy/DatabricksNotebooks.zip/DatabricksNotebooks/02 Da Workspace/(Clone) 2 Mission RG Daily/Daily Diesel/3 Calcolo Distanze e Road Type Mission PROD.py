# Databricks notebook source
# MAGIC %md
# MAGIC # Calcolo Distanze Percorsi e Tipo Strada

# COMMAND ----------

pip install geopy

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load Data 

# COMMAND ----------

#load raw data
df = spark.read.table("reliab.dailybagpspath").na.drop("any")

# COMMAND ----------

from pyspark.sql.functions import  lag, coalesce
from pyspark.sql.window import  Window
 
#aggiungere le variabili di lag alt e long
df = df.withColumn("lag_latitude", lag('latitude', 1).over(Window.partitionBy('chassis', "startofsampl_mission").orderBy('timestamp')))
df = df.withColumn("lag_longitude", lag('longitude', 1).over(Window.partitionBy('chassis', "startofsampl_mission").orderBy('timestamp')))

#per il primo record di mission, lag lat = lat iniziale
df = df.withColumn("lag_latitude", coalesce("lag_latitude", "latitude"))
df = df.withColumn("lag_longitude", coalesce("lag_longitude", "longitude"))

#ccordinates
df = df.withColumn("coordinates", array(col("latitude"), col("longitude")))
df = df.withColumn("lag_coordinates", array(col("lag_latitude"), col("lag_longitude")))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Calcolo Distanze

# COMMAND ----------

#to pandas 
dfPd = df.toPandas()

# COMMAND ----------

#calcolo distanza
import geopy.distance

dfPd["distance"] = dfPd.apply(lambda x: geopy.distance.geodesic(x["coordinates"], 
                                                                x["lag_coordinates"]).km, axis = 1) 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Altitude Bin

# COMMAND ----------

#creare la variabile di altitudine per bin
def alt_bin(x):
    ''' crea colonna altitudine categorica'''
    if x <= 300:
        alt = "0m - 300m"
    elif x <= 600:
        alt = "300m - 600m"
    elif x <= 900:
        alt = "600m - 900m"
    else:
        alt = "> 900m"
    return alt
  
dfPd["altitude_bin"] = dfPd.apply(lambda x: alt_bin(x["Altitude"]) , axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract Road Name

# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#inizializzare il servizio
locator = Nominatim(user_agent="iveCoder", timeout=10)
reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)

# COMMAND ----------

#estrarre strada, regione, stato e paese
for riga in range(len(dfPd)):
    
    #coord
    lat = dfPd.loc[riga, "Latitude"]
    lon = dfPd.loc[riga, "Longitude"]
    coord = f"{lat},{lon}"
    
    #estrai dati
    location = locator.reverse(coord).raw
    address = location["address"]
    
    #aggiunge dati al df
    if "road" in address:
        road = address["road"]
        dfPd.loc[riga, "road"] = road 
        print("Road: ", road)
        
    if "county" in address:
        county = address["county"]
        dfPd.loc[riga, "county"] = county 
        print("county: ", county)  

    if "state" in address:
        state = address["state"]
        dfPd.loc[riga, "state"] = state 
        print("state: ", state)  
        
    if "country" in address:
        country = address["country"]
        dfPd.loc[riga, "country"] = country 
        print("country: ", country)    

# COMMAND ----------

#salvare il df
from datetime import date

#crea spark df
missionDf_spark = spark.createDataFrame(dfPd)

missionDf_spark.write.format("delta").mode("overWrite").saveAsTable(f"reliab.dailyRG_MissionPath_{date.today()}")

# COMMAND ----------

