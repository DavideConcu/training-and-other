# Databricks notebook source
# MAGIC %md
# MAGIC # Download and merge Non harsh steering

# COMMAND ----------

#settare il numero di partizioni = al numero di cores
print("cores: ", spark.sparkContext.defaultParallelism)

print("shuffles before: ", spark.conf.get("spark.sql.shuffle.partitions"))

spark.conf.set("spark.sql.shuffle.partitions", spark.sparkContext.defaultParallelism)

print("shuffles after: ", spark.conf.get("spark.sql.shuffle.partitions"))

# COMMAND ----------

#dati con pendenze e variabili
df = spark.read.table("reliab.2023_r39_rg_daily_DataMergedWithTabular")

# COMMAND ----------

#dataset non flat
from pyspark.sql.functions import col, sum

dfRaw = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_prod")\
            .select("chassis", "MissionId", "NameItem", "RangeLimit1", "Accumulator", "Processed_Signals")\
            .filter(col("Processed_Signals")>0)\
            .filter(col("NameItem")=="SafetyHarshSteeringOccurrences_v01")\
            .filter(col("rangelimit1")!= "-15.687, -5")\
            .filter(col("rangelimit1")!= "5, 15.688")\
            .groupBy(["chassis", "MissionId"])\
            .agg(sum(col("accumulator")).alias("sumNonHarshSteering"))\
            .drop("RangeLimit1", "Accumulator" , "Processed_Signals")

# COMMAND ----------

# FATTO!

#left join con il dataframe di base 
#df.join(dfRaw, ["chassis", "missionId"], "left")\
#    .write\
#    .format("delta")\
#    .mode("overwrite")\
#    .option("overwriteSchema", "true")\
#    .saveAsTable("reliab.2023_r39_rg_daily_DataMergedWithTabularAndSteering")

# COMMAND ----------

dfFinal = spark.read.table("reliab.2023_r39_rg_daily_DataMergedWithTabularAndSteering")

# COMMAND ----------

# MAGIC %md
# MAGIC ### prova 2

# COMMAND ----------

from pyspark.sql.functions import col, sum

dfRaw = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_prod")\
            .select("chassis", "MissionId", "NameItem", "RangeLimit1", "Accumulator", "Processed_Signals")\
            .filter(col("Processed_Signals")>0)\
            .filter(col("NameItem")=="SafetyHarshSteeringOccurrences_v01")\
            .filter(col("rangelimit1")!= "-15.687, -5")\
            .filter(col("rangelimit1")!= "5, 15.688")\
            .join(df.select("chassis", "missionId").distinct(), ["chassis", "missionId"], "right")\
            .groupBy(["chassis", "MissionId"])\
            .agg(sum(col("accumulator")).alias("sumNonHarshSteering"))\
            .drop("RangeLimit1", "Accumulator" , "Processed_Signals").explain()

# COMMAND ----------

dfRaw2 = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_prod")\
            .select("chassis", "MissionId", "NameItem", "RangeLimit1", "Accumulator", "Processed_Signals")\
            .filter(col("Processed_Signals")>0)\
            .filter(col("NameItem")=="SafetyHarshSteeringOccurrences_v01")\
            .filter(col("rangelimit1")!= "-15.687, -5")\
            .filter(col("rangelimit1")!= "5, 15.688")\
            .groupBy(["chassis", "MissionId"])\
            .agg(sum(col("accumulator")).alias("sumNonHarshSteering"))\
            .join(df.select("chassis", "missionId").distinct(), ["chassis", "missionId"], "right")\
            .drop("RangeLimit1", "Accumulator" , "Processed_Signals").explain()

# COMMAND ----------

dfRaw == dfRaw2

# COMMAND ----------

