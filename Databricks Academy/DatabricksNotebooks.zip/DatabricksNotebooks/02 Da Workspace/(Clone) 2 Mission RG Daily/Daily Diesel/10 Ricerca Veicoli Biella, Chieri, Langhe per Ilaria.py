# Databricks notebook source
from pyspark.sql.functions import col

vehic = spark.read.table("edwh.vehicle").withColumnRenamed("pvan_cd_vin_code", "chassis")

df = spark.read.table("reliab.20230420_R39_RGDaily_TabelleRiassuntiveMissionAree_perProcMeans")\
            .select("chassis", "path").distinct()
            #.filter(col("path").isin(["CHIERI", "BIELLA", "LANGHE"]))


# COMMAND ----------

from pyspark.sql.functions import col

vehic = spark.read.table("edwh.vehicle").withColumnRenamed("pvan_cd_vin_code", "chassis")

df = spark.read.table("reliab.20230420_R39_RGDaily_TabelleRiassuntiveMissionAree_perProcMeans")\
            .select("chassis", "path").distinct()\
                .filter(~col("path").isin(["VIU"]))\
                    .orderBy(col("path"))


# COMMAND ----------

display(df)

# COMMAND ----------

