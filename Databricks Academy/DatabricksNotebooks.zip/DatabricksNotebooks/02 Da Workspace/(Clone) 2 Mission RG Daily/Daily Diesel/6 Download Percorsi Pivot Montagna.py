# Databricks notebook source
# MAGIC %md
# MAGIC # Scarica Percorsi Pivot Montagna

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "ScaricaPercorsiPivotMontagna"

nome = database + "." + data + "_" + progetto + "_" + notebook

# COMMAND ----------

#load data 
df = spark.read.table("reliab.20230417_r39_rgdaily_scaricamissionbadpiemonte_missionpivotmontagna")

# COMMAND ----------

from pyspark.sql.functions import col, desc
display(df.sort(col("averageSpeed").desc()))

# COMMAND ----------

#lista mission da scaricare
df.select("chassis", "missionid", "startDateTime", "endDateTime").sort(col("averageSpeed").desc()).limit(10).createOrReplaceTempView("listaView")

# COMMAND ----------

# OK!
#spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaView a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startDateTime 
#                      AND b.endOfSampling   <= a.endDateTime """).write.saveAsTable(f"{nome}")
# 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualizzare le Mission

# COMMAND ----------

pip install folium

# COMMAND ----------

from pyspark.sql.functions import collect_list,array

df = spark.read.table('reliab.20230417_R39_RGDaily_ScaricaPercorsiPivotMontagna')\
    .sort("chassis", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId", "startDateTime")\
        .agg(collect_list("latlon").alias("path")).toPandas()

# COMMAND ----------

def addPaths(row):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"] + " " + str(row["startDateTime"]) +  " " + row["missionId"] 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
        popup = popup
    ).add_to(m)  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green')
    ).add_to(m)

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red')
    ).add_to(m)

# COMMAND ----------

import folium

m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

# COMMAND ----------

df.apply(lambda row: addPaths(row), axis=1)

# COMMAND ----------

