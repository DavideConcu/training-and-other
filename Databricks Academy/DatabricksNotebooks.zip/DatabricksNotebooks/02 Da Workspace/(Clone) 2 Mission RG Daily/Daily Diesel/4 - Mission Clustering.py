# Databricks notebook source
# MAGIC %md 
# MAGIC # Mission Clustering
# MAGIC Clusterizzare le mission dei veicoli per scaricare successivamente il percorso completo di alcune mission per cluster

# COMMAND ----------

#reference mission

#1) Lanzo Torinese
refChassisMission1 = "ZCFCH35A005399657 2021-10-20 08:40:54" 

#2) Ivrea
refChassisMission2 = "ZCFCH35A905399656 2022-10-07 09:43:44"

# COMMAND ----------

display(dfSlopes.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Join tra slopes datasc e datacollector flat 

# COMMAND ----------

#dataset con pendenze delle mission
dfSlopes = spark.read.table("reliab.2023_r39_rg_daily_clean")

# COMMAND ----------

#selezione colonne da dati in datacollector_tabular_flat
varList = ["chassis", "missionId", "totalDistance/(totalTime/3600) as averageSpeed",
            "totaltime", 
            "totalTimeDriving/totalTime as percentTimeDriving", 
            "totalTimeIdling/totalTime as percentTimeIdling",
            "totalTimePtoOn/totalTime as percentTimePTOon",
            "totalTimeACC/totalTime as percentTimeACC", 
            "totalTimeBrakePedal/totalTime as percentTimeBrakePedal",
            "totalDistance", 
            "totalDistancePtoOn/totalDistance as percentDistancePtoOn",
            "totalDistanceACC/totalDistance as percentDistanceACC",
            "fuelConsumption/totalDistance as fuelConsumptionDistance", 
            "maxVehicleSpeed",
            "stops/totalDistance as stopsDistance",
            "harshSteering/totalDistance as harshSteeringDistance", 
            "harshBraking/totalDistance as harshBrakingDistance",
            "engineWorkHours"]

dfTabular = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod").selectExpr(varList)


# COMMAND ----------

#settare il numero di partizioni = al numero di cores
print("cores: ", spark.sparkContext.defaultParallelism)

print("shuffles before: ", spark.conf.get("spark.sql.shuffle.partitions"))

spark.conf.set("spark.sql.shuffle.partitions", spark.sparkContext.defaultParallelism)

print("shuffles after: ", spark.conf.get("spark.sql.shuffle.partitions"))

# COMMAND ----------

#inner join con slopes OK
#dfSlopes.join(dfTabular, ["CHAssIs", "MISSIONid"]).write.mode("overwrite").format("delta").saveAsTable("reliab.2023_r39_rg_daily_DataMergedWithTabular")

# COMMAND ----------

#basic cleaning and drop col
#from pyspark.sql.functions import col
#
#dfMerged = (spark.read.table("reliab.2023_r39_rg_daily_DataMergedWithTabular")
#                            .withColumn("averageSpeed", col("averageSpeed")*3600)
#                            .withColumn("avgSpeed_OdoOverWorkhours", col("endOdom")/col("engineWorkHours"))
#                            .drop("gvw_opt")
#                            .drop("missionType"))

#dfMerged.write.mode("overwrite").option("overwriteSChema", "true").saveAsTable("reliab.2023_r39_rg_daily_DataMergedWithTabular")

# COMMAND ----------

from pyspark.sql.functions import col

#input data
dfMerged = spark.read.table("reliab.2023_r39_rg_daily_DataMergedWithTabular")

display(dfMerged.filter(col("chassis")=="ZCFCH35A905399656").filter(col("startDateTime")=="2022-10-07 09:43:44"))

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Download NonHarsh steering occurrencies from datacollector non flat

# COMMAND ----------

#dati con pendenze e variabili
#df = spark.read.table("reliab.2023_r39_rg_daily_DataMergedWithTabular")

# COMMAND ----------

#dataset non flat
#from pyspark.sql.functions import col, sum
#
#dfRaw = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_prod")\
#            .select("chassis", "MissionId", "NameItem", "RangeLimit1", "Accumulator", "Processed_Signals")\
#            .filter(col("Processed_Signals")>0)\
#            .filter(col("NameItem")=="SafetyHarshSteeringOccurrences_v01")\
#            .filter(col("rangelimit1")!= "-15.687, -5")\
#            .filter(col("rangelimit1")!= "5, 15.688")\
#            .groupBy(["chassis", "MissionId"])\
#            .agg(sum(col("accumulator")).alias("sumNonHarshSteering"))\
#            .drop("RangeLimit1", "Accumulator" , "Processed_Signals")


# COMMAND ----------

#left join con il dataframe di base
#df.join(dfRaw, ["chassis", "missionId"], "left")\
#    .write\
#    .format("delta")\
#    .mode("overwrite")\
#    .option("overwriteSchema", "true")
#    .saveAsTable("reliab.2023_r39_rg_daily_DataMergedWithTabularAndSteering")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Calcolare Matrice di distanza con Ref Mission

# COMMAND ----------

#togliere le colonne che non servono al confronto
df = (  spark.read.table("reliab.2023_r39_rg_daily_datamergedwithtabularandsteering")
                .drop("startDateTime", "endDateTime", "time" , "startOdom", "endOdom" , "idlingTime" , "time_driving" , "gpsLat", "gpsLon", "date", "liters")
)

# COMMAND ----------

cols_to_scale = [col for col in df.columns if col not in ["chassis", "MissionId"]]


# COMMAND ----------

cols_to_scale

# COMMAND ----------

from pyspark.ml.feature import StandardScaler
from pyspark.sql.functions import col

# select the columns to standardize
cols_to_scale = [col for col in df.columns if col not in ["chassis", "MissionId"]]



# create a StandardScaler object
scaler = StandardScaler(inputCol="Slope_perc", outputCol="scaled_features", withStd=True, withMean=True)

# apply the scaler to the selected columns
scaled_df = scaler.fit(df.select("Slope_perc")).transform(df).select([col(c).alias(c+"_scaled") for c in cols_to_scale])


# COMMAND ----------

from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.sql.functions import col

# select the columns to standardize
cols_to_scale = [col for col in df.columns if col not in ["chassis", "MissionId"]]

# combine the columns into a vector column
assembler = VectorAssembler(inputCols=cols_to_scale, outputCol="features")
df_with_features = assembler.transform(df)

# create a StandardScaler object
scaler = StandardScaler(inputCol="features", outputCol="scaled_features", withStd=True, withMean=True)

# apply the scaler to the selected columns
scaled_df = scaler.fit(df_with_features).transform(df_with_features).select([col(c).alias(c+"_scaled") for c in cols_to_scale])

# COMMAND ----------

data = df.select(cols_to_scale)

# COMMAND ----------

# MAGIC %scala
# MAGIC import org.apache.spark.mllib.feature.StandardScaler
# MAGIC import org.apache.spark.mllib.linalg.Vectors
# MAGIC
# MAGIC
# MAGIC val data = df.spark.read.table("")
# MAGIC
# MAGIC // Converting RDD[Array] to RDD[Vectors]
# MAGIC val features = data.map(a => Vectors.dense(a))
# MAGIC // Creating a Scaler model that standardizes with both mean and SD
# MAGIC val scaler = new StandardScaler(withMean = true, withStd = true).fit(features)
# MAGIC // Scale features using the scaler model
# MAGIC val scaledFeatures = scaler.transform(features)

# COMMAND ----------

