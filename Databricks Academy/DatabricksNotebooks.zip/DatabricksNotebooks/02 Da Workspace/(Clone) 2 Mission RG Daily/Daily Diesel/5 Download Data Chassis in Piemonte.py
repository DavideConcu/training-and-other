# Databricks notebook source
# MAGIC %md
# MAGIC # Scaricare le mission dei veicoli bad in piemonte

# COMMAND ----------

pip install folium

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "ScaricaMissionBadPiemonte"

nome = database + "." + data + "_" + progetto + "_" + notebook

# COMMAND ----------

#spark.read.csv("dbfs:/FileStore/tables/reliab/veicoli_piemonte.csv", header=True).createOrReplaceTempView("vinView")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Download Data

# COMMAND ----------

##settare il numero di partizioni = al numero di cores
#print("cores: ", spark.sparkContext.defaultParallelism)
#
#print("shuffles before: ", spark.conf.get("spark.sql.shuffle.partitions"))
#
#spark.conf.set("spark.sql.shuffle.partitions", spark.sparkContext.defaultParallelism)
#
#print("shuffles after: ", spark.conf.get("spark.sql.shuffle.partitions"))

# COMMAND ----------

##download data
#query = """SELECT * 
#            FROM datasc.datacollector_daily_tabular_pivot_delta 
#            WHERE vin in (SELECT chassis FROM vinView ) 
#            AND EXTRACT(YEAR FROM startDateTime) >= 2021"""
#
#spark.sql(query).write.saveAsTable(f"reliab.{nome}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pulizia Dataset

# COMMAND ----------

#from pyspark.sql.functions import col, to_date
#
##togliere i duplicati
#df = spark.read.table("reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte").distinct()
#
##rinomina e drop tripd
#df = df.withColumnRenamed("vin", "chassis").drop("tripId", "last_update", "flat", "hilly", "light_mountain", "medium_mountain", #"severe_mountain", "fueltype")
#
##drop se lat e lon sono missing
#df = df.na.drop(subset=["gpslat", "gpslon"])
#
##aggiungere colonna date
#df = df.withColumn("date", to_date("startDateTime"))
#
##tenere se mission di almeno 15 minuti e almeno 1 km
#df = df.filter(col("time")>60*15).filter(col("distance")>1)
#
#df.write.mode("overwrite").option("overwriteschema", "true").saveAsTable("reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte")
#

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join con i dati aggregati di Datacollector

# COMMAND ----------

#dataset con pendenze delle mission
#dfSlopes = spark.read.table("reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte")

# COMMAND ----------

##selezione colonne da dati in datacollector_tabular_flat
#varList = ["chassis", "missionId", "totalDistance/(totalTime/3600) as averageSpeed",
#            "totaltime", 
#            "totalTimeDriving/totalTime as percentTimeDriving", 
#            "totalTimeIdling/totalTime as percentTimeIdling",
#            "totalTimePtoOn/totalTime as percentTimePTOon",
#            "totalTimeACC/totalTime as percentTimeACC", 
#            "totalTimeBrakePedal/totalTime as percentTimeBrakePedal",
#            "totalDistance", 
#            "totalDistancePtoOn/totalDistance as percentDistancePtoOn",
#            "totalDistanceACC/totalDistance as percentDistanceACC",
#            "fuelConsumption/totalDistance as fuelConsumptionDistance", 
#            "maxVehicleSpeed",
#            "stops/totalDistance as stopsDistance",
#            "harshSteering/totalDistance as harshSteeringDistance", 
#            "harshBraking/totalDistance as harshBrakingDistance",
#            "engineWorkHours"]
#
#dfTabular = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod").selectExpr(varList)

# COMMAND ----------

##inner join con slopes 
#dfSlopes.join(dfTabular, ["CHAssIs", "MISSIONid"]).write.mode("overwrite").format("delta").saveAsTable(f"reliab.{nome}#_mergedWithTabular")

# COMMAND ----------

##basic cleaning and drop col
#from pyspark.sql.functions import col
#
#dfMerged = (spark.read.table('reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte_mergedWithTabular')
#                            .withColumn("avgSpeed_OdoOverWorkhours", col("endOdom")/col("engineWorkHours"))
#                            .drop("gvw_opt")
#                            .drop("missionType"))
#
#dfMerged.write.mode("overwrite").option("overwriteSChema", "true").saveAsTable('reliab.#20230413_R39_RGDaily_ScaricaMissionBadPiemonte_mergedWithTabular')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggiungere le sterzate non Harsh

# COMMAND ----------

#dati con pendenze e variabili
#df = spark.read.table("reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte_mergedWithTabular")

# COMMAND ----------

##dataset non flat
#from pyspark.sql.functions import col, sum
#
#dfRaw = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_prod")\
#            .select("chassis", "MissionId", "NameItem", "RangeLimit1", "Accumulator", "Processed_Signals")\
#            .filter(col("Processed_Signals")>0)\
#            .filter(col("NameItem")=="SafetyHarshSteeringOccurrences_v01")\
#            .filter(col("rangelimit1")!= "-15.687, -5")\
#            .filter(col("rangelimit1")!= "5, 15.688")\
#            .groupBy(["chassis", "MissionId"])\
#            .agg(sum(col("accumulator")).alias("sumNonHarshSteering"))\
#            .drop("RangeLimit1", "Accumulator" , "Processed_Signals")
#

# COMMAND ----------

##left join con il dataframe di base
#df.join(dfRaw, ["chassis", "missionId"], "left")\
#    .write\
#    .format("delta")\
#    .mode("overwrite")\
#    .option("overwriteSchema", "true")\
#    .saveAsTable(f"reliab.{nome}_DataMergedWithTabularAndSteering")
#

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filtrare le Mission per Data e Velocità

# COMMAND ----------

##load data e filtra
#from pyspark.sql.functions import col 
#
#df = spark.read.table('reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte_DataMergedWithTabularAndSteering')\
#    .withColumn("sumNonHarshSteeringDistance" , col("sumNonHarshSteering")/col("distance"))\
#    .filter(col("startDateTime") >= "2022-01-01")\
#        .filter(col("averageSpeed")>30)\
#            .filter(col("averageSpeed")<60)\
#                .filter(col("stopsDistance")<1)\
#                    .filter(col("distance")>5)\
#            .drop("avgSpeed_OdoOverWorkhours", "engineWorkHours", "liters", "startOdom", "endOdom", "sumNonHarshSteering")\
#            .write.mode("overWrite").option("overwriteschema", "true").saveAsTable(f"{nome}_clean3060Speed")

# COMMAND ----------

f"{nome}_clean_allSpeed"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Clustering Mission Residue

# COMMAND ----------

#data 
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')

# COMMAND ----------

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")

df = df.toPandas()

# COMMAND ----------

#from sklearn.preprocessing import StandardScaler
#from sklearn.cluster import KMeans
#
#print("start")
#
#colsNOTtoScale =  ["chassis", "missionid", "startdatetime", "enddatetime", "ref_mission_aosta" , "ref_mission_ivrea", "ref_mission_urban", "totaldistance" ]
#numCols = [x for x in df.columns if x.lower() not in colsNOTtoScale ]
#
##elbow rule overall PRE
#X = df.loc[:, numCols].to_numpy()
#scalers = StandardScaler()
#X_std = scalers.fit_transform(X)
#X_std.shape
#
##create list to hold SSE values for each k
#kmeans_kwargs = {
#"init": "random",
#"n_init": 100,
#    "max_iter": 10000
#}
#
#sse = []
#for k in range(1, 50):
#    print("numero clusters: ", k)
#    kmeans = KMeans(n_clusters=k, **kmeans_kwargs)
#    kmeans.fit(X_std)
#    sse.append(kmeans.inertia_)
#    print(f"k-means ok per {k} cluster \n")

# COMMAND ----------

import matplotlib.pyplot as plt

#visualize results
plt.figure(figsize=(15, 5))
plt.plot(range(1, 50), sse)
plt.title("Elbow Rule")
plt.xticks(range(1, 50))
plt.xlabel("Number of Clusters")
plt.ylabel("SSE")
plt.grid()
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## K-Means con numero ideale di Cluster

# COMMAND ----------

df.columns

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

colsNOTtoScale =  ["chassis", "missionid", "startdatetime", "enddatetime", "totaldistance" "gpsLat", "gpsLon", "cluster", "distance"]
numCols = [x for x in df.columns if x.lower() not in colsNOTtoScale ]
numCols = ["averageSpeed", "sumNonHarshSteeringDistance", "stopsDistance" ]

#elbow rule overall PRE
X = df.loc[:, numCols].to_numpy()
scalers = StandardScaler()
X_std = scalers.fit_transform(X)
X_std.shape

kmeans_kwargs = {
"init": "random",
"n_init": 100,
    "max_iter": 10000,
    "random_state": 1
}

NUMEROCLUSTERS = 5

#fit e risultato del clustering
kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
kmeans.fit(X_std)
predicted_kmeans = kmeans.predict(X_std)

#calcolo distanza dal centroide
distance = []
for point in range(len(X_std)):
    clus = predicted_kmeans[point]
    distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

#attaccare label
df.loc[:, "cluster"] = predicted_kmeans.astype(int)
df.loc[:, "distance"] = distance

# COMMAND ----------

df.groupby("cluster").size().sort_values()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plot delle variabili medie nei cluster

# COMMAND ----------

#violin plot
import matplotlib.pyplot as plt
import seaborn as sns

colsNOTtoPlot =  ["chassis", "missionid", "startdatetime", "enddatetime", "ref_mission_aosta" , "ref_mission_ivrea", "ref_mission_urban", "distance", "cluster", "path","method", "percenttimebrakepedal" , "harshsteeringdistance", "percenttimebrakepedal" , "harshbrakingdistance"]

colsToPlot = numCols

for col in colsToPlot:
    print("COL: ", col)
    plt.figure(figsize=(10, 5))
    sns.violinplot(x="cluster", y=col, data=df, palette="coolwarm", inner="quart" , split=True)

    plt.ylabel(col, size=14)
    plt.xlabel("Path", size=14)
    plt.title(f"Eucl. Distance vs K-means: {col}", size=18)
    plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plottare le mission dei cluster

# COMMAND ----------

#creare i layer della mappa
colors = ["blue" , "green", "orange" , "red" , "purple"]

m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

#creare i layer
listaLayers  = []
for cls in set(df.cluster):
    locals()[f"layer_clus_{cls}"] = folium.FeatureGroup(name=f"Cluster {cls}")
    listaLayers.append(locals()[f"layer_clus_{cls}"])

#aggiungere i punti al layer
for cl in set(df.cluster):
    df[df.cluster==cl].groupby("cluster").sample(n=1000).apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001, color= colors[row["cluster"]] , popup = row["MissionId"])
                                             .add_to(listaLayers[cl]), axis=1)    
    listaLayers[cl].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  

#plotta mappa
m  

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

#ok cluster 1

# COMMAND ----------

df = df.loc[df.cluster==1, ["chassis", "MissionId"] ]
chassis = list(df.chassis)
missionId = list(df.MissionId)


# COMMAND ----------

#filtrare il dataframe spark
from pyspark.sql.functions import col

spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')\
    .filter(col("chassis").isin(chassis))\
        .filter(col("missionId").isin(missionId))\
            .write.saveAsTable(f"{nome}_missionPivotMontagna")

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Limitare le Mission al Piemonte

# COMMAND ----------

#1) Controlla la lista delle missionId totali
#2) toglie dalla lista delle missionId le missionId già presenti nella tabella target 
#3) estrae n missionId e ed estrae le info della strada per queste mission
#4) append nella tabella targed di missionId e infoStreet

# COMMAND ----------

pip install geopy

# COMMAND ----------

#load data
from pyspark.sql.functions import col 

df = spark.read.table('reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte_DataMergedWithTabularAndSteering')\
    .filter(col("startDateTime") >= "2022-01-01")

# COMMAND ----------

#seleziona solo una riga per vin 
from pyspark.sql.functions import first, array

df = (df.groupBy("chassis").agg(array(first(col("gpsLat")), first(col("gpsLon"))).alias("coord") ))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Estrarre Regione

# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#inizializzare il servizio
locator = Nominatim(user_agent="iveCoder", timeout=60)
reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)

# COMMAND ----------

import random, string

def getStreetInfo(latLon):
    """Funzione per estrarre le caratteristiche del punto GPS"""

    def randomword():
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(5))

    try:
        locator = Nominatim(user_agent="iveCoder", timeout=10)
        reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)
        streetInfo = locator.reverse(latLon).raw["address"]

        country = streetInfo["country"]
        county = streetInfo["county"]
        state = streetInfo["state"]

        return "{" + "'country' : " + f" \'{country}\' ," +  "'county' : "+ f" \'{county}\'"  +  "'state' : "+ f" \'{state}\'"  +"}"
    
    except:
        locator = Nominatim(user_agent=f"iveCoder{randomword}", timeout=60)
        reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)
        streetInfo = locator.reverse(latLon).raw

        country = streetInfo["country"]
        county = streetInfo["county"]
        state = streetInfo["state"]
        
        return "{" + "'country' : " + f" \'{country}\' ," +  "'county' : "+ f" \'{county}\'"  +  "'state' : "+ f" \'{state}\'"  +"}"


    

#salvare la funzione come Udf
getStreetInfoUdf = udf(getStreetInfo)

# COMMAND ----------

from pyspark.sql.functions import from_json

schema = "country STRING, county STRING, state STRING"

prova = df.limit(10).select("*")\
        .withColumn("streetInfo", from_json(getStreetInfoUdf(col("coord")) , schema))

display(prova)

# COMMAND ----------

# MAGIC %md 
# MAGIC ##Plottare le mission

# COMMAND ----------

pip install folium

# COMMAND ----------

df = spark.read.table('reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte_DataMergedWithTabularAndSteering')

# COMMAND ----------

#load data 
from pyspark.sql.functions import array ,col
import pandas as pd

df = spark.read.table('reliab.20230413_R39_RGDaily_ScaricaMissionBadPiemonte_DataMergedWithTabularAndSteering')\
    .filter(col("startDateTime") >= "2022-01-01")\
    .selectExpr("chassis", "missionId", "gpsLat", "gpsLon")\
        .withColumn("coord", array(col("gpsLat"), "gpsLon"))


dfPd = df.limit(10000).toPandas()

# COMMAND ----------

#inizializzare la mappa
import folium
from folium.plugins import MarkerCluster

m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)
marker_cluster = MarkerCluster(
    name="clustered name",
).add_to(m)



# COMMAND ----------

dfPd.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.00001, popup=row['missionId'])
                                             .add_to(marker_cluster), axis=1)

folium.LayerControl().add_to(m)


# COMMAND ----------

m

# COMMAND ----------

