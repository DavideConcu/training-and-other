# Databricks notebook source
# MAGIC %md
# MAGIC # Download Data Daily RG

# COMMAND ----------

data = "dbfs:/FileStore/tables/reliab/vinBad_RG_DAILY.csv"

#lista vin da scaricare
spark.read.format("csv")\
        .option("header", "true")\
        .option("inferSchema", "true")\
        .load(data)\
        .createOrReplaceTempView("vinView")

# COMMAND ----------

#download data
spark.sql("""SELECT * 
             FROM datasc.datacollector_daily_tabular_pivot_delta 
             WHERE vin in (SELECT chassis FROM vinView ) 
                     AND EXTRACT(YEAR FROM startDateTime) >= 2021""").write.saveAsTable("reliab.2023_R39_RG_Daily")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Puliza Dataset

# COMMAND ----------

from pyspark.sql.functions import col, to_date

#togliere i duplicati
df = spark.read.table("reliab.2023_R39_RG_Daily").distinct()

#rinomina e drop tripd
df = df.withColumnRenamed("vin", "chassis").drop("tripId", "last_update", "flat", "hilly", "light_mountain", "medium_mountain", "severe_mountain", "fueltype")

#drop se lat e lon sono missing
df = df.na.drop(subset=["gpslat", "gpslon"])

#aggiungere colonna date
df = df.withColumn("date", to_date("startDateTime"))

#tenere se mission di almeno 15 minuti e almeno 1 km
df = df.filter(col("time")>60*15).filter(col("distance")>1)

df.write.saveAsTable("reliab.2023_R39_RG_Daily_clean")


# COMMAND ----------

