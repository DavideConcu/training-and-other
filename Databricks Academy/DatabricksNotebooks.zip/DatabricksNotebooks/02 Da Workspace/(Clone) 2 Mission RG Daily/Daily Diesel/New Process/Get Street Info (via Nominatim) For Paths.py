# Databricks notebook source
# MAGIC %md
# MAGIC #Get Street Info
# MAGIC Ottenere info su punto di partenza e arrivo per Mission aggregate via Nominatim
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Installare pacchetti

# COMMAND ----------

pip install geopy

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "streetInfo"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creare la tabella vuota 
# MAGIC

# COMMAND ----------

#schema finale
schema = 'struct<chassis:string,missionId:string,timestamp:timestamp,latLon:array<decimal(10,5)>,streetInfo:map<string,string>>'

##crea tabella vuota
#spark.createDataFrame([], schema).write\
#        .mode("overWrite")\
#        .saveAsTable(f"{nome}_allAreasPaths")
#
#print(f"{nome}_allAreasPaths")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scarica StreetInfo e Append 

# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#inizializzare il servizio
import random, string

def randomword():
    """ Crea parola random """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(5))

def initialize_service():
    """ Inizializza il servizio di Nominatim """
    locator = Nominatim(user_agent=f"iveCoder{randomword}", timeout=60)
    reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)
    return locator, reverseGeocode
    

# COMMAND ----------

def dowloadStreetInfo(riga):
    """ Download e append to target table """

    #download street info
    riga["streetInfo"] = riga.apply(lambda row: locator.reverse(row["latLon"]).raw["address"], axis=1)
    print("Street Downloaded")

    #crea la riga come spark df
    rigaSpark = spark.createDataFrame(riga , schema).createOrReplaceTempView("riga")

    #insert into table
    spark.sql("""
    INSERT INTO ${targetTableName}
    (SELECT * FROM riga) 
    """)

# COMMAND ----------

# Caricare le tabelle di input e target e inizializzare il servizio

spark.conf.set('targetTableName','reliab.20230426_R39_RGDaily_streetInfo_allAreasPaths')


#target table
targetTable = spark.read.table("reliab.20230426_R39_RGDaily_streetInfo_allAreasPaths")


#load Input table
inputTable = spark.read.table("reliab.20230426_r39_rgdaily_tabelleriassuntivemissionaree_allareaspaths")\
                    .select("chassis", "missionId", "timestamp", "latLon")\
                    .join(targetTable, ["chassis", "missionId", "timestamp"], "leftanti").toPandas()

#inizializzare il servizio
locator, reverseGeocode = initialize_service()

# COMMAND ----------

# loop di scariamento street info (riga per riga)

for i in range(len(inputTable)):

    #riga singola
    riga = inputTable.loc[i:i].copy()
    print("riga: ", i)

    try:
        #download street info
        dowloadStreetInfo(riga)
        
        print("Righe Mancanti: ", len(inputTable) - i , "\n")

    except:
        print("!!!! SOMETHING WENT WRONG - RE-INITIALIZE!!!")

        #re- inizializza il servizio
        locator, reverseGeocode = initialize_service()
        
        #download street info
        dowloadStreetInfo(riga)

        print("!!!OK!!! \n")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join della tabella con Street Info con Tabella di input (contenente le altre info)

# COMMAND ----------

#input table
inputTable = spark.read.table("reliab.20230426_r39_rgdaily_tabelleriassuntivemissionaree_allareaspaths")

#target table
targetTable = spark.read.table("reliab.20230426_R39_RGDaily_streetInfo_allAreasPaths").drop("latLon")

#join 
joined = inputTable.join(targetTable, ["chassis", "missionId", "timestamp"])

#salvare la tabella
#joined.write.saveAsTable(f"{nome}_Final")

print(f"{nome}_Final")

# COMMAND ----------

#Sample.coalesce(1).write.format(“com.databricks.spark.csv”).option(“header”, “true”).save(“dbfs:/FileStore/df/Sample.csv”)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova Pandas

# COMMAND ----------

#input table
df = spark.read.table("reliab.20230426_r39_rgdaily_tabelleriassuntivemissionaree_allareaspaths").toPandas()

# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

#inizializzare il servizio
import random, string

def randomword():
    """ Crea parola random """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(5))

def initialize_service():
    """ Inizializza il servizio di Nominatim """
    locator = Nominatim(user_agent=f"iveCoder{randomword}", timeout=60)
    reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)
    return locator, reverseGeocode
    
#inizializzare il servizio
locator, reverseGeocode = initialize_service()

# COMMAND ----------

df2 = df.apply(lambda row: locator.reverse(row["latLon"]).raw["address"], axis=1)