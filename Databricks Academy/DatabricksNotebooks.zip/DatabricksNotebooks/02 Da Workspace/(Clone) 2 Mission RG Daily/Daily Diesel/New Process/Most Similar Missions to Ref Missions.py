# Databricks notebook source
# MAGIC %md
# MAGIC # Get Most Similar Missions to Ref Missions

# COMMAND ----------

#output data spec
from datetime import date 

data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "GetMostSimilarMissionsToRefMissions"

name = data + "_" + progetto + "_" + notebook

# COMMAND ----------

#Load input data 
df = spark.read.table("reliab.2023_r39_rg_daily_datamergedwithtabularandsteering")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleaning

# COMMAND ----------

#features da eliminare
colsToDrop = ["date", "gpsLat", "gpslon",
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Assign Reference Mission Bool

# COMMAND ----------

from pyspark.sql.functions import col

#reference mission condition
refMissionCondition_AOSTA = (col("chassis") == "ZCFCH35A005399657") & (col("startDateTime") == "2021-10-21 03:56:17")
refMissionCondition_IVREA = (col("chassis") == "ZCFCH35A905399656") & (col("startDateTime") == "2022-10-07 09:43:44")
refMissionCondition_URBAN = (col("chassis") == "ZCFCL35A205452289") & (col("startDateTime") == "2022-04-21 07:21:09")

#add boolean column
df  =    df.withColumn("Ref_Mission_AOSTA" , refMissionCondition_AOSTA)\
           .withColumn("Ref_Mission_IVREA" , refMissionCondition_IVREA)\
           .withColumn("Ref_Mission_URBAN" , refMissionCondition_URBAN)


# COMMAND ----------

# MAGIC %md 
# MAGIC ## K-means Clustering

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1) Scaling

# COMMAND ----------

#prima di tutto è necessario standardizzare le colonne da usare per il clustering 
from pyspark.ml.feature import MinMaxScaler, StandardScaler
from pyspark.ml.feature import VectorAssembler

#features da usare per il clustering

colsNOTtoScale =  ["chassis", "missionid", "startdatetime", "enddatetime", "ref_mission_aosta" , "ref_mission_ivrea", "ref_mission_urban" ]
colsToScale = [x for x in df.columns if x.lower() not in colsNOTtoScale]

#assembler per creare il vettore delle features
vecAssemblerScaling = VectorAssembler().setInputCols(colsToScale).setOutputCol("features")

#df con le features assemblate
df_assemblato = vecAssemblerScaling.transform(df)


#istanza dello scaler
scaler = StandardScaler(inputCol="features", outputCol="scaledFeatures")
scaler_model = scaler.fit(df_assemblato.select("features"))

df_scaled = scaler_model.transform(df_assemblato)\
                    .drop("features")\
                    .withColumnRenamed("scaledFeatures", "features")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2) Clustering Loop per trovare le n mission più simili

# COMMAND ----------

##Clustering loop to obtain the n most similar missions to ref mission
#from pyspark.sql.functions import lit
#from pyspark.ml.clustering import KMeans
#
#
#numeroMissionSimili = 100
#
#
#if "prediction" in df_scaled.columns:
#    df_scaled = df_scaled.drop("prediction")
#
#
##schema del df finale contenente tutte le mission simili delle 3 ref
#schema = df_scaled.limit(1).withColumn("refMission" , lit("juva")).schema
#all_df_cluster = sqlContext.createDataFrame(sc.emptyRDD(), schema)
#
#for refMissionCol in ["Ref_Mission_AOSTA", "Ref_Mission_IVREA", "Ref_Mission_URBAN"]:
#
#    df_cluster = df_scaled
#
#    while True:
#
#        #k means 
#        kmeans = KMeans(k=2, seed = 1)  # 2 clusters here
#        model = kmeans.fit(df_cluster.select('features'))
#        df_cluster = model.transform(df_cluster)
#
#        #prendere il valore di cluster della mission di riferimento
#        refCluster = df_cluster.where(col(refMissionCol) == True).select("prediction").collect()[0]["prediction"]
#
#        #keep delle obs nello stesso cluster
#        df_cluster = df_cluster.where(col("prediction") == refCluster).drop("prediction")
#
#        #numero obs nel cluster
#        nObs = df_cluster.count()
#        print(nObs)
#
#        if nObs <= numeroMissionSimili:
#
#            df_cluster = df_cluster.withColumn("refMission" , lit(refMissionCol))
#
#            break
#    
#    #unire il df della ref mission di ognuno dei tre tipi
#    all_df_cluster = all_df_cluster.unionAll(df_cluster)
#    

# COMMAND ----------

##salvare il dataset come tabella con il cluster OK!
#
#from datetime import date
#
#all_df_cluster.write.format("delta").mode("overwrite").saveAsTable(f"reliab.{date.today().strftime('%Y%m%d')}_{progetto}_{parte}_{numeroMissionSimili}#kmeansClus3Paths")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2) modo 2 - calcolare distanza euclidea con la ref mission e selezionare le n più vicine

# COMMAND ----------

#PROVA
#import pyspark.sql.functions as F
#from pyspark.sql.types import FloatType
#from scipy.spatial import distance
#
#aosta = all_df_cluster.where(col("refMission") == "Ref_Mission_AOSTA")
#refMissionValues = aosta.where(col("Ref_Mission_AOSTA")==True).select("features").collect()
#
#fixed_entry = refMissionValues
#distance_udf = F.udf(lambda x: float(distance.euclidean(x, fixed_entry)), FloatType())
#aosta = aosta.withColumn('distances', distance_udf(F.col('features')))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Distanza euclidea per TUTTE le 950 mila mission

# COMMAND ----------

from  pyspark.sql.functions import udf, lit, col
from pyspark.sql.types import FloatType
from scipy.spatial import distance

df = df_scaled

for path in ["AOSTA", "IVREA", "URBAN"]:

    refMiss = f"Ref_Mission_{path}"

    #trova il punto della ref mission 
    refMissionPoint = df.where(col(refMiss)==True).select("features").collect()

    #definisce funzione di calcolo distanza euclidea
    distance_udf = udf(lambda x: float(distance.euclidean(x, refMissionPoint)),  FloatType())

    #calcolo distanze con tutte le altre mission
    df = df.withColumn(f'distance_{path}', distance_udf(col('features')))


# COMMAND ----------

#salvare il dataset con tutte le distanze
#df.write.format("delta").mode("overwrite").saveAsTable(f"reliab.{name}_allMissionsWithDistances")

# COMMAND ----------

##df delle n mission più simili per percorso
#n = 100
#dfAosta = df.drop("features", "distance_IVREA", "distance_URBAN").withColumnRenamed("distance_AOSTA", "distance").sort("distance").limit(n).withColumn("path" , lit#("AOSTA"))
#dfIvrea = df.drop("features", "distance_AOSTA", "distance_URBAN").withColumnRenamed("distance_IVREA", "distance").sort("distance").limit(n).withColumn("path" , lit#("IVREA"))
#dfUrban = df.drop("features", "distance_AOSTA", "distance_IVREA").withColumnRenamed("distance_URBAN", "distance").sort("distance").limit(n).withColumn("path" , lit#("URBAN"))
#
##tutte insieme
#dfMostSimilarMissions = dfAosta.unionAll(dfIvrea).unionAll(dfUrban)
#
#dfMostSimilarMissions\
#    .write\
#    .format("delta")\
#        .mode("overwrite")\
#            .option("overwriteschema", "true")\
#            .saveAsTable(f"reliab.{name}_{n}MostSimilarMissions3Paths")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plot del risultato

# COMMAND ----------

#load data from previous step to PANDAS
#df = spark.read.table("reliab.20230403_r39_rgdaily_getmostsimilarmissionstorefmissions_100mostsimilarmissions3paths").drop("distance").toPandas()

# COMMAND ----------

#from pyspark.sql.functions import when, col
#
##dataset con i cluster trovati tramite k-means
#dfKmeans = spark.read.table("reliab.20230403_r39_rgdaily_getmostsimilarmissionstorefmissions_100kmeansclus3paths")
#
##togliere var inutili e aggiungere path
#dfKmeans = dfKmeans.withColumn("path", when(col("refMission") == "Ref_Mission_URBAN", "URBAN")
#                           .when(col("refMission") == "Ref_Mission_AOSTA", "AOSTA")
#                           .otherwise("IVREA")).drop("refMission", "features").toPandas()
#

# COMMAND ----------

##df con i cluster in entrambi i modi
#import pandas as pd 
#
##aggiungere metodo 
#df["method"] = "EUCLIDEAN"
#dfKmeans["method"] = "K-MEANS"
#
#df = pd.concat([df, dfKmeans], axis = 0)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### 1) prova: prendere il cluster con le n mission più simili e confrontare con un violin plot un campione casuale di n mission riguardo le variabili usate per il clustering

# COMMAND ----------

##violin plot
#import matplotlib.pyplot as plt
#import seaborn as sns
#
#colsNOTtoPlot =  ["chassis", "missionid", "startdatetime", "enddatetime", "ref_mission_aosta" , "ref_mission_ivrea", "ref_mission_urban", "distance", "path","method",
#                        "percenttimebrakepedal" , "harshsteeringdistance", "percenttimebrakepedal" , "harshbrakingdistance"]
#colsToPlot = [x for x in df.columns if x.lower() not in colsNOTtoPlot]
#
#for col in colsToPlot:
#    print("COL: ", col)
#    plt.figure(figsize=(10, 5))
#    sns.violinplot(x="path", y=col, data=df, hue = "method" , palette="coolwarm", inner="quart" , split=True)
#
#    plt.ylabel(col, size=14)
#    plt.xlabel("Path", size=14)
#    plt.title(f"Eucl. Distance vs K-means: {col}", size=18)
#    plt.show()