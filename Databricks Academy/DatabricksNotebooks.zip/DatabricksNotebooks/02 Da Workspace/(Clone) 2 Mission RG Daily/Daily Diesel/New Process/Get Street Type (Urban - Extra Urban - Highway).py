# Databricks notebook source
# MAGIC %md
# MAGIC #Get Street Type 
# MAGIC Ottenere info su punto di partenza e arrivo per Mission aggregate via Nominatim
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Installare pacchetti

# COMMAND ----------

pip install geopy

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "GetStreetType"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolo delle percentuali di Urban, ExtraUrban e Highway

# COMMAND ----------

#input data
df = spark.read.table("reliab.20230427_R39_RGDaily_streetInfo_Final")

# COMMAND ----------

display(df.limit(10))

# COMMAND ----------

#Mappare le strade
from pyspark.sql.functions import col, split

#### Mappa Strade
def map_streets(road):
    """mappare le strade"""
    import re

    if type(road) == str:

        road1 = re.split(" ", road)[0]
        if len(re.split(" ", road))>1:
            road2 = re.split(" ", road)[1]
        else:
            road2 = None

        #highway
        patternHigh = r"(^A\d{0,3}\s{0,1}$|^Autostrad|^Svincolo|^Tangenziale|^Diramazione|Raccordo)"
                
        #extraurban
        patternExtr2 = [r"Strada|Via" , r"^(Provinciale|Regionale|Statale)"]
        
        if re.match(patternHigh, road1):
            streetType = "Highway"

        elif re.match(patternExtr1 , road1) or (type(road2) == str and re.match(patternExtr2[0] , road1) and re.match(patternExtr2[1] , road2)) :
            streetType = "Extra-Urban"
            
        elif road1 == "N.A.":
            streetType = "N.A."
                
        else:
            streetType = "Urban"
                
    else:
        streetType= "N.A."

    return streetType

map_streets_udf = udf(map_streets)



#apply the function 
df = df.withColumn("streetType", map_streets_udf(col("streetInfo.road")))

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Calcolo distanza tra ogni punto

# COMMAND ----------

#agiungere i lag della posiziome

from pyspark.sql.functions import  lag, coalesce
from pyspark.sql.window import  Window

df = df.withColumn("lag_latLon", lag('latLon', 1).over(Window.partitionBy('chassis', "missionId").orderBy('timestamp')))\
        .withColumn("lag_latLon", coalesce(col("lag_latlon"), col("latlon")))


#funzione per calcolare la distanze tra due punti
import geopy.distance

def get_distance(lag_latlon, latlon):
    """ Get distance from point to another """
    distance = geopy.distance.geodesic(lag_latlon,latlon).km
    return distance

distance_udf = udf(get_distance)


#applica la funzione
df = df.withColumn("distanceKm", distance_udf(col("lag_latlon"), col("latlon")))


# COMMAND ----------

# MAGIC %md
# MAGIC ## Sommare i km per tipo di strada e Altitudine

# COMMAND ----------

from pyspark.sql.functions import sum, desc


display(df.join(df.groupBy("path").agg(sum("distanceKm").alias("totalKm")), "path")\
        .groupBy("path", "streetType")\
        .agg(sum(  (col("distanceKm"))/col("totalKm") ).alias("distanceKm")).orderBy("path", desc("distanceKm")))

# COMMAND ----------

from pyspark.sql.functions import split

display(df.select("streetinfo.road", "streetType").filter(col("streetType")=="Urban").withColumn("k", split( col("road"), " ")[0]).select("k").distinct())

# COMMAND ----------

display(df.select("path", "missionid").distinct().groupBy("path").count())

# COMMAND ----------



# COMMAND ----------

