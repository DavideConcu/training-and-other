# Databricks notebook source
# MAGIC %md 
# MAGIC # Validare il Metodo 

# COMMAND ----------

#output data spec
from datetime import date 

data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "GetMostSimilarMissionsToRefMissions_validareIlMetodo"

name = data + "_" + progetto + "_" + notebook

# COMMAND ----------

#input data 
df = spark.read.table("reliab.20230405_r39_rgdaily_getmostsimilarmissionstorefmissions_allmissionswithdistances")

# COMMAND ----------

##aggiungere il percorso più vicino
#from pyspark.sql.functions import col, least, when
#
#df = df.withColumn("closerPath", 
#                                    when(col("distance_AOSTA")==least( col("distance_AOSTA"), col("distance_IVREA"), col("distance_URBAN")), "AOSTA")
#                                   .when(col("distance_IVREA")==least( col("distance_AOSTA"), col("distance_IVREA"), col("distance_URBAN")), "IVREA")
#                                   .otherwise("URBAN"))

# COMMAND ----------

#df.write.format("delta").mode("overwrite").option("overwriteschema", "true").saveAsTable("reliab.20230405_r39_rgdaily_getmostsimilarmissionstorefmissions_allmissionswithdistances")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcolare distanze tra i tre pivot OK

# COMMAND ----------

from pyspark.sql.functions import col 

dfPivot = df.where((col("Ref_Mission_AOSTA")==True) | (col("Ref_Mission_IVREA")==True) | (col("Ref_Mission_URBAN")==True))

# COMMAND ----------

PivotMatrix = dfPivot.selectExpr("closerPath as Pivot", "distance_AOSTA as distanceToAosta", "distance_IVREA as distanceToIvrea", "distance_URBAN as distanceToUrban").sort("distanceToAosta")

#PivotMatrix.write.saveAsTable(f"reliab.{name}_PivotDistancesMatrix")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Limitare il numero di mission usando distanza tra pivot più vicino

# COMMAND ----------

df.groupBy("closerPath").count().show()

# COMMAND ----------

display(PivotMatrix)

# COMMAND ----------

from pyspark.sql.functions import least

raggioAosta = PivotMatrix.where(col("pivot")=="AOSTA").withColumn("minDistance", least(col("distanceToIvrea"), col("distanceToUrban"))).select("minDistance").collect()[0]["minDistance"]

raggioIvrea = PivotMatrix.where(col("pivot")=="IVREA").withColumn("minDistance", least(col("distanceToAosta"), col("distanceToUrban"))).select("minDistance").collect()[0]["minDistance"]

raggioUrban = PivotMatrix.where(col("pivot")=="URBAN").withColumn("minDistance", least(col("distanceToAosta"), col("distanceToIvrea"))).select("minDistance").collect()[0]["minDistance"]

# COMMAND ----------

df = df.withColumn("distance", least(col("distance_AOSTA") , col("distance_IVREA"), col("distance_URBAN")))

# COMMAND ----------

#limitare il numero di mission per pivot
from pyspark.sql.functions import when

soglia = 0.3

dfFiltered = df.withColumn("keep" , 
                                when((col("closerPath") == "AOSTA") & (col("distance")<= raggioAosta*soglia) , True )
                                .when((col("closerPath") == "IVREA") & (col("distance")<= raggioIvrea*0.1) , True )
                                .when((col("closerPath") == "URBAN") & (col("distance")<= raggioUrban*soglia) , True )
                                .otherwise(False)

).where(col("keep")==True).drop("keep").drop("features", "distance_AOSTA", "distance_IVREA", "distance_URBAN").sort("closerPath", "distance")

# COMMAND ----------

#salvataggio del file 
dfFiltered.write.saveAsTable(f"reliab.{name}_validatedMissions")

# COMMAND ----------

dfFiltered.groupBy("closerPath").count().sort("count").show()

# COMMAND ----------

display(dfFiltered)