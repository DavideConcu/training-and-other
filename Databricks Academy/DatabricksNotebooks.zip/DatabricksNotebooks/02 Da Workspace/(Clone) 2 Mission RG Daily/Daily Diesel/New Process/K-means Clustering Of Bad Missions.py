# Databricks notebook source
# MAGIC %md
# MAGIC # Clustering delle Mission Bad

# COMMAND ----------

#output data spec
from datetime import date 

data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "kMeansClusteringBadMissions"

name = data + "_" + progetto + "_" + notebook

# COMMAND ----------

#Load input data 
df = spark.read.table("reliab.2023_r39_rg_daily_datamergedwithtabularandsteering")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1) Cleaning 

# COMMAND ----------

#features da eliminare
colsToDrop = ["date", "gpsLat", "gpslon",
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")

df = df.toPandas()

# COMMAND ----------

# MAGIC %md 
# MAGIC #### 2) Elbow Rule per trovare il numero di cluster

# COMMAND ----------

#from sklearn.preprocessing import StandardScaler
#from sklearn.cluster import KMeans
#
#print("start")
#
#colsNOTtoScale =  ["chassis", "missionid", "startdatetime", "enddatetime", "ref_mission_aosta" , "ref_mission_ivrea", "ref_mission_urban" ]
#numCols = [x for x in df.columns if x.lower() not in colsNOTtoScale ]
#
##elbow rule overall PRE
#X = df.loc[:, numCols].to_numpy()
#scalers = StandardScaler()
#X_std = scalers.fit_transform(X)
#X_std.shape
#
##create list to hold SSE values for each k
#kmeans_kwargs = {
#"init": "random",
#"n_init": 100,
#    "max_iter": 10000
#}
#
#sse = []
#for k in range(1, 50):
#    print("numero clusters: ", k)
#    kmeans = KMeans(n_clusters=k, **kmeans_kwargs)
#    kmeans.fit(X_std)
#    sse.append(kmeans.inertia_)
#    print(f"k-means ok per {k} cluster \n")

# COMMAND ----------

import matplotlib.pyplot as plt

#visualize results
plt.figure(figsize=(15, 5))
plt.plot(range(1, 50), sse)
plt.title("Elbow Rule")
plt.xticks(range(1, 50))
plt.xlabel("Number of Clusters")
plt.ylabel("SSE")
plt.grid()
plt.show()

# COMMAND ----------

#salvare il file con gli SSE
#import pandas as pd
#sseDf = pd.DataFrame(sse , columns=["SSE"])
#clusDf = pd.DataFrame(range(2,51), columns=["Num Clusters"])

#save results
#pd.concat( [clusDf, sseDf] , axis = 1).to_csv("/dbfs/FileStore/tables/reliab/eelbowRule.csv", index = False)
#sseDf = pd.read_csv("/dbfs/FileStore/tables/reliab/eelbowRule.csv")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Effettuare K-means con numero di cluster ottimale

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

colsNOTtoScale =  ["chassis", "missionid", "startdatetime", "enddatetime", "ref_mission_aosta" , "ref_mission_ivrea", "ref_mission_urban" ]
numCols = [x for x in df.columns if x.lower() not in colsNOTtoScale ]

#elbow rule overall PRE
X = df.loc[:, numCols].to_numpy()
scalers = StandardScaler()
X_std = scalers.fit_transform(X)
X_std.shape

kmeans_kwargs = {
"init": "random",
"n_init": 100,
    "max_iter": 10000
}

NUMEROCLUSTERS = 17

#fit e risultato del clustering
kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
kmeans.fit(X_std)
predicted_kmeans = kmeans.predict(X_std)

#calcolo distanza dal centroide
distance = []
for point in range(len(X_std)):
    clus = predicted_kmeans[point]
    distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

#attaccare label
df.loc[:, "cluster"] = predicted_kmeans.astype(int)
df.loc[:, "distance"] = distance

# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare i centroidi del clustering 

# COMMAND ----------

#centroidi
import pandas as pd 

#salvare i centroid
kMeansClusterCenters = kmeans.cluster_centers_

#trasformo in pandas df
clusterCentersDf = pd.DataFrame(kMeansClusterCenters, columns = numCols )

#creo spark df
clusterCentersSparkDf = spark.createDataFrame(clusterCentersDf)

# COMMAND ----------

#assemblare le features del centroide 
from pyspark.ml.feature import MinMaxScaler, StandardScaler
from pyspark.ml.feature import VectorAssembler

#features da usare per il clustering
colsToScale = clusterCentersSparkDf.columns

#assembler per creare il vettore delle features centroidi
vecAssemblerScaling = VectorAssembler().setInputCols(colsToScale).setOutputCol("kMeansCentroids")

#df con i centroidi assemblati
dfCentroidiCluster_assemblato = vecAssemblerScaling.transform(clusterCentersSparkDf)


# COMMAND ----------

#salvare il df con i centroidi dei cluster
dfCentroidiCluster_assemblato.write.format("delta").saveAsTable(f"reliab.{name}_OnlyClusterCentroids_{NUMEROCLUSTERS}Clus")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Salvare il Df con tutte le mission con cluster label (non serve)

# COMMAND ----------

#salvare il dataset come tabella con il cluster OK!

#from datetime import date

#convertire in spark dataframe 
#df_spark = spark.createDataFrame(df)

#df_spark.write.format("delta").mode("overwrite").saveAsTable(f"reliab.{name}_AllMissions10clus")