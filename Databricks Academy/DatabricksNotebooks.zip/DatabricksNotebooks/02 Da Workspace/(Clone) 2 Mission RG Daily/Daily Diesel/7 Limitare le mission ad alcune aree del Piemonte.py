# Databricks notebook source
# MAGIC %md
# MAGIC # Limitare Mission Bad Aree Piemonte

# COMMAND ----------

pip install folium

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "R39_RGDaily"
notebook = "MissionAreeSpecifichePiemonte"

nome = database + "." + data + "_" + progetto + "_" + notebook

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Data

# COMMAND ----------

#Load Data
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")

#df = df.toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Definire le Aree di interesse

# COMMAND ----------

# Area Giaveno:
nw = [45.170614,7.033845]
sw = [44.661034,7.041002]
ne = [45.162868,7.362566]
se = [44.688378,7.469755]

maxLat = min(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = min(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]



# COMMAND ----------

from pyspark.sql.functions import col, lit

df = df\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("GIAVENO"))#.toPandas()

# COMMAND ----------

display(df.select("chassis").distinct())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualizzare le Mission 

# COMMAND ----------

#aggiungere il poligono alla mappa 
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

line_color='gray'
fill_color='gray'
weight=2
text='Giaveno'

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight, popup=(folium.Popup(text))))


df.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 , popup = row["MissionId"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Clustering delle Mission dell'area

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

colsNOTtoScale =  ["chassis", "missionid", "startdatetime", "enddatetime", "totaldistance" "gpsLat", "gpsLon", "cluster", "distance"]
numCols = [x for x in df.columns if x.lower() not in colsNOTtoScale ]
numCols = ["averageSpeed", "sumNonHarshSteeringDistance", "stopsDistance", "Slope_perc" ]

#elbow rule overall PRE
X = df.loc[:, numCols].to_numpy()
scalers = StandardScaler()
X_std = scalers.fit_transform(X)
X_std.shape

kmeans_kwargs = {
"init": "random",
"n_init": 100,
    "max_iter": 10000,
    "random_state": 1
}

NUMEROCLUSTERS = 3

#fit e risultato del clustering
kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
kmeans.fit(X_std)
predicted_kmeans = kmeans.predict(X_std)

#calcolo distanza dal centroide
distance = []
for point in range(len(X_std)):
    clus = predicted_kmeans[point]
    distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

#attaccare label
df.loc[:, "cluster"] = predicted_kmeans.astype(int)
df.loc[:, "distance"] = distance

# COMMAND ----------

#violin plot
import matplotlib.pyplot as plt
import seaborn as sns


colsToPlot = numCols

for col in colsToPlot:
    print("COL: ", col)
    plt.figure(figsize=(10, 5))
    sns.violinplot(x="cluster", y=col, data=df, palette="coolwarm", inner="quart" , split=True)

    plt.ylabel(col, size=14)
    plt.xlabel("Cluster", size=14)
    plt.title(f"{col}", size=18)
    plt.show()

# COMMAND ----------

df.groupby("cluster").size()

# COMMAND ----------

#creare i layer della mappa
colors = ["blue" , "red", "green" , "red" , "purple"]

m = folium.Map(location=(NW[0]+SE[0]/2, NW[1]+SW[1]/2), zoom_start=13)

line_color='gray'
fill_color='gray'
weight=2
text='Giaveno'

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight, popup=(folium.Popup(text))))

#creare i layer
listaLayers  = []
for cls in set(df.cluster):
    locals()[f"layer_clus_{cls}"] = folium.FeatureGroup(name=f"Cluster {cls}")
    listaLayers.append(locals()[f"layer_clus_{cls}"])

#aggiungere i punti al layer
for cl in set(df.cluster):
    df[df.cluster==cl]\
        .apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 ,  popup = row["MissionId"])
                                             .add_to(listaLayers[cl]), axis = 1)    
    listaLayers[cl].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  

#plotta mappa
m  

# COMMAND ----------

sampledDf = df.groupby("cluster").sample(frac=0.02).reset_index()
sampledDf.groupby("cluster").size()

# COMMAND ----------

#creare i layer della mappa
colors = ["blue" , "red", "green" , "red" , "purple"]

m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

line_color='gray'
fill_color='gray'
weight=2
text='Giaveno'

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight, popup=(folium.Popup(text))))

#creare i layer
listaLayers  = []
for cls in set(sampledDf.cluster):
    locals()[f"layer_clus_{cls}"] = folium.FeatureGroup(name=f"Cluster {cls}")
    listaLayers.append(locals()[f"layer_clus_{cls}"])

#aggiungere i punti al layer
for cl in set(sampledDf.cluster):
    sampledDf[sampledDf.cluster==cl]\
        .apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 , color=colors[cl], popup = row["MissionId"])
                                             .add_to(listaLayers[cl]), axis = 1)    
    listaLayers[cl].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  

#plotta mappa
m  

# COMMAND ----------

# MAGIC %md
# MAGIC ## Download dei percorsi Estratti

# COMMAND ----------

#download percorsi completi per i percorsi estratti
area = "GIAVENO"

#spark.createDataFrame(sampledDf.loc[: , ["chassis", "MissionId", "startDateTime", "endDateTime"]]).createOrReplaceTempView("listaPercorsiView")

# COMMAND ----------

##download Percorsi OK!
#spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaPercorsiView a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startDateTime 
#                      AND b.endOfSampling   <= a.endDateTime """).write.saveAsTable(f"{nome}_{area}")
# 

# COMMAND ----------

f"{nome}_{area}"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Vedere i Percorsi estratti

# COMMAND ----------

from pyspark.sql.functions import array, col , collect_list

#missionRotte = ["944130f4-5af2-406a-a895-9b1e3cbbdb14", "944130f4-5af2-406a-a895-9b1e3cbbdb14", "aac8b944-0519-45c4-ae70-ea8c3224e410"]

df = spark.read.table('reliab.20230417_R39_RGDaily_MissionAreeSpecifichePiemonte_GIAVENO')\
        .sort("missionid", "timestamp")\
        .filter(col("chassis") != "ZCFCG35A805331982")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
        popup = popup
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popup
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popup
    ).add_to(listaLayers[num])

# COMMAND ----------

import folium
colors = ["blue" , "red", "green" , "red" , "purple"]


#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2
text='Giaveno'

edges = [NW, NE, SE, SW]


#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])



#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Dettagli Mission scelte

# COMMAND ----------

mId = ["afd43f92-a023-4416-92f8-c3d1d35f7936",
        "701afad5-0f07-45ee-a6a1-22d4efc49afb",
        "d71701e9-95bb-427b-af02-274e3a7b73ff",
        "4b9a5286-29d7-43f3-84d9-dac52ef140f6"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Altre Aree

# COMMAND ----------

# MAGIC %md
# MAGIC ### Val di Sesia

# COMMAND ----------

# Area GARGALLO:
nw = [45.936696,8.258029]
sw = [45.708537,8.266103]
ne = [45.928736501865274,8.555181795123923]
se = [45.75786335605447, 8.562785208252006]

maxLat = max(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = max(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]

# COMMAND ----------

#Load Data
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")

#df = df.toPandas()


from pyspark.sql.functions import col, lit

df = df\
    .filter(col("totalDistance")>=20)\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("GARGALLO"))#.toPandas()

# COMMAND ----------

display(df.select("chassis").distinct())

# COMMAND ----------

#aggiungere il poligono alla mappa 
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight))


df.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 , popup = row["MissionId"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

#m

# COMMAND ----------

# MAGIC %md
# MAGIC #### Download Percorsi

# COMMAND ----------

v

# COMMAND ----------

# MAGIC %md
# MAGIC #### Plot Percorsi

# COMMAND ----------

from pyspark.sql.functions import array, col , collect_list
import folium

#missionRotte = ["944130f4-5af2-406a-a895-9b1e3cbbdb14", "944130f4-5af2-406a-a895-9b1e3cbbdb14", "aac8b944-0519-45c4-ae70-ea8c3224e410"]

df = spark.read.table('reliab.20230418_R39_RGDaily_MissionAreeSpecifichePiemonte_VALDISESIA')\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()

#mappa
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]


#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])



#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

set(df.chassis)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Val di Viù

# COMMAND ----------

# Area GARGALLO:
nw = [45.31559248371927, 7.311555310334209]
sw = [45.11408955832108, 7.311152744941018]
ne = [45.27247721238687, 7.518428070890534]
se = [45.121318396717236, 7.532189049171643]

maxLat = max(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = max(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]



#Load Data
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")


from pyspark.sql.functions import col, lit

df = df\
    .filter(col("totalDistance")>=20)\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("GARGALLO")).toPandas()



#aggiungere il poligono alla mappa 
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight))


df.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 , popup = row["MissionId"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

m

# COMMAND ----------

#download percorsi completi per i percorsi estratti
#area = "ValdiView"
#
#spark.createDataFrame(df.loc[: , ["chassis", "MissionId", "startDateTime", "endDateTime"]]).createOrReplaceTempView("listaPercorsiView")
#
#
#spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaPercorsiView a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startDateTime 
#                      AND b.endOfSampling   <= a.endDateTime """).write.saveAsTable(f"{nome}_{area}")
# 

# COMMAND ----------

from pyspark.sql.functions import array, col , collect_list
import folium


df = spark.read.table('reliab.20230418_R39_RGDaily_MissionAreeSpecifichePiemonte_VALDIview')\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]


#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

set(df.chassis)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Biella

# COMMAND ----------

import folium 

# Area GARGALLO:
nw = [45.697547,7.864973]
sw = [45.335737,7.939180]
ne = [45.674523,8.225015]
se = [45.401343,8.266241]

maxLat = max(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = max(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]



#Load Data
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")


from pyspark.sql.functions import col, lit

df = df\
    .filter(col("totalDistance")>=20)\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("GARGALLO")).toPandas()



#aggiungere il poligono alla mappa 
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight))


df.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 , popup = row["MissionId"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

m

# COMMAND ----------



# COMMAND ----------

#download percorsi completi per i percorsi estratti
#area = "Biella"
#
#spark.createDataFrame(df.loc[: , ["chassis", "MissionId", "startDateTime", "endDateTime"]].sample(n=20)).createOrReplaceTempView("listaPercorsiView")
#
#
#spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaPercorsiView a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startDateTime 
#                      AND b.endOfSampling   <= a.endDateTime """).write.saveAsTable(f"{nome}_{area}")
# 

# COMMAND ----------

from pyspark.sql.functions import array, col , collect_list
import folium


df = spark.read.table('reliab.20230418_R39_RGDaily_MissionAreeSpecifichePiemonte_BIELLA')\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]


#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC ### Langhe

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])

# COMMAND ----------

import folium 

# Area LANGHE:
nw = [44.686529877243146, 7.9197697606387125]
sw = [44.568961969398806, 7.916904806329416]
ne = [44.68549996698143, 8.00455385614518]
se = [44.59563900692741, 8.065028052698336]

maxLat = max(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = max(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]



#Load Data
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")


from pyspark.sql.functions import col, lit

df = df\
    .filter(col("totalDistance")>=20)\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("LANGHE"))

display(df.select("chassis").distinct())

# COMMAND ----------

import folium 

# Area LANGHE:
nw = [44.686529877243146, 7.9197697606387125]
sw = [44.568961969398806, 7.916904806329416]
ne = [44.68549996698143, 8.00455385614518]
se = [44.59563900692741, 8.065028052698336]

maxLat = max(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = max(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]



#Load Data
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")


from pyspark.sql.functions import col, lit

df = df\
    .filter(col("totalDistance")>=20)\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("LANGHE")).toPandas()



#aggiungere il poligono alla mappa 
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight))


df.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 , popup = row["MissionId"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

#m

# COMMAND ----------

###download percorsi completi per i percorsi estratti
#area = "Langhe"
#
#spark.createDataFrame(df.loc[: , ["chassis", "MissionId", "startDateTime", "endDateTime"]]).createOrReplaceTempView("listaPercorsiView")
#
#
#spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaPercorsiView a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startDateTime 
#                      AND b.endOfSampling   <= a.endDateTime """).write.saveAsTable(f"{nome}_{area}")
# 

# COMMAND ----------

from pyspark.sql.functions import array, col , collect_list
import folium


df = spark.read.table('reliab.20230419_R39_RGDaily_MissionAreeSpecifichePiemonte_LANGHE')\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]


#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Chieri

# COMMAND ----------

import folium 

# Area LANGHE:
nw = [45.109496,7.779468]
sw = [44.909678,7.787400]
ne = [45.083266,7.964443]
se = [44.915271,7.959782]

maxLat = max(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = max(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]



#Load Data
df = spark.read.table('reliab_20230414_R39_RGDaily_ScaricaMissionBadPiemonte_clean3060Speed')

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")


from pyspark.sql.functions import col, lit

df = df\
    .filter(col("totalDistance")>=20)\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("LANGHE"))
        #.toPandas()



##aggiungere il poligono alla mappa 
#m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)
#
#
#line_color='gray'
#fill_color='gray'
#weight=2
#
#edges = [NW, NE, SE, SW]
#
#m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
#                                              weight=weight))
#
#
#df.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
#                                              radius=0.000001 , popup = row["MissionId"])
#                                             .add_to(m), axis=1) 
#
#
##aggiunge il layer controller
#m = m.add_child(folium.LayerControl(collapsed=False)) 
#
#m

# COMMAND ----------

###download percorsi completi per i percorsi estratti
#area = "Chieri"
#
#spark.createDataFrame(df.loc[: , ["chassis", "MissionId", "startDateTime", "endDateTime"]].sample(n=20)).createOrReplaceTempView("listaPercorsiView")
#
#
#spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaPercorsiView a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startDateTime 
#                      AND b.endOfSampling   <= a.endDateTime """).write.saveAsTable(f"{nome}_{area}")
# 

# COMMAND ----------

from pyspark.sql.functions import array, col , collect_list
import folium


df = spark.read.table('reliab.20230420_R39_RGDaily_MissionAreeSpecifichePiemonte_Chieri')\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]


#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Urban 2

# COMMAND ----------

from pyspark.sql.functions import array, col , collect_list
import folium 

# Area LANGHE:
nw = [45.095289,7.601548]
sw = [45.081133,7.707245]
ne = [45.041750,7.598135]
se = [45.036413,7.674403]

maxLat = max(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = max(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]



#Load Data
df = spark.read.table('reliab.20230519_R39_RGDaily_ScaricaMissionBadPiemonte_clean_allSpeed')\
    .filter(col("averageSpeed")<40)

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")


from pyspark.sql.functions import col, lit

df = df\
    .filter(col("totalDistance")>=20)\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("LANGHE"))\
        .toPandas()



#aggiungere il poligono alla mappa 
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight))


df.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 , popup = row["MissionId"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

#m

# COMMAND ----------

###impostare il numero di partizioni shuffle
#print("partizioni shuffle PRE: ", spark.conf.get("spark.sql.shuffle.partitions"))
#spark.conf.set("spark.sql.shuffle.partitions" , "auto")
#print("partizioni shuffle POST: ", spark.conf.get("spark.sql.shuffle.partitions"))
#
#
###download percorsi completi per i percorsi estratti
#area = "Torino"
#
#spark.createDataFrame(df.loc[: , ["chassis", "MissionId", "startDateTime", "endDateTime"]].sample(n=30)).createOrReplaceTempView("listaPercorsiView")
#
#
#spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaPercorsiView a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startDateTime 
#                      AND b.endOfSampling   <= a.endDateTime """)\
#                        .write\
#                        .mode("overWrite")\
#                        .option("overwriteSchema", "true")\
#                        .saveAsTable(f"{nome}_{area}")

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 

datasetPercorsi  = "reliab.20230519_r39_rgdaily_missionareespecifichepiemonte_torino"

df = spark.read.table(datasetPercorsi)\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]


#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


#m

# COMMAND ----------

#tabelle riassuntive
dfPercorsi = spark.read.table("reliab.20230519_r39_rgdaily_missionareespecifichepiemonte_torino")\
                    .select("chassis", "missionId")\
                        .distinct()

df = spark.read.table("reliab.20230519_r39_rgdaily_scaricamissionbadpiemonte_clean_allspeed")\
    .join(dfPercorsi, ["chassis", "missionId"])\
        .selectExpr("AVG(distance) as distance", "avg(averageSpeed) as averageSpeed", "avg(idlingTime) as idlingTime",
                    "avg(stopsDistance) as stopsDistance", "avg(harshSteeringDistance) as harshSteeringDistance" ,"avg(harshBrakingDistance) as harshBrakingDistance", "avg(sumNonHarshSteeringDistance) as sumNonHarshSteeringDistance")\
        .selectExpr( "averageSpeed", "idlingTime/3600 as hoursIdling", "stopsDistance*10 as stops10km", "stopsDistance*distance as numberStops",
                    "harshSteeringDistance*distance as numberHarshSteering", "harshBrakingDistance*distance as numberHarshBraking",
                        "sumNonHarshSteeringDistance*distance as numberNormalSteering")\
                            .toPandas()

display(df.T.reset_index().rename({"index": "signal",0:"value"}, axis=1))

# COMMAND ----------

#numero di key offs
from pyspark.sql.functions import count, to_date 

df = spark.read.table("reliab.20230519_r39_rgdaily_scaricamissionbadpiemonte_clean_allspeed")\
    .filter(col("averageSpeed")<40)\
    .groupBy(["chassis", to_date("startDateTime")])\
     .agg(count("*").alias("count"))\
         .selectExpr("max(count)")\
             .show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Autostrada 3 

# COMMAND ----------

from pyspark.sql.functions import array, col , collect_list
import folium 

# Area autostrada3:
nw = [44.968296,7.551009]
sw = [44.043772,7.825850]
ne = [45.057613,7.963271]
se = [44.236935,8.276430]

maxLat = max(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = max(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]



#Load Data
df = spark.read.table('reliab.20230519_R39_RGDaily_ScaricaMissionBadPiemonte_clean_allSpeed')\
    .filter(col("averageSpeed")>70)\
        .filter(col("distance")>80)

#features da eliminare
colsToDrop = ["date", 
			 "avgSpeed_OdoOverWorkhours", "engineWorkHours", "sumNonHarshSteering",
			 "startOdom", "liters", "endOdom", "idlingTime", "time_driving", 
			 "TIME", "TOTALTIME", "distance", "percentTimePTOon", "percentDistanceACC", 
			 "percentDistancePtoOn", "percentTimeACC", "maxVehicleSpeed"]

#drop var
df = df.drop(*colsToDrop)

#eliminare i nulls
df = df.na.drop("any")


from pyspark.sql.functions import col, lit

df = df\
    .filter(col("totalDistance")>=20)\
    .filter(col("gpsLat") <= maxLat)\
    .filter(col("gpsLat") >= minLat)\
    .filter(col("gpsLon") <= maxLon)\
    .filter(col("gpsLon") >= minLon)\
        .withColumn("area", lit("LANGHE"))\
        .toPandas()



#aggiungere il poligono alla mappa 
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight))


df.apply(lambda row: folium.CircleMarker(location=[row["gpsLat"], row["gpsLon"]], 
                                              radius=0.000001 , popup = row["MissionId"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

#m

# COMMAND ----------

###impostare il numero di partizioni shuffle
print("partizioni shuffle PRE: ", spark.conf.get("spark.sql.shuffle.partitions"))
spark.conf.set("spark.sql.shuffle.partitions" , "auto")
print("partizioni shuffle POST: ", spark.conf.get("spark.sql.shuffle.partitions"))


##download percorsi completi per i percorsi estratti
area = "Autostrada3"

spark.createDataFrame(df.loc[: , ["chassis", "MissionId", "startDateTime", "endDateTime"]].sample(n=30)).createOrReplaceTempView("listaPercorsiView")


spark.sql("""SELECT a.*, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
              FROM  listaPercorsiView a 
                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
                      ON a.chassis = b.chassis 
                      AND b.startofsampling >= a.startDateTime 
                      AND b.endOfSampling   <= a.endDateTime """)\
                        .write\
                        .mode("overWrite")\
                        .option("overwriteSchema", "true")\
                        .saveAsTable(f"{nome}_{area}")

print(f"nome tabella: {nome}_{area}")

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 

datasetPercorsi  = "reliab.20230522_r39_rgdaily_missionareespecifichepiemonte_autostrada3"

df = spark.read.table(datasetPercorsi)\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=((NW[0]+SW[0])/2, (NW[1]+NE[1])/2), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2

edges = [NW, NE, SE, SW]


#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

