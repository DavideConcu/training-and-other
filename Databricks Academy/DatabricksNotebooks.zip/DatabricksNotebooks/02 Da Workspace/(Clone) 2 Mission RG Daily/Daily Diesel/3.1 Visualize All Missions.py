# Databricks notebook source
# MAGIC %md
# MAGIC # Plot di Tutte le Mission

# COMMAND ----------

pip install geopy

# COMMAND ----------

pip install polyline

# COMMAND ----------

pip install folium

# COMMAND ----------

import geopy.distance
import requests
import folium
import polyline

# COMMAND ----------

#load table
from pyspark.sql.functions import col, upper

missionDf = spark.read.table("reliab.dailyRG_MissionDf2").filter(upper(col("country")) =="ITALIA").na.drop("any")

# COMMAND ----------

#inizializzare la mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

# COMMAND ----------

display(missionDf.limit(10))

# COMMAND ----------

def add_path_to_map(route, mappa):
    """ aggiunge le singole mission alla mappa principale"""

    folium.PolyLine(
        route['route'],
        weight=8,
        color='blue',
        opacity=0.4,
        popup = route["name"]
    ).add_to(m)

    folium.Marker(
        location=route['start_point'],
        icon=folium.Icon(icon='play', color='green')
    ).add_to(m)

    folium.Marker(
        location=route['end_point'],
        icon=folium.Icon(icon='stop', color='red')
    ).add_to(m)

# COMMAND ----------

from pyspark.sql.functions import col

for chassis, startMission, config in  missionDf.select("chassis","startofsampl_mission", "config").distinct().orderBy("chassis","startofsampl_mission").collect():
    
    #print(chassis, startMission)
    mission = {"chassis": chassis, "mission": startMission , "config":config}
    
    #filtrare il dataset di partenza per tenere la singola mission
    singleMissionDf = missionDf\
        .where(col("chassis") == mission["chassis"])\
        .where(col("startofsampl_mission") == mission["mission"])\
        .orderBy(col("timestamp"))
    
    #aggiungere il percorso completo
    path = list()
    for long, lat in singleMissionDf.select("latitude", "longitude").collect():
        path.append(tuple([long, lat]))
    
    #definire il dizionario contenente le specifiche del percorso
    route = dict()
    route["route"] = path
    route["start_point"] = (singleMissionDf.collect()[0]["Latitude"], singleMissionDf.collect()[0]["Longitude"])
    route["end_point"] = (singleMissionDf.collect()[-1]["Latitude"], singleMissionDf.collect()[-1]["Longitude"])
    route["name"] = singleMissionDf.selectExpr("CONCAT(chassis, ' ', startofsampl_mission, ' Conf:', config) as name").limit(1).collect()[0]["name"]
    
    print(route)
    add_path_to_map(route)

# COMMAND ----------

m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova con UDF

# COMMAND ----------

# MAGIC %md
# MAGIC ### mission di una specifica configurazione

# COMMAND ----------

conf = 11

# COMMAND ----------

#load table
from pyspark.sql.functions import col, upper

missionDf = spark.read.table("reliab.dailyRG_MissionDf2").filter(upper(col("country")) =="ITALIA").filter(col("config")==conf).na.drop("any")

# COMMAND ----------

def add_path_to_map(route, mappa):
    """ aggiunge le singole mission alla mappa principale"""

    folium.PolyLine(
        route['route'],
        weight=8,
        color='blue',
        opacity=0.4,
        popup = route["name"]
    ).add_to(mappa)

    folium.Marker(
        location=route['start_point'],
        icon=folium.Icon(icon='play', color='green')
    ).add_to(mappa)

    folium.Marker(
        location=route['end_point'],
        icon=folium.Icon(icon='stop', color='red')
    ).add_to(mappa)

# COMMAND ----------

#inizializzare la mappa
m2 = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

# COMMAND ----------

from pyspark.sql.functions import col

for chassis, startMission, config in  missionDf.select("chassis","startofsampl_mission", "config").distinct().orderBy("chassis","startofsampl_mission").collect():
    
    #print(chassis, startMission)
    mission = {"chassis": chassis, "mission": startMission , "config":config}
    
    #filtrare il dataset di partenza per tenere la singola mission
    singleMissionDf = missionDf\
        .where(col("chassis") == mission["chassis"])\
        .where(col("startofsampl_mission") == mission["mission"])\
        .orderBy(col("timestamp"))
    
    #aggiungere il percorso completo
    path = list()
    for long, lat in singleMissionDf.select("latitude", "longitude").collect():
        path.append(tuple([long, lat]))
    
    #definire il dizionario contenente le specifiche del percorso
    route = dict()
    route["route"] = path
    route["start_point"] = (singleMissionDf.collect()[0]["Latitude"], singleMissionDf.collect()[0]["Longitude"])
    route["end_point"] = (singleMissionDf.collect()[-1]["Latitude"], singleMissionDf.collect()[-1]["Longitude"])
    route["name"] = singleMissionDf.selectExpr("CONCAT(chassis, ' ', startofsampl_mission, ' Conf:', config) as name").limit(1).collect()[0]["name"]
    
    print(route)
    add_path_to_map(route, m2)

# COMMAND ----------

