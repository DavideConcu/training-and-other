# Databricks notebook source
# MAGIC %md
# MAGIC # Download Data

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "RGDailyCNG"
notebook = "dataSuperFlatStarting2022"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

#leggere il file csv con i dati dei veicoli
listaVeicoliConMtbf = spark.read.csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCng.csv", header=True)\
.withColumnRenamed("Serial_Number", "chassis")

listaVeicoliConMtbf.count()

# COMMAND ----------

#download super flat data
#from pyspark.sql.functions import col
#
#spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
#                    .join(listaVeicoliConMtbf, "chassis")\
#                    .filter(col("startOfSampling") >= "2022")\
#                    .write\
#                    .mode("overwrite")\
#                    .option("overwriteschema", "true")\
#                    .saveAsTable(f"{nome}")
#
#print(f"saved file: {nome}")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(DISTINCT CHASSIS)
# MAGIC FROM reliab.20230525_RGDailyCNG_dataSuperFlatStarting2022

# COMMAND ----------

# MAGIC %md
# MAGIC ## Lista di Daily CNG da EDWH VEHICLE

# COMMAND ----------

from pyspark.sql.functions import col

listaChassisDaEDWH = (spark.read.table("edwh.vehicle")\
                .filter((col("pvcb_ds_sub_product_cl").like("%DAILY%POWER%"))|(col("pvcb_ds_sub_product_cl").like("%DAILY%CNG%")))\
                .filter((col("pvan_ds_preliminary_model_year")=="MY2019")|(col("pvan_ds_preliminary_model_year")=="MY2021")))\
                .select(col("pvan_cd_vin_code").alias("chassis"))

listaChassisDaEDWH.count()

# COMMAND ----------

#download super flat data
from pyspark.sql.functions import col

spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
                    .join(listaChassisDaEDWH, "chassis")\
                    .filter(col("startOfSampling") >= "2022")\
                    .write\
                    .mode("overwrite")\
                    .option("overwriteschema", "true")\
                    .saveAsTable(f"{nome}_daEDWH")

print(f"saved file: {nome}_daEDWH")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(DISTINCT chassis)
# MAGIC FROM reliab.20230526_RGDailyCNG_dataSuperFlatStarting2022_daEDWH

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT chassis
# MAGIC FROM reliab.20230526_RGDailyCNG_dataSuperFlatStarting2022_daEDWH

# COMMAND ----------

