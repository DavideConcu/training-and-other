# Databricks notebook source
from pyspark.sql.functions import col
df = spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
                .filter(col("totaldistance")>0)\
                .filter(col("totaltime")>0)\
                .selectExpr( "chassis", "missionid", "totaldistance", "maxVehicleSpeed", "stops", "stops/totaldistance as stopsPerDistance", "totaldistance/(totaltime/(60*60)) as averageSpeed" , "totalTimeIdling/totaltime as percentIdling", "harshSteering/totaldistance as harshSteeringPerDistance").toPandas()

# COMMAND ----------

df.chassis.drop_duplicates().count()

# COMMAND ----------

import pandas as pd
garbageIta = pd.read_excel("/dbfs/FileStore/tables/reliab/garbageCollectorsIta.xlsx")
garbageIta = spark.createDataFrame(garbageIta).selectExpr("pvan_cd_vin_code as chassis")


# COMMAND ----------


#lista totale di daily
from pyspark.sql.functions import col

df = spark.read.table("edwh.vehicle").selectExpr("pvan_cd_vin_code as chassis", "pvcb_ds_sub_product_cl as boh").filter(col("boh").like("%DAILY%"))

df = df.join(garbageIta, "chassis")

# COMMAND ----------

#download dei dati di questi vin
from pyspark.sql.functions import col

#spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
#                    .join(df, "chassis")\
#                    .filter(col("startOfSampling") >= "2022")\
#                    .write\
#                    .mode("overwrite")\
#                    .option("overwriteschema", "true")\
#                    .saveAsTable(f"reliab.20230630_cngDaily_AllEcologyData")
#


# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view listaMission as 
# MAGIC select distinct chassis, missionId, startOfSampling, endOfSampling from
# MAGIC default.20230630_cngDaily_AllEcologyData

# COMMAND ----------

# MAGIC %md
# MAGIC ## Caratteristiche delle mission aggregate

# COMMAND ----------

df = spark.read.table("default.20230630_cngDaily_AllEcologyData")\
                .filter(col("totaldistance")>0)\
                .filter(col("totaltime")>0)\
                .selectExpr( "chassis", "missionid", "totaldistance", "maxVehicleSpeed", "stops", "stops/totaldistance as stopsPerDistance", "totaldistance/(totaltime/(60*60)) as averageSpeed" , "totalTimeIdling/totaltime as percentIdling", "harshSteering/totaldistance as harshSteeringPerDistance")\
                .filter(col("chassis")!="ZCFC0358605473717").toPandas()



# COMMAND ----------

df.groupby("chassis").mean()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md 
# MAGIC ## Clustering delle mission aggregate

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans


numCols = ["averageSpeed"]

#elbow rule overall PRE
X = df.loc[:, numCols].to_numpy()
scalers = StandardScaler()
X_std = scalers.fit_transform(X)
X_std.shape

kmeans_kwargs = {
"init": "random",
"n_init": 100,
    "max_iter": 1000,
    "random_state": 1
}

NUMEROCLUSTERS = 4

#fit e risultato del clustering
kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
kmeans.fit(X_std)
predicted_kmeans = kmeans.predict(X_std)

#calcolo distanza dal centroide
distance = []
for point in range(len(X_std)):
    clus = predicted_kmeans[point]
    distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

#attaccare label
df.loc[:, "cluster"] = predicted_kmeans.astype(int)
df.loc[:, "distance"] = distance

df = df.drop("distance", axis = 1)


#riordinare i cluster
newClus = df.groupby("cluster").averageSpeed.mean().sort_values(ascending=False).reset_index().reset_index().rename({"index":"cluster_new"}, axis=1)[["cluster_new", "cluster"]]

df = df.merge(newClus, on="cluster").drop("cluster", axis=1).rename({"cluster_new":"cluster"},axis=1)

# COMMAND ----------

#violin plot
import matplotlib.pyplot as plt
import seaborn as sns


plt.figure(figsize=(10, 5))
sns.violinplot(x="cluster", y="averageSpeed", data=df, palette="coolwarm", inner="quart" , split=True)

plt.ylabel("Average Speed [km/h]", size=14)
plt.xlabel("Cluster", size=14)
plt.title(f"Average Speed Distribution", size=18)
ax = plt.gca()
ax.grid(True)
plt.show()

# COMMAND ----------

df.drop(["stops", "harshSteeringPerDistance"], axis=1).groupby("cluster").mean().reset_index()

# COMMAND ----------

#func mission basata su velocità media
def missionType(cluster):
    """map mission type in highway extraurban urban raccoltarifiuti"""
    missionType = None

    if cluster == 3:
        missionType = "ECOLOGY"
    elif cluster == 2:
        missionType = "URBAN"
    elif cluster == 1:
        missionType = "EXTRAURBAN"
    elif cluster == 0:
        missionType = "HIGHWAY"

    return missionType

#func mission basata su altitudine
def missionTypeAltitude(altitude):
    """define another mission type based on altitude"""
    missionTypeAltitude = None
    if altitude >= 600:
        missionTypeAltitude = "MOUNTAIN"
    elif altitude >= 300:
        missionTypeAltitude = "HILLY"
    else:
        missionTypeAltitude = "FLAT"
    
    return missionTypeAltitude

# COMMAND ----------

df["missionType"] = df.apply(lambda x: missionType(x["cluster"]), axis = 1)

dfMissionAggSpark = spark.createDataFrame(df)

# COMMAND ----------

#mission sicuramente di raccolta rifiuti
df.loc[df.missionid.isin( ["19467c1b-429f-4910-bd46-c5e62faf8eb1" , "48b7f5d1-4604-4851-85fd-f4bfc4fb9a49" ]),:]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Percorsi completi

# COMMAND ----------

#download dei percorsi completi per queste mission
#estrarre percorsi completi
#spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.#Longitude
#              FROM  listaMission a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startofsampling 
#                      AND b.endOfSampling   <= a.endOfSampling """).write.saveAsTable(f"reliab.#20230630_dailyCNG_PercorsiVinEcology")
#
#
print(f"Table created: ") 

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct missionid)
# MAGIC from reliab.20230630_dailyCNG_PercorsiVinEcology

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualizzare le mission

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 



df = spark.read.table("reliab.20230630_dailyCNG_PercorsiVinEcology")\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path"))\
        .join(dfMissionAggSpark, ["chassis", "missionid"]).toPandas()

zona = df.path[0][0]

df=df.loc[df.missionType == "URBAN",:]


#mappa

m = folium.Map(location=(zona), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

"id: 19467c1b-429f-4910-bd46-c5e62faf8eb1"
"id: 48b7f5d1-4604-4851-85fd-f4bfc4fb9a49"
 