# Databricks notebook source
# MAGIC %md
# MAGIC # Download Sample Percorsi in Francia

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "dailyCNG"
notebook = "downloadPercorsiFRANCIA"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

from pyspark.sql.functions import col, mean, avg, count

#con mtbf da Cinzia
dfCinzia = spark.read.csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCngTotal.csv", header = "true")\
                .withColumnRenamed("Serial_Number", "chassis")\
                .withColumnRenamed("MTBF_veicolo", "mtbf")\
                .select("chassis", "mtbf")

vehicleFrancia = spark.read.table("edwh.vehicle")\
    .selectExpr("pvan_cd_vin_code as chassis", "makt_ds_country_sdes as market")\
        .join(dfCinzia, "chassis")\
            .withColumn("mtbf", col("mtbf").cast("float"))\
            .filter(col("market")=="Italy")



# COMMAND ----------

# MAGIC %md
# MAGIC ## Merge con il dataset delle mission aggregate di tutti i cng

# COMMAND ----------

dataset = "reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh"

dfMission = spark.read.table(dataset)\
        .filter(col("totalTime")>0)\
        .filter(col("totaldistance")>0)\
        .join(vehicleFrancia, "chassis")

# COMMAND ----------

dfMission.select("chassis").distinct().count()

# COMMAND ----------

display(dfMission)

# COMMAND ----------

dfMission.sample(0.005).select("chassis", "missionId", "startOfSampling", "endOfSampling").createTempView("listaMission")

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM listaMission
# MAGIC LIMIT 10

# COMMAND ----------

##estrarre percorsi completi
#spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  listaMission a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startofsampling 
#                      AND b.endOfSampling   <= a.endOfSampling """).write.saveAsTable(f"{nome}")
#

print(f"Table created: {nome}") 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check dataset percorsi + info

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT Count(*)
# MAGIC from reliab.20230616_dailyCNG_downloadPercorsiFRANCIA_withStreetInfo

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct chassis)
# MAGIC from reliab.20230616_dailyCNG_downloadPercorsiFRANCIA_withStreetInfo

# COMMAND ----------

# MAGIC %sql
# MAGIC select chassis, count(distinct missionid)
# MAGIC from reliab.20230616_dailyCNG_downloadPercorsiFRANCIA_withStreetInfo
# MAGIC group by chassis

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from reliab.20230616_dailyCNG_downloadPercorsiFRANCIA_withStreetInfo
# MAGIC limit 5

# COMMAND ----------

# MAGIC %md
# MAGIC ## Estrarre lista univoca strade
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import col, split

df = spark.read.table("reliab.20230616_dailyCNG_downloadPercorsiFRANCIA_withStreetInfo")

dfStrade = df.withColumn("road1", split(col("streetInfo.road"), " ")[0])\
    .withColumn("road2", split(col("streetInfo.road"), " ")[1])\
             .select("road1").distinct()

# COMMAND ----------

display(dfStrade)

# COMMAND ----------

# MAGIC %md
# MAGIC ## visualizzare qualche mission 

# COMMAND ----------

from pyspark.sql.functions import col

#mission agg dataset
listaMission = spark.read.table("reliab.20230616_dailycng_downloadpercorsifrancia_withstreetinfo_withmissiontype_pivoted1rowpermission")

urban = listaMission.sort(col("Urban").desc(), col("totalDistanceKm").desc()).limit(30)
extra = listaMission.sort(col("Extraurban").desc(), col("totalDistanceKm").desc()).limit(30)
highw = listaMission.sort(col("Highway").desc(), col("totalDistanceKm").desc()).limit(30)


# COMMAND ----------

from pyspark.sql.functions import array

datasetPercorsi  = "reliab.20230616_dailycng_downloadpercorsifrancia_withstreetinfo_withmissiontype"


df = spark.read.table(datasetPercorsi)\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path"))\
            .join(highw, ["chassis", "missionid"])\
                .toPandas()

# COMMAND ----------


#plot delle mission
from pyspark.sql.functions import col 
import folium

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])


#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

from pyspark.sql.functions import col

dataset = "reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh"

display(spark.read.table(dataset)\
        .filter(col("totalTime")>0)\
        .filter(col("totaldistance")>0)\
        .select("chassis")\
        .distinct())

# COMMAND ----------

