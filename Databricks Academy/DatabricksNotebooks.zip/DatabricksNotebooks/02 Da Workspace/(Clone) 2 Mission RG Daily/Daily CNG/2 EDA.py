# Databricks notebook source
# MAGIC %md
# MAGIC # EDA

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "RGDailyCNG"
notebook = "EDA"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read the data

# COMMAND ----------

#data
df = spark.read.table("reliab.20230525_RGDailyCNG_dataSuperFlatStarting2022")

display(df.limit(10))

# COMMAND ----------

#eliminare i vin con poche acquisizioni
#from pyspark.sql.functions import count, col
#
#chassisWithMoreMiss = df.groupBy("chassis").agg(count("*").alias("missionPerChassis")).filter(col("missionPerChassis")>100)
#
#df = df.join(chassisWithMoreMiss, "chassis").toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualizzare un campione di n mission

# COMMAND ----------

sample = df.toPandas().sample(10000)

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])

# COMMAND ----------

#aggiungere il poligono alla mappa 
import folium

m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

line_color='gray'
fill_color='gray'
weight=2
text='Giaveno'

 

sample.apply(lambda row: folium.CircleMarker(location=[row["lat_end"], row["lon_end"]], 
                                              radius=0.000001 , popup = row["chassis"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Posizione degli Chassis

# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#prima missione per chassis
from pyspark.sql.functions import first

oneMissionPerVin = (df.select("chassis", "lat_Start", "lon_Start")\
                     .groupBy("chassis")\
                     .agg( first("lat_Start").alias("lat_start"), first("lon_start").alias("lon_start"))).toPandas()

# COMMAND ----------

#inizializzare il servizio
import random, string

def randomword():
    """ Crea parola random """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(5))

def initialize_service():
    """ Inizializza il servizio di Nominatim """
    locator = Nominatim(user_agent=f"iveCoder{randomword}", timeout=60)
    reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)
    return locator, reverseGeocode
    
def extractCountry(row):
    info = locator.reverse([row["lat_start"], row["lon_start"]])
    try:
        country = info.raw["address"]["country"]
        print(country)
    except:
        print("none")
        country = None
    return country

def extractRegion(row):
    info = locator.reverse([row["lat_start"], row["lon_start"]])
    try:
        state = info.raw["address"]["state"]
        print(state)
    except:
        print("none")
        state = None
    return state


# COMMAND ----------

#estrarre info su posizione da Nominatim
import geopy 


#inizializzare il servizio
locator, reverseGeocode = initialize_service()

oneMissionPerVin["country"] = oneMissionPerVin.apply(lambda row: extractCountry(row), axis=1)

# COMMAND ----------

#italianChassis = oneMissionPerVin.loc[oneMissionPerVin.country=="Italia"]

italianChassis["region"] = italianChassis.apply(lambda row: extractRegion(row), axis=1)

# COMMAND ----------

from pyspark.sql.functions import *

df.filter(col("chassis").isin(list(italianChassis.chassis))).count()

# COMMAND ----------

display(df.select("chassis", "country_code").distinct().groupBy("country_code").count())

# COMMAND ----------

display(df.select("chassis").groupBy("chassis").count())

# COMMAND ----------

dfPandas = df.toPandas()

# COMMAND ----------

dfPandas["totalTimeMinutes"] = dfPandas.totalTime/60
dfPandas.totalTimeMinutes.quantile(0.5)

# COMMAND ----------

dfPandas.groupby("chassis").count().quantile(0.30)["customer"]

# COMMAND ----------

mask = (dfPandas.groupby("chassis").customer.count()>50)

lista = list(mask[mask].index)


# COMMAND ----------

#eliminare gli chassis con troppe poche mission
df = df.filter(col("chassis").isin(lista))

# COMMAND ----------

dfPandas = dfPandas.loc[dfPandas.totalTime>7.5*60]

dfPandas["averageSpeed"] = dfPandas.totalDistance/(dfPandas.totalTime/60**2)
dfPandas["mtbfHours"] = dfPandas.MTBF_veicolo.astype(float)/ dfPandas.engineWorkHours

# COMMAND ----------

dfPandas = dfPandas.loc[:, ["chassis", "missionId", "totalTimeMinutes", "averageSpeed", "mtbfHours"]].reset_index(drop=True)

# COMMAND ----------

italianMissions = dfPandas.loc[dfPandas.chassis.isin(list(italianChassis.chassis))].reset_index(drop=True)
italianMissions

# COMMAND ----------

#campionare una mission per chassis
lista = list()
for vin in italianMissions.chassis.drop_duplicates():
    miss = italianMissions.loc[italianMissions.chassis == vin].sample(4).missionId.to_list()
    lista += miss 

# COMMAND ----------

listaDf = dfPandas.loc[dfPandas.missionId.isin(lista), ["chassis", "missionId", "startOfSampling", "endOfSampling"]].reset_index(drop = True)

spark.createDataFrame(listaDf).createTempView("lista")

# COMMAND ----------

# OK!
#spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  lista a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startofsampling 
#                      AND b.endOfSampling   <= a.endOfSampling """).write.saveAsTable(f"{nome}_samplePercorsiItaliaCNG")
# 

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM reliab.20230526_rgdailycng_datacleaning_samplepercorsiitaliacng
# MAGIC LIMIT 10

# COMMAND ----------

#plot delle mission
from pyspark.sql.functions import col 

import folium

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 

datasetPercorsi  = "reliab.20230526_rgdailycng_datacleaning_samplepercorsiitaliacng"

df = spark.read.table(datasetPercorsi)\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

