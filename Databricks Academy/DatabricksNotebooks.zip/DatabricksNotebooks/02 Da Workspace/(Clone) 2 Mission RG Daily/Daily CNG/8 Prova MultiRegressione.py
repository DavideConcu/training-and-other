# Databricks notebook source
#input dataset 
dataset = "reliab.20230616_dailyCNG_downloadPercorsiFRANCIA_withStreetInfo_withMissionType_PIVOTED1rowPermIssion"

datasetMissionAgg = "reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh"
dfMissionAgg = spark.read.table(datasetMissionAgg)

df = spark.read.table(dataset)\
            .join(dfMissionAgg, ["chassis", "missionid"])\
            .toPandas()

# COMMAND ----------

features = ['totalDistanceKm',
 'totalTimeHours',
 'avgSpeedMission',
 'totalKilograms',
 'totalTime',
 'totalTimeDriving',
 'totalTimeIdling',
 'totalTimePtoOn',
 'totalTimePtoDriving',
 'totalTimePtoIdling',
 'totalTimeCC',
 'totalTimeACC',
 'totalTimeEcoRollInt',
 'totalTimeAccPedal',
 'totalTimeBrakePedal',
 'totalTimeBrakeSwitch',
 'totalTimeLowIdleSwitch',
 'totalTimeKickDownSwitch',
 'totalTimeEngineBrake',
 'totalTimeRetarderLever',
 'totalDistance',
 'totalDistancePtoOn',
 'totalDistanceCC',
 'totalDistanceACC',
 'fuelConsumption',
 'engineTimeAll',
 'engineSpeedOptimalTime',
 'engineSpeedTimeAll',
 'fuelConsumptionPtoOn',
 'fuelConsumptionPtoIdling',
 'fuelConsumptionPtoDriving',
 'fuelConsumptionDriving',
 'fuelConsumptionIdling',
'maxVehicleSpeed',
'stops',
 'engineSpeedAvg',
 'flat',
 'hilly',
 'light_mountain',
 'medium_mountain',
 'severe_mountain',
 'externalTempMin',
 'externalTempMax',
 'externalTempAvg',
 'engineCoolantTemperatureMax',
 'intakeManifoldPressureMax',
 'engineFuelTemperatureMax',
 'barometricPressureMin',
 'barometricPressureMax',
 'barometricPressureAvg',
 'engineOilLevelAvg',
 'engineExaustTemperatureMax',
 'engineOverspeedTime',
 'harshSteering',
 'harshAcceleration']

target = ['Extraurban',
 'Urban',
 'Highway',
 'Montagna',
 'Collinare']

df = df.loc[:, features + target].dropna()


X = df.loc[:, features].to_numpy()
Y = df.loc[:, target].to_numpy()

# COMMAND ----------

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X = scaler.fit_transform(X)



# COMMAND ----------

#il modello
model = MultiOutputRegressor(GradientBoostingRegressor(random_state=0))
prediction = model.fit(X, Y).predict(X)

# COMMAND ----------

import pandas as pd
dfPred = pd.DataFrame(prediction, columns = [x+"_pred" for x in  target])

# COMMAND ----------

df.loc[:,target].reset_index(drop=True)\
    .merge(dfPred, right_index=True, left_index=True)

# COMMAND ----------

from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(X,Y)

# COMMAND ----------

#il modello
model = MultiOutputRegressor(GradientBoostingRegressor(random_state=0))
model_fitted = model.fit(X_train, Y_train)

# COMMAND ----------

model_fitted.score(X_test,Y_test)

# COMMAND ----------

