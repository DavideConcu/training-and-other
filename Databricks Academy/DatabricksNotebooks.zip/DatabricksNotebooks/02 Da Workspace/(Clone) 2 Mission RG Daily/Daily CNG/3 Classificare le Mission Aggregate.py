# Databricks notebook source
pip install imblearn


# COMMAND ----------

import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# COMMAND ----------

#inizializzare il servizio
import random, string

def randomword():
    """ Crea parola random """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(5))

def initialize_service():
    """ Inizializza il servizio di Nominatim """
    locator = Nominatim(user_agent=f"iveCoder{randomword}", timeout=60)
    reverseGeocode = RateLimiter(locator.reverse, min_delay_seconds=0.001)
    return locator, reverseGeocode
    

def extractInfo(row):
    request = locator.reverse([row["Latitude"], row["Longitude"]])
    try:
        info = request.raw["address"]
        print("ok")
    except:
        print("none")
        info = None
    return info



# COMMAND ----------

inputTable = "reliab.20230526_rgdailycng_datacleaning_samplepercorsiitaliacng"

dfInput = spark.read.table(inputTable)\
            .na.drop(how="any" , subset=["Latitude", "Longitude"])\
            .toPandas()

# COMMAND ----------

dfInput

# COMMAND ----------

import pandas as pd

dfTarget = pd.DataFrame(columns = dfInput.columns)

# COMMAND ----------

locator, reverseGeocode = initialize_service()

sourceDf = pd.merge(dfTarget.loc[:, ["chassis", "missionId", "Timestamp"]], 
                    dfInput, on = ["chassis", "missionId", "Timestamp"], how="right", indicator=True)
sourceDf = sourceDf[sourceDf._merge=="right_only"].drop("_merge", axis=1).reset_index(drop=True)

print(len(sourceDf))
for i in range(len(sourceDf)):

    print(i)
    riga = dfInput.loc[i:i, :]

    riga["streetInfo"] = riga.apply(lambda row: extractInfo(row), axis = 1)

    dfTarget = pd.concat([dfTarget, riga]).reset_index(drop=True)



# COMMAND ----------

dfTarget

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC // Step 3 - Read in the JSON, but let it infer the schema
# MAGIC val eventsSchema = spark.read
# MAGIC                         .table("reliab.20230427_r39_rgdaily_streetinfo_final")
# MAGIC                         .schema.toDDL
# MAGIC
# MAGIC println(eventsSchema)

# COMMAND ----------

schema = "chassis STRING,missionId STRING,startOfSampling TIMESTAMP,endOfSampling TIMESTAMP,Timestamp TIMESTAMP,Altitude DECIMAL(10,2),Latitude DECIMAL(10,5),Longitude DECIMAL(10,5), streetInfo MAP<STRING,STRING>"


# COMMAND ----------

#spark.createDataFrame(dfTarget, schema)\
#    .write.saveAsTable(f"{nome}_percorsiConStreetInfo")

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "RGDailyCNG"
notebook = "classificaMission"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

# MAGIC %md
# MAGIC ## aggiungere il tipo di strada

# COMMAND ----------

from pyspark.sql.functions import col, collect_set

df = spark.read.table("reliab.20230529_RGDailyCNG_classificaMission_percorsiConStreetInfo")\
    .filter(col("streetInfo.country")=="Italia")

# COMMAND ----------

# MAGIC %md 
# MAGIC ##### streetType

# COMMAND ----------

#Mappare le strade
from pyspark.sql.functions import col, split
import re

#### Mappa Strade
def map_streets(road):
    """mappare le strade"""
    print(type(road))

    #patternHigh
    patternHigh = r"(^A\d{1,3}\s{0,1}$|^Autostrad|^Svincolo Autostradale|^Tangenziale|^Diramazione|^Raccordo|^Asse)"
                
    #extraurban
    patternExtra = r"^Strada Provinciale|^Strada Regionale|^Strada Statale|^Sp\s{0,1}\d{1,45}|^Sr\s{0,1}\d{1,5}|^Ss\s{0,1}\d{1,45}|^Variante|^Sentiero"
        
    #patternUrban 
    patternUrban = r"(Ex\s){0,1}Via|^Piazz|^Corso|^Strada (?!Provinciale|Regionale|Statale)|^Rotatoria|^Largo|^Vicolo|Svincolo|^Rotonda|^Foro|^Ponte|^Lungomare|^Vico|^Cavalcavia"

    if type(road)==str:
        
        road = road.title()

        if re.match(patternHigh, road):
            streetType = "HIGHWAY"
        elif re.match(patternUrban, road):
            streetType = "URBAN"
        elif re.match(patternExtra, road):
            streetType = "EXTRAURBAN"
        else:
            streetType = "OTHER"
    else:
        streetType = "NULL"

    return streetType

map_streets_udf = udf(map_streets)



#apply the function 
df = df.withColumn("streetType", map_streets_udf(col("streetInfo.road")))

# COMMAND ----------

display(df.select("streetInfo.road", "streetType").filter(col("streetType") == "EXTRAURBAN").distinct())


# COMMAND ----------

# MAGIC %md
# MAGIC ## Distanza percorsa

# COMMAND ----------

#agiungere i lag della posiziome
from pyspark.sql.functions import  lag, coalesce, array
from pyspark.sql.window import  Window

df =  df.withColumn("latLon", array(col("Latitude"), col("Longitude")))\
        .withColumn("lag_latLon", lag('latLon', 1).over(Window.partitionBy('chassis', "missionId").orderBy('timestamp')))\
        .withColumn("lag_latLon", coalesce(col("lag_latlon"), col("latlon")))


#funzione per calcolare la distanze tra due punti
import geopy.distance

def get_distance(lag_latlon, latlon):
    """ Get distance from point to another """
    distance = geopy.distance.geodesic(lag_latlon,latlon).km
    return distance

distance_udf = udf(get_distance)


#applica la funzione
df = df.withColumn("distanceKm", distance_udf(col("lag_latlon"), col("latlon")))


# COMMAND ----------

from pyspark.sql.functions import sum, desc , col, create_map, collect_list, flatten


display(df
        .groupBy("chassis", "missionId", "streetType")
        .agg(sum(col("distanceKm")).alias("DistanceKm"))
        .withColumn("map", create_map(col("streetType") , col("distanceKm")))
        .groupBy("chassis", "missionId")
        .agg((collect_list("map")))
        )

# COMMAND ----------

from pyspark.sql.functions import first, when, col

missionDf =     df\
        .groupBy("chassis", "missionId", "streetType")\
        .agg(sum(col("distanceKm")).alias("distanceKm"))\
        .groupBy("chassis", "missionId")\
        .pivot("streetType")\
        .agg(first("distanceKm"))\
        .na.fill(0)\
        .withColumn("missionType" , when(
                                    (col("HIGHWAY")>col("EXTRAURBAN"))
                                   &(col("HIGHWAY")>col("URBAN")     ), "HIGHWAY"
                                        )
                    
                                    .when(
                                     (col("EXTRAURBAN")>col("HIGHWAY"))
                                    &(col("EXTRAURBAN")>col("URBAN")  ), "EXTRAURBAN"
                                        )
                                    
                                    .when(
                                     (col("URBAN")>col("HIGHWAY"))
                                    &(col("URBAN")>col("EXTRAURBAN")), "URBAN"
                                        )
                                    
                                    .when(col("OTHER")>col("NULL"), "OTHER")
                                    .otherwise("NULL")
                                    )


# COMMAND ----------

display(missionDf)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## join con percorsi per visualizzare - OK

# COMMAND ----------

df.columns

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = row["missiontype"]
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = row["missiontype"]
    ).add_to(listaLayers[num])

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 

datasetPercorsi  = "reliab.20230526_rgdailycng_datacleaning_samplepercorsiitaliacng"

df = spark.read.table(datasetPercorsi)\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path"))\
        .join(missionDf.select("chassis", "missionid", "missiontype"), ["chassis", "missionid"])\
        .filter(~col("missiontype").isin(["NULL", "OTHER"]))\
        .toPandas()



#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md 
# MAGIC ## join tra dati di tipo mission e dati aggregati sulla mission per classificazione

# COMMAND ----------

#selezione colonne da dati in datacollector_tabular_flat
varList = ["chassis", "missionId", "totalDistance/(totalTime/3600) as averageSpeed",
            "totaltime", 
            "totalTimeDriving/totalTime as percentTimeDriving", 
            "totalTimeIdling/totalTime as percentTimeIdling",
            "totalTimePtoOn/totalTime as percentTimePTOon",
            "totalTimeACC/totalTime as percentTimeACC", 
            "totalTimeBrakePedal/totalTime as percentTimeBrakePedal",
            "totalDistance", 
            "totalDistancePtoOn/totalDistance as percentDistancePtoOn",
            "totalDistanceACC/totalDistance as percentDistanceACC",
            "fuelConsumption/totalDistance as fuelConsumptionDistance", 
            "maxVehicleSpeed",
            "stops/totalDistance as stopsDistance",
            "harshSteering/totalDistance as harshSteeringDistance", 
            "harshBraking/totalDistance as harshBrakingDistance",
            ]


df = spark.read.table("reliab.20230525_RGDailyCNG_dataSuperFlatStarting2022")\
    .selectExpr(varList)\
    .join(missionDf.select("chassis", "missionid", "missionType") , ["chassis", "missionId"])\
    .filter(~col("missionType").isin(["NULL", "OTHER"]))\
    .na.drop("any")\
    .toPandas()


# COMMAND ----------

#spark.createDataFrame(df).write.saveAsTable(f"{nome}_trainingSample")

print(f"{nome}_trainingSample")

# COMMAND ----------

testChassis = ['ZCFCN35A305380285',
 'ZCFCN35A405306051',
 'ZCFCN35A505415408',
 'ZCFCN35A605305452',
 'ZCFCN35A705387756',
 'ZCFCN35A705433425',]

X_train = df.loc[~df.chassis.isin(testChassis), [x for x in df.columns if x not in  ["missionType", "chassis", "missionId"]]]
y_train = df.loc[~df.chassis.isin(testChassis), "missionType"]
               
X_test = df.loc[df.chassis.isin(testChassis), [x for x in df.columns if x not in  ["missionType", "chassis", "missionId"]]]
y_test = df.loc[df.chassis.isin(testChassis), "missionType"]

# COMMAND ----------

from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# COMMAND ----------

# MAGIC %md
# MAGIC #### naive bayes

# COMMAND ----------

from sklearn.naive_bayes import GaussianNB
#from adspy_shared_utilities import plot_class_regions_for_classifier

nbclf = GaussianNB().fit(X_train, y_train)
#plot_class_regions_for_classifier(nbclf, X_train, y_train, X_test, y_test,)

# COMMAND ----------


print('Accuracy of GaussianNB classifier on training set: {:.2f}'
     .format(nbclf.score(X_train, y_train)))
print('Accuracy of GaussianNB classifier on test set: {:.2f}'
     .format(nbclf.score(X_test, y_test)))

predictions = nbclf.predict(X_test)


from  sklearn.metrics import  classification_report
import pandas as pd

print(classification_report(y_test, predictions))

# COMMAND ----------

from imblearn.over_sampling import RandomOverSampler
from collections import Counter

over_sampler = RandomOverSampler(random_state=42)
X_res, y_res = over_sampler.fit_resample(X_train, y_train)
print(f"Training target statistics: {Counter(y_res)}")
print(f"Testing target statistics: {Counter(y_test)}")

# COMMAND ----------

from sklearn.naive_bayes import GaussianNB

nbclf = GaussianNB().fit(X_res, y_res)


print('Breast cancer dataset')
print('Accuracy of GaussianNB classifier on training set: {:.2f}'
     .format(nbclf.score(X_res, y_res)))
print('Accuracy of GaussianNB classifier on test set: {:.2f}'
     .format(nbclf.score(X_test, y_test)))

# COMMAND ----------

# MAGIC %md
# MAGIC #### random forest 
# MAGIC

# COMMAND ----------

from sklearn.ensemble import RandomForestClassifier

# COMMAND ----------

clf = RandomForestClassifier(max_features = 10, random_state = 0, n_estimators=30)
clf.fit(X_train, y_train)

pred = clf.predict(X_test)

print(classification_report(y_test, pred))

print('Accuracy of RF classifier on training set: {:.2f}'
     .format(clf.score(X_train, y_train)))
print('Accuracy of RF classifier on test set: {:.2f}'
     .format(clf.score(X_test, y_test)))

# COMMAND ----------

from sklearn.ensemble import GradientBoostingClassifier
clf = GradientBoostingClassifier(random_state = 0)
clf.fit(X_train, y_train)

print(classification_report(y_test, pred ,  zero_division=True))
print('Accuracy of GBDT classifier on training set: {:.2f}'
     .format(clf.score(X_train, y_train)))
print('Accuracy of GBDT classifier on test set: {:.2f}\n'
     .format(clf.score(X_test, y_test)))


# COMMAND ----------

