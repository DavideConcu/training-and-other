# Databricks notebook source
# MAGIC %md
# MAGIC ## Dataset con tutte le mission aggregate

# COMMAND ----------

#dataset con tutte le mission trovate
from pyspark.sql.functions import col

dataset = "reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh"

df = spark.read.table(dataset)\
        .filter(col("totalTime")>0)\
        .filter(col("totaldistance")>0)

df.count()

# COMMAND ----------

#merge con mtbf da Cinzia
dfCinzia = spark.read.csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCngTotal.csv", header = "true")\
                .withColumnRenamed("Serial_Number", "chassis")\
                .withColumnRenamed("MTBF_veicolo", "mtbf")\
                .select("chassis", "mtbf")

df = df.join(dfCinzia, "chassis", "left")

# COMMAND ----------

from pyspark.sql.functions import col, mean, avg, count

vehicle = spark.read.table("edwh.vehicle")\
    .selectExpr("pvan_cd_vin_code as chassis", "makt_ds_country_sdes as market")

display(dfCinzia.join(vehicle, "chassis").groupBy("market").agg(count("*").alias("count"), avg("mtbf").alias("mtbf")).sort("mtbf"))

# COMMAND ----------


print("CHASSIS MTBF NON MANCANTE: ", df.where(col("mtbf").isNotNull())\
    .select("chassis").distinct().count())

print("CHASSIS MTBF MANCANTE: ", df.where(col("mtbf").isNotNull()==False)\
    .select("chassis").distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC # Dataset con i percorsi completi estratti (in Piemonte)

# COMMAND ----------

df = spark.read.table("reliab.20230616_dailyCNG_downloadPercorsiFRANCIA_withStreetInfo_withMissionType")\
        #.join(dfCinzia, "chassis", "left")



# COMMAND ----------

print("CHASSIS MTBF NON MANCANTE: ", df.where(col("mtbf").isNotNull())\
    .select("chassis").distinct().count())

print("CHASSIS MTBF MANCANTE: ", df.where(col("mtbf").isNotNull()==False)\
    .select("chassis").distinct().count())

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## velocità media per classi di mission type

# COMMAND ----------

dfPandas = df\
            .select("chassis", "missionid", "distanceKm", "timeSeconds", "averageSpeed", "streetType")\
            .withColumn("timeHours", col("timeSeconds")/(60**2))\
            .toPandas()
        
dfPandas.distanceKm = dfPandas.distanceKm.astype("float")

# COMMAND ----------

#violin plot
import matplotlib.pyplot as plt
import seaborn as sns


plt.figure(figsize=(10, 5))
sns.violinplot(x="streetType", y="averageSpeed", data=dfPandas, palette="coolwarm", inner="quart" , split=True)

plt.ylabel(col, size=14)
plt.xlabel("Cluster", size=14)
plt.title(f"speed", size=18)
plt.show()

# COMMAND ----------

#fare la media delle velocità all'interno di ogni mission per tipo di mission
dfPandasAgg1 = dfPandas.groupby(["chassis", "missionid", "streetType"]).averageSpeed.mean().reset_index()


dfPandasAgg2 = dfPandas.groupby(["chassis", "missionid", "streetType"])["distanceKm", "timeHours"].sum().reset_index()
dfPandasAgg2["sumAvgSpeed"] = dfPandasAgg2.distanceKm / dfPandasAgg2.timeHours
dfPandasAgg2.drop(["distanceKm", "timeHours"], axis = 1, inplace=True)

# COMMAND ----------

import pandas as pd

provaAvg = pd.merge(dfPandasAgg1, dfPandasAgg2,on = ["chassis", "missionid", "streetType"] )
#provaAvg["diff"] = ((provaAvg.averageSpeed - provaAvg.sumAvgSpeed)**2)**0.5
#provaAvg.sort_values(by="diff", ascending=False)

provaAvg = provaAvg.melt(id_vars=["chassis", "missionid", "streetType"], var_name=["avgType"], value_name="speedComparison")

# COMMAND ----------

#violin plot
import matplotlib.pyplot as plt
import seaborn as sns


plt.figure(figsize=(10, 5))
sns.violinplot(x="streetType", y="speedComparison", data=provaAvg, hue="avgType", palette="coolwarm", inner="quart" , split=True)

plt.ylabel(col, size=14)
plt.xlabel("Cluster", size=14)
plt.title(f"speed", size=18)
plt.show()

# COMMAND ----------

provaAvg

# COMMAND ----------

#non cambia molto - sommare a urban gli "other"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Aggiungere avg speed per mission type al df spark

# COMMAND ----------

#aggiungere il tempo in ore
from pyspark.sql.functions import when, col

df = df.withColumn("timeHours", col("timeSeconds")/(60**2))\
        .withColumn("streetTypeAgg", when(col("streetType")=="URBAN", "URBAN")
                                 .when(col("streetType")=="EXTRAURBAN", "EXTRAURBAN")
                                 .when(col("streetType")=="HIGHWAY", "HIGHWAY")
                                 .when(col("streetType")=="OTHER", "URBAN")
                                 .otherwise("NULL")
                                    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregare le mission (1 riga per mission * street type)

# COMMAND ----------

from pyspark.sql.functions import col, sum

dfwithAvgspeed = df.groupBy("chassis", "missionId", "streetType")\
            .agg(sum(col("distanceKm")).alias("distanceKm") , sum(col("timeHours")).alias("timeHours") )\
            .withColumn("averageSpeed", col("distanceKm")/col("timeHours"))\
            .filter(col("averageSpeed").isNotNull())\
            .filter(col("distanceKm")>0)\
            .filter(col("streetType").isin(["NULL", "OTHER"])==False)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Mission Aggregate (1 riga per mission con streetType in colonna) 
# MAGIC #### - PROVA 1: average speed in colonna per tipo di mission

# COMMAND ----------

#dato di partenza: più righe per mission (1 riga per tipo di street type)
display(dfwithAvgspeed.sort("chassis", "missionid", "streetType").limit(5))

# COMMAND ----------

from pyspark.sql.functions import sum, collect_set, first

listaValoriStreetType = dfwithAvgspeed.select(collect_set("streetType").alias("list")).collect()[0][0]

dfAgg1rowPerMission = dfwithAvgspeed.groupBy("chassis", "missionId")\
                                    .pivot("streetType", listaValoriStreetType)\
                                    .agg(first("averageSpeed"))\
                                    .fillna(0, subset=listaValoriStreetType)



# COMMAND ----------

display(dfAgg1rowPerMission)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Mission Aggregate (1 riga per mission con streetType in colonna) 
# MAGIC #### - PROVA 2:  percentuale della distanza percorsa in colonna per tipo di mission

# COMMAND ----------

#sommare per mission i km e il tempo
from pyspark.sql.functions import sum, collect_set, first

listaValoriStreetType = dfwithAvgspeed.select(collect_set("streetType").alias("list")).collect()[0][0]


dfAggKmAndHours = dfwithAvgspeed.groupBy("chassis", "missionId")\
                        .agg(sum("distanceKm").alias("distanceKm"), 
                             sum("timeHours").alias("timeHours"))\
                        .withColumn("averageSpeed", col("distanceKm")/col("timeHours"))


dfAgg1rowPerMission = dfwithAvgspeed.groupBy("chassis", "missionId")\
                                .pivot("streetType", listaValoriStreetType)\
                                .agg( first("distanceKm"))\


dfAgg1rowPerMission = dfAggKmAndHours.join(dfAgg1rowPerMission, ["chassis", "missionId"])\
                                        .fillna(0, subset=listaValoriStreetType)\
                                        .withColumn("urban", col("urban")/col("distanceKm"))\
                                        .withColumn("extraurban", col("extraurban")/col("distanceKm"))\
                                        .withColumn("highway", col("highway")/col("distanceKm"))
                                                       

# COMMAND ----------

display(dfAgg1rowPerMission.sort("chassis", "missionid"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verificare che AVG speed calcolato da DF percorsi sia uguale a AVG speed risultante da Mission aggregate da edwh

# COMMAND ----------

#prima: vedere se l'avg speed che risulta dal calcolo è simile a quello che risulta dalle mission aggregate
#dataset con tutte le mission trovate
from pyspark.sql.functions import col

dataset = "reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh"

df = spark.read.table(dataset)\
        .filter(col("totalTime")>0)\
        .filter(col("totaldistance")>0)\
        .withColumn("averageSpeedDaEdwh", col("totaldistance")/(col("totaltime")/(60**2)))\
        .select("chassis", "missionId", "averageSpeedDaEdwh")


dfAgg1rowPerMission = dfAgg1rowPerMission.join(df, ["chassis", "missionid"], "left")\
                        .withColumn("avgSpeedDifference", ((col("averageSpeed")-col("averageSpeedDaEdwh"))**2)**0.5)

# COMMAND ----------

from pyspark.sql.functions import desc

display(dfAgg1rowPerMission.sort(desc("avgSpeedDifference")))

# COMMAND ----------

# MAGIC %md
# MAGIC #prova classificazione

# COMMAND ----------

dfAgg1rowPerMission.select("chassis").distinct().count()

# COMMAND ----------

