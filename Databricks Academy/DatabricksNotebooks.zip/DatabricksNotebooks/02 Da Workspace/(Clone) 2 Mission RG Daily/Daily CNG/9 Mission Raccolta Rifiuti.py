# Databricks notebook source
# MAGIC %md
# MAGIC # Download Data Raccolta Rifiuti

# COMMAND ----------

pip install openpyxl

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "RGDailyCNG"
notebook = "missionRaccoltaRifiuti_downloadFlatData"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Lista dei Customer da Beccaro

# COMMAND ----------

import pandas as pd

clienti = pd.read_excel("/dbfs/FileStore/tables/reliab/Lista_Grandi_Clienti_Delivery_Distribution_Grocery_Ecology.xlsx", header=[3])

clienti = clienti.loc[pd.isnull(clienti.Cliente)==False]

# COMMAND ----------

clienti

# COMMAND ----------

dfPandasClienti = pd.DataFrame(set(clienti.Cliente.str.lower()), columns=["cliente"])

dfClienti = spark.createDataFrame(dfPandasClienti)

# COMMAND ----------

from pyspark.sql.functions import col, lower

vinRaccDiff = spark.read.table("edwh.vehicle")\
                .withColumn("cliente", lower(col("cust_ds_cust_nm_customer")))\
                .join(dfClienti, "cliente" )\
                .selectExpr("pvan_cd_vin_code as chassis")   

# COMMAND ----------

spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
        .join(vinRaccDiff, "chassis").count()