# Databricks notebook source
from pyspark.sql.functions import col

#varList = ["chassis", "missionId", "totalDistance/(totalTime/3600) as averageSpeed",
#            "totaltime", 
#            "totalTimeDriving/totalTime as percentTimeDriving", 
#            "totalTimeIdling/totalTime as percentTimeIdling",
#            "totalTimePtoOn/totalTime as percentTimePTOon",
#            "totalTimeACC/totalTime as percentTimeACC", 
#            "totalTimeBrakePedal/totalTime as percentTimeBrakePedal",
#            "totalDistance", 
#            "totalDistancePtoOn/totalDistance as percentDistancePtoOn",
#            "totalDistanceACC/totalDistance as percentDistanceACC",
#            "fuelConsumption/totalDistance as fuelConsumptionDistance", 
#            "maxVehicleSpeed",
#            "stops/totalDistance as stopsDistance",
#            "harshSteering/totalDistance as harshSteeringDistance", 
#            "harshBraking/totalDistance as harshBrakingDistance",
#            ]
            
misPiem = spark.read.table("default.20230531_rgdailycng_missioninpiemonte_streetinfocomplete")

df = spark.read.table("reliab.20230531_rgdailycng_missioninpiemonte")\
            .join(misPiem, ["chassis", "missionId"])\
            .filter(col("totalTime")>60*5)\
            .filter(col("totalDistance")>1)\
            .filter(col("streetInfo.state")=="Piemonte")

df.count()

# COMMAND ----------

#merge con file di mtbf per vedere se abbiamo chassis con mtbf già pronto

#leggere il file csv con i dati dei veicoli
listaVeicoliConMtbf = spark.read.csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCng.csv", header=True)\
                                        .withColumnRenamed("Serial_Number", "chassis")\
                                        .drop("Sub_Vehicle_Class_Description")

df = df.join(listaVeicoliConMtbf , ["chassis"], "left")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Plot delle mission in Piemonte

# COMMAND ----------

from pyspark.sql.functions import col 

df = spark.read.table("reliab.20230531_RGDailyCNG_checkIfInPiemonte")\
        .filter(col("isInPiedmont")==True).toPandas()



# COMMAND ----------

print(len(set(df.chassis)))


df.sample(20).sort_values()

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])

# COMMAND ----------

#aggiungere il poligono alla mappa 
import folium

m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

line_color='gray'
fill_color='gray'
weight=2



df.apply(lambda row: folium.CircleMarker(location=[row["lat_start"], row["lon_start"]], 
                                              radius=0.000001 , popup = row["chassis"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Estrarre un campione di percorsi in Piemonte

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "RGDailyCNG"
notebook = "missionInPiemonte_EstrarrePercorsi"

nome = database + "." + data + "_" + progetto + "_" + notebook

print(nome)

# COMMAND ----------

#missioInPiemonte
dfPiemonte =  spark.read.table("reliab.20230531_RGDailyCNG_checkIfInPiemonte")\
                    .filter(col("isInPiedmont")==True)\
                    .select("chassis", "missionId")\
                    .distinct()\
                    .sample(0.15)

#data
dfCompleto = spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
                    .select("chassis", "missionId", "startOfSampling", "endOfSampling")\
                    .join(dfPiemonte, ["chassis", "missionId"])\
                    .createOrReplaceTempView("lista")

# COMMAND ----------

#estrarre percorsi completi
#spark.sql("""SELECT a.chassis, a.missionId, b.startOfSampling, b.endOfSampling, b.Timestamp, b.Altitude, b.Latitude, b.Longitude
#              FROM  lista a 
#                  LEFT JOIN datacollector.datacollector_gps_tabular_prod b
#                      ON a.chassis = b.chassis 
#                      AND b.startofsampling >= a.startofsampling 
#                      AND b.endOfSampling   <= a.endOfSampling """).write.saveAsTable(f"{nome}")
# 

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(DISTINCT missionid)
# MAGIC from reliab.20230601_RGDailyCNG_missionInPiemonte_EstrarrePercorsi

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plot di alcuni percorsi in piemonte

# COMMAND ----------

df = spark.read.table("reliab.20230601_RGDailyCNG_missionInPiemonte_EstrarrePercorsi")

# COMMAND ----------

#plot delle mission
from pyspark.sql.functions import col 

import folium

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 

datasetPercorsi  = "reliab.20230601_RGDailyCNG_missionInPiemonte_EstrarrePercorsi"

df = spark.read.table(datasetPercorsi)\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId")\
        .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=False)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

