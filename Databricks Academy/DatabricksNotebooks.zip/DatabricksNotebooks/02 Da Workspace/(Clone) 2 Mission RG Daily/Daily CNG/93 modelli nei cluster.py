# Databricks notebook source


# COMMAND ----------

from pyspark.sql.functions import col,count, substring

# tabella con gli chassis e cluster id
df = spark.read.table("reliab.20230713_rgdailycng_allchassisclusteredwithbothmethods")

veic = spark.read.table("edwh.vehicle")\
            .withColumnRenamed("pvan_cd_vin_code", "chassis")\
            .withColumnRenamed("prvp_ds_vp_sdes", "model")\
            .select("chassis", "model")\
            .withColumn("model", substring("model", 0,3))



df = df.join(veic, "chassis")

totalVeicClus = df.groupBy("onlyMtbfVehiclesLess5000", "cluster").agg(count("model").alias("totalVeic"))


df = df.join(totalVeicClus,["onlyMtbfVehiclesLess5000" , "cluster"])
        




# COMMAND ----------

display(df)

# COMMAND ----------

agg = df.groupBy(["onlyMtbfVehiclesLess5000","cluster", "totalVeic", "model"])\
        .agg(count("model").alias("veicClus"))\
            .withColumn("perc", col("veicClus")/col("totalVeic"))



# COMMAND ----------

display(agg)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number,desc

windowSpec = Window().partitionBy(["onlyMtbfVehiclesLess5000", "model"]).orderBy(desc("perc"))

aggModel = agg.select("*", row_number().over(windowSpec).alias("row")).filter(col("row")<3)

# COMMAND ----------

display(aggModel.filter(col("onlyMtbfVehiclesLess5000")==True))

# COMMAND ----------

display(spark.read.table("reliab.20230713_rgdailycng_accumulclusteringresults").sort(["onlyMtbfVehiclesLess5000", "cluster"]))

# COMMAND ----------

