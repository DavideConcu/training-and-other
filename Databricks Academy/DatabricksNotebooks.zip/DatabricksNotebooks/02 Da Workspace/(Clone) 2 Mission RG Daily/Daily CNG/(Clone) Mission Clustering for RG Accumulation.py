# Databricks notebook source
# MAGIC %md
# MAGIC # RG Km Accumulation based on Average Speed Clustering

# COMMAND ----------

from pyspark.sql.functions import col

dfSpark = spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
                .filter(col("totaldistance")>0)\
                .filter(col("totaltime")>0)\
                .selectExpr( "chassis", "missionid", "totaldistance", "maxVehicleSpeed", "stops", "stops/totaldistance as stopsPerDistance", "totaldistance/(totaltime/(60*60)) as averageSpeed" , "totalTimeIdling/totaltime as percentIdling", "harshSteering/totaldistance as harshSteeringPerDistance")


dfAltitude = spark.read.table("reliab.20230626_dailycng_daedwh_altitude").dropna()

df = dfSpark.join(dfAltitude, ["chassis", "missionId"]).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4 Cluster sulla Average Speed

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans


numCols = ["averageSpeed"]

#elbow rule overall PRE
X = df.loc[:, numCols].to_numpy()
scalers = StandardScaler()
X_std = scalers.fit_transform(X)
X_std.shape

kmeans_kwargs = {
"init": "random",
"n_init": 100,
    "max_iter": 1000,
    "random_state": 1
}

NUMEROCLUSTERS = 4

#fit e risultato del clustering
kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
kmeans.fit(X_std)
predicted_kmeans = kmeans.predict(X_std)

#calcolo distanza dal centroide
distance = []
for point in range(len(X_std)):
    clus = predicted_kmeans[point]
    distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

#attaccare label
df.loc[:, "cluster"] = predicted_kmeans.astype(int)
df.loc[:, "distance"] = distance

df = df.drop("distance", axis = 1)


#riordinare i cluster
newClus = df.groupby("cluster").averageSpeed.mean().sort_values(ascending=False).reset_index().reset_index().rename({"index":"cluster_new"}, axis=1)[["cluster_new", "cluster"]]

df = df.merge(newClus, on="cluster").drop("cluster", axis=1).rename({"cluster_new":"cluster"},axis=1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Mappare le mission

# COMMAND ----------

#func mission basata su velocità media
def missionType(cluster):
    """map mission type in highway extraurban urban raccoltarifiuti"""
    missionType = None

    if cluster == 3:
        missionType = "ECOLOGY"
    elif cluster == 2:
        missionType = "URBAN"
    elif cluster == 1:
        missionType = "EXTRAURBAN"
    elif cluster == 0:
        missionType = "HIGHWAY"

    return missionType

#func mission basata su altitudine
def missionTypeAltitude(altitude):
    """define another mission type based on altitude"""
    missionTypeAltitude = None
    if altitude >= 600:
        missionTypeAltitude = "MOUNTAIN"
    elif altitude >= 300:
        missionTypeAltitude = "HILLY"
    else:
        missionTypeAltitude = "FLAT"
    
    return missionTypeAltitude

# COMMAND ----------

#apply the functions to map missions
df["missionType"] = df.apply(lambda x: missionType(x["cluster"]), axis = 1)
df["missionTypeAltitude"] = df.apply(lambda x: missionTypeAltitude(x["maxAltitude"]), axis = 1)

#spark df
dfMissionMappateSpark = spark.createDataFrame(df)

# COMMAND ----------

#salvare il dataset con le mission mappate
#dfMissionMappateSpark.write.saveAsTable("reliab.20230711_RGDailyCNG_AllMissionsWithStreetTypeForPowerBI")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Aggregare per Chassis

# COMMAND ----------

#calcolo dei totali per vin
totalsPerVin = df.groupby("chassis")[["totaldistance", "stops"]].sum().reset_index()
totalsPerVin["stopsPerDistance"] =  totalsPerVin.stops/totalsPerVin.totaldistance
totalsPerVin = totalsPerVin.drop("stops",axis=1)


#### STREET TYPE PIVOT
for column in ["missionType", "missionTypeAltitude"]:

    dfAggMissType = df.groupby(["chassis", column]).totaldistance.sum()
    dfAggMissType.name = "distance"

    dfAggMissType = dfAggMissType.reset_index().merge(totalsPerVin, on="chassis")

    dfAggMissType["totaldistancePerc"] = dfAggMissType.distance/dfAggMissType.totaldistance 

    pivot = dfAggMissType.pivot(index=["chassis"], columns=column, values="totaldistancePerc").fillna(0)

    totalsPerVin = totalsPerVin.merge(pivot, on="chassis")


#spark df
totalsPerVinSpark = spark.createDataFrame(totalsPerVin)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Aggiungere l'MTBF al df con 1 riga per chassis

# COMMAND ----------

#aggiungere l'mtbf 
dfCinzia = spark.read\
        .csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCngTotal.csv", header = "true")\
        .withColumnRenamed("Serial_Number", "chassis")\
        .withColumn("mtbf" , col("MTBF_veicolo").cast("float"))\
        .select("chassis", "mtbf")


totalsPerVinSpark = totalsPerVinSpark.join(dfCinzia, "chassis", "left")

# COMMAND ----------

#salvare il dataset per power bi
#totalsPerVinSpark.write.saveAsTable("reliab.20230711_RGDailyCNG_AllChassisAggForPowerBI")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Clustering dei VIN 
# MAGIC obbiettivo: avere 6 cluster (1 per veicolo RG)

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

def clustering(df):

    numCols = ["ECOLOGY", "URBAN", "EXTRAURBAN", "HIGHWAY"]

    #elbow rule overall PRE
    X = df.loc[:, numCols].to_numpy()
    scalers = StandardScaler()
    X_std = scalers.fit_transform(X)
    X_std.shape

    kmeans_kwargs = {
    "init": "random",
    "n_init": 100,
        "max_iter": 1000,
        "random_state": 1
    }

    NUMEROCLUSTERS = 6

    #fit e risultato del clustering
    kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
    kmeans.fit(X_std, sample_weight=weight)
    #kmeans.fit(X_std)

    predicted_kmeans = kmeans.predict(X_std)

    #calcolo distanza dal centroide
    distance = []
    for point in range(len(X_std)):
        clus = predicted_kmeans[point]
        distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

    #attaccare label
    df.loc[:, "cluster"] = predicted_kmeans.astype(int)

    return df 


# COMMAND ----------

from pyspark.sql.functions import col

#clustering con tutti i veicoli (a prescindere dall'mtbf)
df = totalsPerVinSpark.toPandas()
weight = df.loc[:,"totaldistance"].to_numpy()
clusteringAll = clustering(df)
clusteringAll["onlyMtbfVehiclesLess5000"] = False

#clustering usando solo i veicoli con mtbf
df = totalsPerVinSpark.filter(col("mtbf") <= 5000).toPandas()

weight =  ((1 / df.loc[:,"mtbf"]) * df.loc[:,"totaldistance"] ).to_numpy()
clusteringMtbf = clustering(df)
clusteringMtbf["onlyMtbfVehiclesLess5000"] = True

dfClustering = pd.concat([clusteringAll, clusteringMtbf])
dfClustering.reset_index(drop=True, inplace=True)


#risistemare l'ordine delle colonne
dfClustering = dfClustering.loc[:, ["chassis","mtbf", "totaldistance","stopsPerDistance","ECOLOGY","URBAN","EXTRAURBAN","HIGHWAY","FLAT","HILLY","MOUNTAIN","cluster", "onlyMtbfVehiclesLess5000"]]


#salvare il risultato del clustering 
dfClusteringSpark = spark.createDataFrame(dfClustering)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Medie all'interno del cluster
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Media Non Pesata

# COMMAND ----------

#media semplice
display(dfClusteringSpark.groupBy(["onlyMtbfVehiclesLess5000", "cluster"]).mean())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Media pesata all'interno del cluster

# COMMAND ----------

import numpy as np

df = dfClustering.copy()


#inizializzare df
dfAvgClus = pd.DataFrame() 

#colonna mtbf
col = "mtbf"
dfAvgClus[col] = df.groupby(["onlyMtbfVehiclesLess5000", "cluster"]).apply(lambda x: np.nanmean(x[col]))


#medie pesate per le altre var
for col in ["ECOLOGY", "URBAN", "EXTRAURBAN", "HIGHWAY", "FLAT", "HILLY", "MOUNTAIN"]:
    dfAvgClus[col] = df.groupby(["onlyMtbfVehiclesLess5000", "cluster"]).apply(lambda x: np.average(x[col], weights=x.totaldistance))


# COMMAND ----------

#salvare il dataset
spark.createDataFrame(dfAvgClus.reset_index()).write.saveAsTable("reliab.20230713_RGDailyCNG_AccumulClusteringResults")