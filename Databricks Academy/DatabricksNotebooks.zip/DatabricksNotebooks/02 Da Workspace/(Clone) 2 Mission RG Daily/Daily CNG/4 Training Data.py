# Databricks notebook source
# MAGIC %md
# MAGIC ##dataset di training con mission daily diesel

# COMMAND ----------

#dati di partenza
from pyspark.sql.functions import col, lit

varlist = ["chassis", "missionId", "totaldistance/(totaltime/(60*60)) as averageSpeed",
            "totaltime", 
            "percentTimeDriving", 
            "percentTimeIdling",
            "percentTimePTOon",
            "percentTimeACC", 
            "percentTimeBrakePedal",
            "totalDistance", 
            "percentDistancePtoOn",
            "percentDistanceACC",
            "fuelConsumptionDistance", 
            "maxVehicleSpeed",
            "stopsDistance",
            "harshSteeringDistance", 
            "harshBrakingDistance"]

dfDailyDTabular = spark.read.table("reliab.20230413_r39_rgdaily_scaricamissionbadpiemonte_mergedwithtabular")\
                            .selectExpr(varlist)

dfDailyDMission = spark.read.table("reliab.20230427_r39_rgdaily_streetinfo_final_AggMissionType")\
            .join(dfDailyDTabular, ["chassis", "missionid"])\


dfDailyCNG = spark.read.table("reliab.20230530_RGDailyCNG_classificaMission_trainingSample")\
                    .filter(~col("missionType").isin(["NULL", "OTHER"]))



training = dfDailyCNG.unionByName(dfDailyDMission).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prova Classificazione

# COMMAND ----------

testProportion = 0.5
nChassisTest = round(testProportion*training.chassis.count())

print(nChassisTest)

testList = training.chassis.sample(nChassisTest)

#df Training
X_train = training.loc[~training.chassis.isin(testList) , [x for x in training.columns if x not in ["chassis", "missionId", "missionType"]]]
y_train = training.loc[~training.chassis.isin(testList) ,"missionType"]

X_test = training.loc[training.chassis.isin(testList) , [x for x in training.columns if x not in ["chassis", "missionId", "missionType"]]]
y_test = training.loc[training.chassis.isin(testList) ,"missionType"]

# COMMAND ----------

# MAGIC %md
# MAGIC #### random forest

# COMMAND ----------

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

clf = RandomForestClassifier(max_features = 8, random_state = 0, n_estimators=400)
clf.fit(X_train, y_train)

pred = clf.predict(X_test)

print(classification_report(y_test, pred, zero_division=True))

print('Accuracy of RF classifier on training set: {:.2f}'
     .format(clf.score(X_train, y_train)))
print('Accuracy of RF classifier on test set: {:.2f}'
     .format(clf.score(X_test, y_test)))

# COMMAND ----------

