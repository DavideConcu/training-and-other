# Databricks notebook source
table = "reliab.20231010__RGDailyCNG_VeicoliMissionPiemonte"

# COMMAND ----------

#selezione colonne da dati in datacollector_tabular_flat
varList = ["chassis", "missionId", "totalDistance/(totalTime/3600) as averageSpeed",
            "totaltime", 
            "totalTimeDriving/totalTime as percentTimeDriving", 
            "totalTimeIdling/totalTime as percentTimeIdling",
            "totalTimePtoOn/totalTime as percentTimePTOon",
            "totalTimeACC/totalTime as percentTimeACC", 
            "totalTimeBrakePedal/totalTime as percentTimeBrakePedal",
            "totalDistance", 
            "totalDistancePtoOn/totalDistance as percentDistancePtoOn",
            "totalDistanceACC/totalDistance as percentDistanceACC",
            "fuelConsumption/totalDistance as fuelConsumptionDistance", 
            "maxVehicleSpeed",
            "stops/totalDistance as stopsDistance",
            "harshSteering/totalDistance as harshSteeringDistance", 
            "harshBraking/totalDistance as harshBrakingDistance",
            "engineWorkHours",
            "area"]

dfTabular = spark.read.table(table).selectExpr(varList)

# COMMAND ----------

dfTabular.write.mode("overWrite").option("overwriteschema", "true").saveAsTable(table + "_forProcMeansSAS")

# COMMAND ----------

display(dfTabular.select("area", "chassis").distinct().orderBy("area"))

# COMMAND ----------

