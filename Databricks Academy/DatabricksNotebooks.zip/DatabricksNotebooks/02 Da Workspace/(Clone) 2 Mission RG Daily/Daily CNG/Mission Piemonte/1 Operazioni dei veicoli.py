# Databricks notebook source
# MAGIC %pip install folium

# COMMAND ----------

# MAGIC %md
# MAGIC # Specifiche dei Veicoli usati per definire le mission

# COMMAND ----------

##output data spec
from datetime import date 
database = "reliab"
data = date.today().strftime('%Y%m%d')
progetto = "_RGDailyCNG"
notebook = "VeicoliMissionPiemonte"

nome = database + "." + data + "_" + progetto + "_" + notebook

# COMMAND ----------

from pyspark.sql.functions import col

#load table
table = "reliab.20230531_rgdailycng_missioninpiemonte"

df = spark.read.table(table)

#togliere il veicolo di iveco
df = df.filter(col("customer") != "Iveco Demo HQ")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Asti (Extraurban)

# COMMAND ----------

# Area ASTI:
nw = [45.095119,7.980219]
sw = [44.850904,7.972744]
ne = [45.088170,8.318530]
se = [44.825390,8.328263]

maxLat = min(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = min(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]

# COMMAND ----------

from pyspark.sql.functions import col, lit

asti = df\
    .filter((col("lat_start") <= maxLat) | (col("lat_end") <= maxLat))\
    .filter((col("lat_start") >= minLat) | (col("lat_end") >= minLat))\
    .filter((col("lon_start") <= maxLon) | (col("lon_end") <= maxLon))\
    .filter((col("lon_start") >= minLon) | (col("lon_end") >= minLon))\
        .withColumn("area", lit("ASTI"))\
        .select("missionId", "area")


#df = df.join(asti, "missionId", how = "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pinerolo (Extraurban)

# COMMAND ----------

area = "PINEROLO"

# Area Pinerolo:
nw = [45.046553,7.167337]
sw = [44.695395,7.185837]
ne = [45.042842,7.534700]
se = [44.777473,7.506133]

maxLat = min(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = min(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]

# COMMAND ----------

from pyspark.sql.functions import col, lit

pinerolo1 = df\
    .filter((col("lat_start") <= maxLat) | (col("lat_end") <= maxLat))\
    .filter((col("lat_start") >= minLat) | (col("lat_end") >= minLat))\
    .filter((col("lon_start") <= maxLon) | (col("lon_end") <= maxLon))\
    .filter((col("lon_start") >= minLon) | (col("lon_end") >= minLon))\
        .withColumn("area", lit(area))\
        .select("missionId", "area")


# COMMAND ----------

area = "PINEROLO"

# Area Pinerolo:
nw = [45.501486,7.740259]
sw = [45.251737,7.765003]
ne = [45.517462,7.988492]
se = [45.251253,7.924346]

maxLat = min(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = min(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]

# COMMAND ----------

from pyspark.sql.functions import col, lit

pinerolo2 = df\
    .filter((col("lat_start") <= maxLat) | (col("lat_end") <= maxLat))\
    .filter((col("lat_start") >= minLat) | (col("lat_end") >= minLat))\
    .filter((col("lon_start") <= maxLon) | (col("lon_end") <= maxLon))\
    .filter((col("lon_start") >= minLon) | (col("lon_end") >= minLon))\
        .withColumn("area", lit(area))\
        .select("missionId", "area")


# COMMAND ----------

##df = df.join(pinerolo1, "missionId", "left")
#df = df.join(pinerolo2, "missionId", "left")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Viù

# COMMAND ----------

area = "VIù"

# Area Pinerolo:
nw = [45.311235,7.279878]
sw = [45.148438,7.289723]
ne = [45.313674,7.578034]
se = [45.148632,7.577978]

maxLat = min(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = min(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]

# COMMAND ----------

from pyspark.sql.functions import col, lit

viù = df\
    .filter((col("lat_start") <= maxLat) | (col("lat_end") <= maxLat))\
    .filter((col("lat_start") >= minLat) | (col("lat_end") >= minLat))\
    .filter((col("lon_start") <= maxLon) | (col("lon_end") <= maxLon))\
    .filter((col("lon_start") >= minLon) | (col("lon_end") >= minLon))\
        .withColumn("area", lit(area))\
        .select("missionId", "area")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Domodossola (Highway)

# COMMAND ----------

area = "DOMODOSSOLA"

# Area domodossola:
nw = [46.338206,8.021742]
sw = [45.243567,8.196571]
ne = [46.365505,8.495712]
se = [45.274500,8.757248]

maxLat = min(nw[0], ne[0])
minLat = min(sw[0], se[0])

maxLon = min(ne[1], se[1])
minLon =  min(nw[1], sw[1])

#Points:
NW =  [maxLat , minLon]
SW =  [minLat, minLon]
NE =  [maxLat, maxLon]
SE =  [minLat, maxLon]

# COMMAND ----------

from pyspark.sql.functions import col, lit

domodossola = df\
    .filter((col("lat_start") <= maxLat) | (col("lat_end") <= maxLat))\
    .filter((col("lat_start") >= minLat) | (col("lat_end") >= minLat))\
    .filter((col("lon_start") <= maxLon) | (col("lon_end") <= maxLon))\
    .filter((col("lon_start") >= minLon) | (col("lon_end") >= minLon))\
        .withColumn("area", lit(area))\
        .select("missionId", "area")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Unione delle Mission 

# COMMAND ----------

#tutte le missionid delle aree
allMissions = asti\
                .union(pinerolo1)\
                .union(pinerolo2)\
                .union(domodossola)\
                .union(viù)


#filtrare il dataset di partenza
df = df.join(allMissions, "missionId")

# COMMAND ----------

#salvare il dataset finale
df.write.saveAsTable(nome)

print(nome)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualizzare le Mission

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    folium.Marker(
        location=row['path'][0],
        icon=folium.Icon(icon='play', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])

    folium.Marker(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])

# COMMAND ----------

#aggiungere il poligono alla mappa 
import folium 

m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)

line_color='gray'
fill_color='gray'
weight=2
text=''

edges = [NW, NE, SE, SW]

m.add_child(folium.vector_layers.Polygon(locations=edges, color=line_color, fill_color=fill_color,
                                              weight=weight, popup=(folium.Popup(text))))


df.toPandas().apply(lambda row: folium.CircleMarker(location=[row["lat_start"], row["lon_end"]], 
                                              radius=0.000001 , popup = row["missionId"])
                                             .add_to(m), axis=1) 


#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False)) 

m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualizzare i Percorsi

# COMMAND ----------

df = spark.read.table("reliab.20230601_rgdailycng_missioninpiemonte_estrarrepercorsi")\
                .join(allMissions, "missionId")

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    
    folium.Circle(
        location=row['path'][0],
        icon=folium.Icon(icon='point', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])
    
    folium.Circle(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])


# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


df = df\
    .filter(col("latitude").isNotNull())\
    .filter(col("longitude").isNotNull())\
    .sort("missionid", "timestamp")\
    .withColumn("latLon", array("latitude", "longitude"))\
    .groupBy("chassis", "missionId")\
    .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

