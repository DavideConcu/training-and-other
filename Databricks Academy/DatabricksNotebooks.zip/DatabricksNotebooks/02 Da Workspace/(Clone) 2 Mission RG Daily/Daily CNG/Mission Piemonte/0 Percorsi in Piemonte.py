# Databricks notebook source
pip install folium

# COMMAND ----------

from pyspark.sql.functions import col 

#filtro per togliere il veicolo iveco 
filtro = spark.read.table("reliab.20230531_rgdailycng_missioninpiemonte").filter(col("customer")!="Iveco Demo HQ").select("missionId", "customer")

# COMMAND ----------

#plot delle mission
from pyspark.sql.functions import col 

df = spark.read.table("reliab.20230601_rgdailycng_missioninpiemonte_estrarrepercorsi")\
        .join(filtro, "missionId", "inner")

dfMissionType = spark.read.table("reliab.20230711_rgdailycng_allmissionswithstreettypeforpowerbi")\
                        .select("chassis", "missionid", "missionType")



df = df.join(dfMissionType, ["chassis", "missionId"])
            #.filter(col("missionType")=="EXTRAURBAN")


#unire la mission type standard
daEdwh = spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
                .select("chassis", "missionId", "missionType")\
                .withColumnRenamed("missionType", "missionType_standard")

df = df.join(daEdwh, ["chassis", "missionid"])#.filter(col("missionType_standard")=="UrbanHeavy")


# COMMAND ----------

display(df.select(col("customer")).distinct())

# COMMAND ----------

#display(df.select("missionType_standard").distinct())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plot Mission

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    
    folium.Circle(
        location=row['path'][0],
        icon=folium.Icon(icon='point', color='green'),
        popup = popupLatLonStart
    ).add_to(listaLayers[num])
    
    folium.Circle(
        location=row['path'][-1],
        icon=folium.Icon(icon='stop', color='red'),
        popup = popupLatLonEnd
    ).add_to(listaLayers[num])


# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


df = df\
    .filter(col("latitude").isNotNull())\
    .filter(col("longitude").isNotNull())\
    .sort("missionid", "timestamp")\
    .withColumn("latLon", array("latitude", "longitude"))\
    .groupBy("chassis", "missionId")\
    .agg(collect_list("latlon").alias("path")).toPandas()



#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

