# Databricks notebook source
# MAGIC %md
# MAGIC # Modo Semplificato per Calcolo accumuli

# COMMAND ----------

from pyspark.sql.functions import col
df = spark.read.table("reliab.20230526_rgdailycng_datasuperflatstarting2022_daedwh")\
                .filter(col("totaldistance")>0)\
                .filter(col("totaltime")>0)\
                .selectExpr( "chassis", "missionid", "totaldistance", "maxVehicleSpeed", "stops", "stops/totaldistance as stopsPerDistance", "totaldistance/(totaltime/(60*60)) as averageSpeed" , "totalTimeIdling/totaltime as percentIdling", "harshSteering/totaldistance as harshSteeringPerDistance")

# COMMAND ----------

# MAGIC %md
# MAGIC #### aggiunta dell'altitudine 
# MAGIC

# COMMAND ----------

dfAltitude = spark.read.table("reliab.20230626_dailycng_daedwh_altitude").dropna()

df = df.join(dfAltitude, ["chassis", "missionId"]).toPandas()

# COMMAND ----------

import matplotlib.pyplot as plt

alt = df.loc[df.maxAltitude<1000,:].sample(1000).sort_values(by="maxAltitude").reset_index().maxAltitude


plt.figure(figsize=(10, 5))
plt.ylabel("Altitude [m]", size=14)
plt.yticks([0,300,600])
plt.xticks([])
ax = plt.gca()
ax.grid(True)
plt.plot(alt)
plt.title("")


# COMMAND ----------

# MAGIC %md
# MAGIC #### prova con 4 cluster

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans


numCols = ["averageSpeed"]

#elbow rule overall PRE
X = df.loc[:, numCols].to_numpy()
scalers = StandardScaler()
X_std = scalers.fit_transform(X)
X_std.shape

kmeans_kwargs = {
"init": "random",
"n_init": 100,
    "max_iter": 1000,
    "random_state": 1
}

NUMEROCLUSTERS = 4

#fit e risultato del clustering
kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
kmeans.fit(X_std)
predicted_kmeans = kmeans.predict(X_std)

#calcolo distanza dal centroide
distance = []
for point in range(len(X_std)):
    clus = predicted_kmeans[point]
    distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

#attaccare label
df.loc[:, "cluster"] = predicted_kmeans.astype(int)
df.loc[:, "distance"] = distance

df = df.drop("distance", axis = 1)


#riordinare i cluster
newClus = df.groupby("cluster").averageSpeed.mean().sort_values(ascending=False).reset_index().reset_index().rename({"index":"cluster_new"}, axis=1)[["cluster_new", "cluster"]]

df = df.merge(newClus, on="cluster").drop("cluster", axis=1).rename({"cluster_new":"cluster"},axis=1)

# COMMAND ----------

#violin plot
import matplotlib.pyplot as plt
import seaborn as sns


plt.figure(figsize=(10, 5))
sns.violinplot(x="cluster", y="averageSpeed", data=df, palette="coolwarm", inner="quart" , split=True)

plt.ylabel("Average Speed [km/h]", size=14)
plt.xlabel("Cluster", size=14)
plt.title(f"Average Speed Distribution", size=18)
#ax = plt.gca()
ax.grid(True)
plt.show()

# COMMAND ----------

df.drop(["stops", "harshSteeringPerDistance", "maxAltitude", "meanAltitude"], axis=1).groupby("cluster").mean().reset_index()

# COMMAND ----------

display(spark.createDataFrame(df.drop(["stops", "harshSteeringPerDistance", "maxAltitude", "meanAltitude"], axis=1).groupby("cluster").mean().T.reset_index()))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Mappare le mission

# COMMAND ----------

#func mission basata su velocità media
def missionType(cluster):
    """map mission type in highway extraurban urban raccoltarifiuti"""
    missionType = None

    if cluster == 3:
        missionType = "ECOLOGY"
    elif cluster == 2:
        missionType = "URBAN"
    elif cluster == 1:
        missionType = "EXTRAURBAN"
    elif cluster == 0:
        missionType = "HIGHWAY"

    return missionType

#func mission basata su altitudine
def missionTypeAltitude(altitude):
    """define another mission type based on altitude"""
    missionTypeAltitude = None
    if altitude >= 600:
        missionTypeAltitude = "MOUNTAIN"
    elif altitude >= 300:
        missionTypeAltitude = "HILLY"
    else:
        missionTypeAltitude = "FLAT"
    
    return missionTypeAltitude

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Aggregare per Vin

# COMMAND ----------

#apply the functions to map missions
df["missionType"] = df.apply(lambda x: missionType(x["cluster"]), axis = 1)
df["missionTypeAltitude"] = df.apply(lambda x: missionTypeAltitude(x["maxAltitude"]), axis = 1)

#calcolo dei totali per vin
totalsPerVin = df.groupby("chassis")[["totaldistance", "stops"]].sum().reset_index()
totalsPerVin["stopsPerDistance"] =  totalsPerVin.stops/totalsPerVin.totaldistance
totalsPerVin = totalsPerVin.drop("stops",axis=1)



#### STREET TYPE PIVOT
for column in ["missionType", "missionTypeAltitude"]:

    dfAggMissType = df.groupby(["chassis", column]).totaldistance.sum()
    dfAggMissType.name = "distance"

    dfAggMissType = dfAggMissType.reset_index().merge(totalsPerVin, on="chassis")

    dfAggMissType["totaldistancePerc"] = dfAggMissType.distance/dfAggMissType.totaldistance 

    pivot = dfAggMissType.pivot(index=["chassis"], columns=column, values="totaldistancePerc").fillna(0)

    totalsPerVin = totalsPerVin.merge(pivot, on="chassis")

# COMMAND ----------

#aggiungere l'mtbf 
dfCinzia = spark.read.csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCngTotal.csv", header = "true")\
                .withColumnRenamed("Serial_Number", "chassis")\
                .withColumn("mtbf" , col("MTBF_veicolo").cast("float"))\
                .select("chassis", "mtbf")

# COMMAND ----------

dfMissionMappateSpark = spark.createDataFrame(df)

totalsPerVin = spark.createDataFrame(totalsPerVin)\
                    .join(dfCinzia, ["chassis"], "left")

# COMMAND ----------

display(totalsPerVin)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Clustering dei VIN per avere 6 RG

# COMMAND ----------

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

df = totalsPerVin.filter(col("mtbf").isNotNull()).toPandas()

#DEFINIRE I PESI PER LA CLUSTER 
#weight = df.loc[:,"totaldistance"].to_numpy()
#weight =  (1 / df.loc[:,"mtbf"]).to_numpy()
weight =  ((1 / df.loc[:,"mtbf"]) * df.loc[:,"totaldistance"] ).to_numpy()


numCols = ["ECOLOGY", "URBAN", "EXTRAURBAN", "HIGHWAY"]

#elbow rule overall PRE
X = df.loc[:, numCols].to_numpy()
scalers = StandardScaler()
X_std = scalers.fit_transform(X)
X_std.shape

kmeans_kwargs = {
"init": "random",
"n_init": 100,
    "max_iter": 1000,
    "random_state": 1
}

NUMEROCLUSTERS = 6

#fit e risultato del clustering
kmeans = KMeans(n_clusters=NUMEROCLUSTERS, **kmeans_kwargs)
kmeans.fit(X_std, sample_weight=weight)
#kmeans.fit(X_std)

predicted_kmeans = kmeans.predict(X_std)

#calcolo distanza dal centroide
distance = []
for point in range(len(X_std)):
    clus = predicted_kmeans[point]
    distance.append(np.linalg.norm(X_std[point] - kmeans.cluster_centers_[clus]))

#attaccare label
df.loc[:, "cluster"] = predicted_kmeans.astype(int)
df.loc[:, "distance"] = distance

df = df.drop("distance", axis = 1)


#riordinare i cluster
#newClus = df.groupby("cluster").averageSpeed.mean().sort_values(ascending=False).#reset_index().reset_index().rename({"index":"cluster_new"}, axis=1)[["cluster_new", #"cluster"]]
#
#df = df.merge(newClus, on="cluster").drop("cluster", axis=1).rename#({"cluster_new":"cluster"},axis=1)

# COMMAND ----------

#risistemare l'ordine delle colonne
df = df.loc[:, ["chassis","totaldistance","stopsPerDistance","ECOLOGY","URBAN","EXTRAURBAN","HIGHWAY","FLAT","HILLY","MOUNTAIN","cluster"]]

# COMMAND ----------

#to spark (per vedere quali mission sono in piemonte e in quale cluster)
dfClustersSpark = spark.createDataFrame(df).select("chassis", "cluster").distinct()

dfAllVarSpark = spark.createDataFrame(df).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggiunta dell'MTBF

# COMMAND ----------

#aggiungere l'mtbf 
dfCinzia = spark.read.csv("dbfs:/FileStore/tables/reliab/mtbfVinDailyCngTotal.csv", header = "true")\
                .withColumnRenamed("Serial_Number", "chassis")\
                .withColumn("mtbf" , col("MTBF_veicolo").cast("float"))\
                .select("chassis", "mtbf")

dfAllVarSpark = dfAllVarSpark.join(dfCinzia, "chassis", "left")   


display(dfAllVarSpark)

# COMMAND ----------

dfAllVarSpark.filter(col("mtbf")<5000).count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Media all'interno del cluster (non pesata)

# COMMAND ----------

df = dfAllVarSpark.toPandas()

display(spark.createDataFrame(df.groupby("cluster").mean().reset_index()))

# COMMAND ----------

print(f"CHASSIS IN TOTALE: {df.chassis.count()}")

df.groupby("cluster").chassis.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Media pesata all'interno del cluster

# COMMAND ----------

import numpy as np

dfAvgClus = pd.DataFrame() 
for col in ["ECOLOGY", "URBAN", "EXTRAURBAN", "HIGHWAY", "FLAT", "HILLY", "MOUNTAIN", "mtbf"]:

    dfAvgClus[col] = df.groupby("cluster").apply(lambda x: np.average(x[col], weights=x.totaldistance))

# COMMAND ----------

dfAvgClus

# COMMAND ----------

display(spark.createDataFrame(dfAvgClus.reset_index()))

# COMMAND ----------

# MAGIC %md
# MAGIC # Vedere quali di queste mission sono in piemonte

# COMMAND ----------

from pyspark.sql.functions import col

#mission in piemonte true false
dfPiemonte = spark.read.table("reliab.20230531_RGDailyCNG_checkIfInPiemonte")\
                    .filter(col("isInPiedmont")==True).distinct()

#join con le mission mappate
dfMissionMappatePiemonte = dfMissionMappateSpark.join(dfPiemonte,["chassis", "missionid"]).filter(col("totaldistance")>1).drop("lonLat").distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Percorsi completi delle mission in piemonte già estratti

# COMMAND ----------

#df con i percorsi già estratti
dfPathPiemonte = spark.read.table("reliab.20230601_RGDailyCNG_missionInPiemonte_EstrarrePercorsi")


#df con le mission aggregate in piemonte
dfMissionMappatePiemonte.join(dfPathPiemonte, ["chassis", "missionId"])


# COMMAND ----------

# MAGIC %md
# MAGIC ## limitare il numero di mission per tipologia (urban eco ecc)

# COMMAND ----------

#selezionare solo n mission per tipologia (le più lunghe in km)
from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number

#selezionare le n mission
windowSpec = Window.partitionBy(col("missionType")).orderBy(col("totalDistance").desc())

missionsToVisualize = dfMissionMappatePiemonte.withColumn("rowNumb", row_number().over(windowSpec))\
                        .select("chassis", "missionId","missionType", "missionTypeAltitude").distinct()


pathsToVisualize = dfPathPiemonte.join(missionsToVisualize, ["chassis", "missionId"])

# COMMAND ----------

display(missionsToVisualize.limit(3))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualizzare le mission

# COMMAND ----------

def addPaths(row, num):
    """ aggiunge le singole mission alla mappa principale"""
    
    popup = row["chassis"]  +  " " + row["missionId"] 
    popupLatLonStart =  str(row['path'][0][1])  + ", " + str(row['path'][0][0])
    popupLatLonEnd = str(row['path'][-1][1]) + ", " +  str(row['path'][-1][0]) 

    folium.PolyLine(
        row['path'],
        weight=8,
        color='blue',
        opacity=0.4,
    ).add_to(listaLayers[num])  
    
    #folium.Marker(
    #    location=row['path'][0],
    #    icon=folium.Icon(icon='play', color='green'),
    #    popup = popupLatLonStart
    #).add_to(listaLayers[num])

    #folium.Marker(
    #    location=row['path'][-1],
    #    icon=folium.Icon(icon='stop', color='red'),
    #    popup = popupLatLonEnd
    #).add_to(listaLayers[num])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Highway

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


df = pathsToVisualize\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId","missionType")\
        .agg(collect_list("latlon").alias("path")).toPandas()

df=df.loc[df.missionType=="HIGHWAY",:]

#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC #extraurban

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


df = pathsToVisualize\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId","missionType")\
        .agg(collect_list("latlon").alias("path")).toPandas()

df=df.loc[df.missionType=="EXTRAURBAN",:]

#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Urban

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


df = pathsToVisualize\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId","missionType")\
        .agg(collect_list("latlon").alias("path")).toPandas()

df=df.loc[df.missionType=="URBAN",:]

#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ecology

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 


df = pathsToVisualize\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId","missionType")\
        .agg(collect_list("latlon").alias("path")).toPandas()

df=df.loc[df.missionType=="ECOLOGY",:]

#mappa
m = folium.Map(location=(45.081699, 7.642890), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

# MAGIC %md
# MAGIC # visualizzare le mission francesi

# COMMAND ----------

pathFrancesi = spark.read.table("reliab.20230620_dailycng_downloadpercorsifrancia_sample2_withstreetinfo").join(dfMissionMappateSpark, ["chassis", "missionId"])

# COMMAND ----------

samplePaths = pathFrancesi.select("chassis", "missionid").distinct()

pathFrancesi = pathFrancesi.join(samplePaths, ["chassis", "missionId"])

# COMMAND ----------

#visualizzare le mission estratte (I PERCORSI)
from pyspark.sql.functions import array, col , collect_list
import folium 

tipo ="HIGHWAY"

limitPaths = pathFrancesi.filter(col("missionType")==tipo).select("chassis", "missionid").distinct()

df = pathFrancesi\
        .filter(col("latitude").isNotNull())\
        .filter(col("longitude").isNotNull())\
        .sort("missionid", "timestamp")\
        .withColumn("latLon", array("latitude", "longitude"))\
        .groupBy("chassis", "missionId","missionType")\
        .agg(collect_list("latlon").alias("path"))\
        .join(limitPaths, ["chassis","missionid"]).toPandas()

zona = df.path[0][0]
df=df.loc[df.missionType==tipo,:]

#mappa
m = folium.Map(location=(zona), zoom_start=13)


line_color='gray'
fill_color='gray'
weight=2



#creare i layer
listaLayers  = []
for num,mid in enumerate(set(df.missionId)):
    locals()[f"layer_clus_{num}"] = folium.FeatureGroup(name=f"id: {mid}", show=True)
    listaLayers.append(locals()[f"layer_clus_{num}"])


#aggiungere i punti al layer
for num, mid in enumerate(set(df.missionId)):
    df[df.missionId==mid]\
        .apply(lambda row: addPaths(row, num), axis = 1)    
    listaLayers[num].add_to(m)

#aggiunge il layer controller
m = m.add_child(folium.LayerControl(collapsed=False))  


m

# COMMAND ----------

