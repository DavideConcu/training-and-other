# Databricks notebook source
#load table
sdf = spark.read.table("reliab.20240206_vari_dailyDiesel_my1921_alldata")

sdf.select("chassis").distinct().count()

# COMMAND ----------

from pyspark.sql.functions import col, to_date

sdf = sdf.withColumn("date", to_date(col("startofsampling")))

# COMMAND ----------

sdf = sdf.filter(col("missiontype")!= "HighWay")

# COMMAND ----------

display(sdf)

# COMMAND ----------

from pyspark.sql.functions import col, sum, count

grouped = sdf.groupBy(["chassis", "date", "missiontype"]).agg(sum("totaldistance").alias("distance"))

# COMMAND ----------

display(grouped)

# COMMAND ----------

from pyspark.sql.functions import col, mean, count

grouped_chassis = grouped.groupBy("chassis", "date")\
                        .pivot(("missionType")).agg(sum("distance").alias("distance"))
            

# COMMAND ----------

# DBTITLE 1,jj
display(grouped_chassis)

# COMMAND ----------

final = grouped_chassis.fillna(0).groupBy("chassis").agg(
                                count("date").alias("total_days"),
                                sum(col("extraurban") + col("urbanLight") + col("urbanHeavy")).alias("total_km"),
                                mean("extraurban").alias("extraurban_km"),
                                mean("urbanLight").alias("urbanLight_km"),
                                mean("urbanHeavy").alias("urbanHeavy_km"),

)

# COMMAND ----------

display(final)

# COMMAND ----------

display(final.select(mean("extraurban_km"), mean("urbanLight_km"), mean("urbanHeavy_km")))

# COMMAND ----------

