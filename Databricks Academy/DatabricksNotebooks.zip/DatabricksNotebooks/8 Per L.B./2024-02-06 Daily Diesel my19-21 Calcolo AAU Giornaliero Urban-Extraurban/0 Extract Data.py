# Databricks notebook source
# MAGIC %md
# MAGIC ## Collect Data for Daily Diesel my19-21
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## List of Vehicles

# COMMAND ----------

from pyspark.sql.functions import col

filtro_veicoli = spark.read.table("edwh.vehicle")\
                    .selectExpr("pvan_cd_vin_code as chassis", 
                                "pvan_id_warranty_start_date as warr_startdate",
                                "pvcb_ds_sub_product_cl as product")\
                    .filter((col("product").like("%DAILY%MY19%DIESEL%"))|
                            (col("product").like("%DAILY%MY21%DIESEL%"))) 


# COMMAND ----------

filtro_veicoli.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Collect Data

# COMMAND ----------

dati_collector = spark.read.table("datacollector.datacollector_tabular_mission_for_wti_daily_super_flat_prod")\
  

# COMMAND ----------

from pyspark.sql.functions import col

#save data
join_sdf = filtro_veicoli.join(dati_collector, "chassis")\
                .filter((col("startofsampling")>col("warr_startdate"))|
                        (col("endofsampling")>col("warr_startdate")))

# COMMAND ----------

#join_sdf.write.mode("overwrite").saveAsTable("reliab.20240206_vari_dailyDiesel_my1921_alldata")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct chassis)
# MAGIC from reliab.20240206_vari_dailydiesel_my1921_alldata