# Databricks notebook source
# estrarre la lista dei veicoli Daily Diesel MY21 F1C - F1A CAB 
vehicles_sdf = spark.read.table("edwh.vehicle")

vehicles_sdf = vehicles_sdf\
                    .selectExpr("pvan_cd_vin_code as chassis", 
                                "pvan_ds_preliminary_model_year as my",
                                "pvcb_ds_sub_product_cl as product as product")

# COMMAND ----------

